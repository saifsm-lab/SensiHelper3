plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Build number comes from GitHub Actions (-PbuildNumber=...). It is also the release tag number (build-N)
val buildNo = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 1
// GitHub Actions writes this file from the KS_B64 secret. Without it, a temporary debug key is used.
val keystoreFile = rootProject.file("release.keystore")

android {
    namespace = "com.saif.sensihelper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.saif.sensihelper"
        minSdk = 26
        targetSdk = 34
        versionCode = buildNo
        versionName = "build $buildNo"
    }
    signingConfigs {
        create("app") {
            if (keystoreFile.exists()) {
                storeFile = keystoreFile
                storeType = "pkcs12"
                storePassword = "sensihelper"
                keyAlias = "sensi"
                keyPassword = "sensihelper"
            }
        }
    }
    buildTypes {
        debug {
            if (keystoreFile.exists()) signingConfig = signingConfigs.getByName("app")
        }
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime:2.9.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
