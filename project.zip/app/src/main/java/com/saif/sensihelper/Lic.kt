package com.saif.sensihelper

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.X509EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Device-bound access.
 * A code from the owner only works on the phone whose Device ID it was made for. The app holds only the
 * PUBLIC key, so a code cannot be made, edited or copied to another phone without the owner's private key.
 * The owner can also block a phone later by adding its Device ID to "revoked" in config.json.
 */
object Lic {
    private const val PUB = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAELdUWty3aHXYLyEjgMFg/UE46PdQ0QSWVN1mQiXD+EMqJpNSYK1yC66YkAXEHrQ86sfP5X6Z081rk96Lv3j+URg=="
    private const val PREFS = "lic"
    const val OK = 0
    const val BAD = 1
    const val EXPIRED = 2

    @Volatile private var cache: Boolean? = null
    @Volatile private var lastRefresh = 0L

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The short ID the user sends to the owner: 16 hex characters in groups of four. */
    fun deviceId(ctx: Context): String {
        val aid = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val h = MessageDigest.getInstance("SHA-256").digest(("sensi|" + aid + "|" + ctx.packageName).toByteArray(Charsets.UTF_8))
        val sb = StringBuilder()
        for (i in 0 until 8) sb.append(String.format("%02X", h[i]))
        return sb.substring(0, 4) + "-" + sb.substring(4, 8) + "-" + sb.substring(8, 12) + "-" + sb.substring(12, 16)
    }

    private fun todayInt(): Int {
        val f = SimpleDateFormat("yyyyMMdd", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date()).toInt()
    }

    private fun derInt(b: ByteArray): ByteArray {
        var i = 0
        while (i < b.size - 1 && b[i].toInt() == 0) i++
        var v = b.copyOfRange(i, b.size)
        if ((v[0].toInt() and 0x80) != 0) v = byteArrayOf(0) + v
        return byteArrayOf(0x02, v.size.toByte()) + v
    }

    /** Converts the 64-byte r||s signature into the DER form Java expects. */
    private fun derFromRaw(raw: ByteArray): ByteArray {
        val r = derInt(raw.copyOfRange(0, 32))
        val s = derInt(raw.copyOfRange(32, 64))
        return byteArrayOf(0x30, (r.size + s.size).toByte()) + r + s
    }

    /** OK, BAD (wrong code or made for another phone) or EXPIRED. */
    fun verify(ctx: Context, code: String): Int {
        return try {
            val c = code.trim()
            if (!c.startsWith("SH1.")) return BAD
            var b64 = c.substring(4).replace('-', '+').replace('_', '/')
            while (b64.length % 4 != 0) b64 += "="
            val raw = Base64.decode(b64, Base64.DEFAULT)
            if (raw.size != 68) return BAD
            val expiry = ((raw[0].toInt() and 0xFF) shl 24) or ((raw[1].toInt() and 0xFF) shl 16) or
                ((raw[2].toInt() and 0xFF) shl 8) or (raw[3].toInt() and 0xFF)
            val sig = raw.copyOfRange(4, 68)
            val msg = ("SH1|" + deviceId(ctx) + "|" + expiry).toByteArray(Charsets.UTF_8)
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(PUB, Base64.DEFAULT)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(pub)
            v.update(msg)
            if (!v.verify(derFromRaw(sig))) return BAD
            if (expiry != 0 && todayInt() > expiry) EXPIRED else OK
        } catch (e: Throwable) {
            BAD
        }
    }

    /** True when this phone has a valid code and has not been blocked. */
    fun ok(ctx: Context): Boolean {
        cache?.let { return it }
        val p = prefs(ctx)
        val good = !p.getBoolean("rev", false) && verify(ctx, p.getString("code", "") ?: "") == OK
        cache = good
        return good
    }

    fun blocked(ctx: Context): Boolean = prefs(ctx).getBoolean("rev", false)

    /** Checks the code and keeps it on this phone when it is good. Returns OK, BAD or EXPIRED. */
    fun activate(ctx: Context, code: String): Int {
        val r = verify(ctx, code)
        if (r == OK) {
            prefs(ctx).edit().putString("code", code.trim()).apply()
            cache = null
        }
        return r
    }

    /**
     * Reads "revoked" (a list of Device IDs) from config.json on GitHub. If this phone is in the list it is locked.
     * Offline or on an error nothing changes. [onBlocked] runs only when the phone was open and has just been blocked.
     */
    fun refreshRevoked(ctx: Context, force: Boolean, onBlocked: () -> Unit) {
        val now = System.currentTimeMillis()
        if (!force && now - lastRefresh < 5 * 60 * 1000L) return
        lastRefresh = now
        val app = ctx.applicationContext
        Thread {
            try {
                val c = URL("https://raw.githubusercontent.com/$UPDATE_REPO/main/config.json?t=$now").openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val body = c.inputStream.bufferedReader().readText()
                val arr = JSONObject(body).optJSONArray("revoked")
                var hit = false
                if (arr != null) {
                    val me = deviceId(app)
                    for (i in 0 until arr.length()) if (arr.optString(i).trim().uppercase(Locale.US) == me) hit = true
                }
                val was = prefs(app).getBoolean("rev", false)
                if (hit != was) {
                    prefs(app).edit().putBoolean("rev", hit).apply()
                    cache = null
                }
                if (hit && !was) onBlocked()
            } catch (e: Throwable) {
            }
        }.start()
    }
}

/** What the lock screen page can call. It only exists while the phone is not activated. */
class LockBridge(private val act: MainActivity) {
    @JavascriptInterface
    fun deviceId(): String = Lic.deviceId(act)

    @JavascriptInterface
    fun state(): String = if (Lic.blocked(act)) "blocked" else "locked"

    @JavascriptInterface
    fun copy(text: String) {
        try {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Sensi Helper", text))
        } catch (e: Throwable) {}
    }

    /** "ok", "bad", "expired" or "blocked". On "ok" the app opens by itself. */
    @JavascriptInterface
    fun activate(code: String): String {
        if (Lic.blocked(act)) return "blocked"
        return when (Lic.activate(act, code)) {
            Lic.OK -> { act.runOnUiThread { act.startApp() }; "ok" }
            Lic.EXPIRED -> "expired"
            else -> "bad"
        }
    }
}
