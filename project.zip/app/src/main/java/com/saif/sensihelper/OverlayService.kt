package com.saif.sensihelper

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import org.json.JSONObject

/** Draws the crosshair on top of other apps (needs "Display over other apps"). */
class OverlayService : Service() {

    private var view: View? = null
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("x")?.let { show(it) }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("xh", "Crosshair", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "xh")
            .setContentTitle("Crosshair is on")
            .setContentText("Tap to open Sensi Helper")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun show(json: String) {
        hide()
        val v = CrosshairView(this, JSONObject(json))
        val px = (100 * resources.displayMetrics.density).toInt()   // 100 units = 100dp
        val lp = WindowManager.LayoutParams(
            px, px,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.CENTER
        wm.addView(v, lp)
        view = v
    }

    private fun hide() {
        view?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        view = null
    }

    override fun onDestroy() {
        hide()
        super.onDestroy()
    }
}

/** Same geometry as the preview in the app (100 x 100 unit box). */
class CrosshairView(ctx: Context, private val o: JSONObject) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val u = width / 100f
        val style = o.optString("style", "both")
        val size = o.optDouble("size", 10.0).toFloat()
        val thick = o.optDouble("thick", 2.0).toFloat()
        val gap = o.optDouble("gap", 4.0).toFloat()
        val alpha = (o.optInt("op", 100) * 2.55f).toInt().coerceIn(0, 255)
        val color = try { Color.parseColor(o.optString("color", "#27f0d6")) } catch (e: Throwable) { Color.CYAN }

        p.color = color
        p.alpha = alpha
        p.strokeWidth = thick * u
        p.style = Paint.Style.STROKE

        if (style == "cross" || style == "both") {
            c.drawLine(50 * u, (50 - gap - size) * u, 50 * u, (50 - gap) * u, p)
            c.drawLine(50 * u, (50 + gap) * u, 50 * u, (50 + gap + size) * u, p)
            c.drawLine((50 - gap - size) * u, 50 * u, (50 - gap) * u, 50 * u, p)
            c.drawLine((50 + gap) * u, 50 * u, (50 + gap + size) * u, 50 * u, p)
        }
        if (style == "dot" || style == "both") {
            p.style = Paint.Style.FILL
            c.drawCircle(50 * u, 50 * u, maxOf(1.5f, thick * 0.9f) * u, p)
            p.style = Paint.Style.STROKE
        }
        if (style == "ring") {
            c.drawCircle(50 * u, 50 * u, (gap + size / 2) * u, p)
        }
    }
}
