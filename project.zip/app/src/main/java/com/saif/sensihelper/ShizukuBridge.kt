package com.saif.sensihelper

import android.app.Activity
import android.content.pm.PackageManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/** JS name: window.Native  (see MainActivity line in SETUP.md) */
class ShizukuBridge(private val act: Activity, private val web: WebView) {

    // Only these command prefixes may run. Keeps the WebView from becoming a free shell.
    private val allowedPrefixes = listOf(
        "settings put ", "settings delete ", "settings get ",
        "cmd game ", "cmd notification set_dnd ", "cmd package compile ",
        "cmd deviceidle whitelist ", "am kill-all", "am force-stop ",
        "wm size", "wm density", "getprop ", "dumpsys battery", "dumpsys thermalservice",
        "cmd netpolicy set restrict-background ", "svc bluetooth ",
        "cmd power set-fixed-performance-mode-enabled ", "cmd package trim-caches "
    )
    private val bad = Regex("[`\$|&<>\\n]")

    private fun allowed(cmd: String) = cmd.split(';').map { it.trim() }.filter { it.isNotEmpty() }
        .all { s -> allowedPrefixes.any { s.startsWith(it) } && !bad.containsMatchIn(s) }

    private val shizukuPkg = "moe.shizuku.privileged.api"

    private fun installed() = try { act.packageManager.getPackageInfo(shizukuPkg, 0); true } catch (e: Throwable) { false }

    private var lastAsk = 0L
    private var lastErr = "-"

    /** Ask the Shizuku app to (re)send its binder. Needed when this app was already running before Shizuku started. */
    private fun askBinder() {
        val now = System.currentTimeMillis()
        if (now - lastAsk < 3000) return
        lastAsk = now
        try {
            val c = Class.forName("rikka.shizuku.ShizukuProvider")
            val m = c.methods.firstOrNull { it.name.startsWith("requestBinderForNonProvider") }
            if (m == null) lastErr = "requestBinder method not found" else m.invoke(null, act.applicationContext)
        } catch (e: Throwable) { lastErr = e.toString() }
    }

    /** ok | no_permission | not_running | not_installed */
    @JavascriptInterface
    fun status(): String {
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!ping) {
            askBinder()
            return if (installed()) "not_running" else "not_installed"
        }
        return try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "ok" else "no_permission"
        } catch (e: Throwable) { "not_running" }
    }

    /** Returns a short result text so the UI can show what happened. */
    @JavascriptInterface
    fun requestPermission(): String = try {
        if (!Shizuku.pingBinder()) { askBinder(); "No connection to Shizuku yet. Fully close and reopen this app." }
        else { Shizuku.requestPermission(1001); "Permission popup requested" }
    } catch (e: Throwable) { "Error: " + e }

    /** Plain-text connection report for the Tweaks tab. */
    @JavascriptInterface
    fun diag(): String {
        val sb = StringBuilder()
        sb.append("this app: ").append(act.packageName).append('\n')
        try { sb.append("Shizuku app: ").append(act.packageManager.getPackageInfo(shizukuPkg, 0).versionName).append('\n') }
        catch (e: Throwable) { sb.append("Shizuku app: not found\n") }
        try { sb.append("binder: ").append(Shizuku.pingBinder()).append('\n') } catch (e: Throwable) { sb.append("binder: error ").append(e).append('\n') }
        try { sb.append("server: v").append(Shizuku.getVersion()).append(" uid ").append(Shizuku.getUid()).append('\n') }
        catch (e: Throwable) { sb.append("server: not reachable\n") }
        try { sb.append("permission: ").append(if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "granted" else "not granted").append('\n') }
        catch (e: Throwable) { sb.append("permission: unknown\n") }
        val prov = try { act.packageManager.resolveContentProvider(act.packageName + ".shizuku", 0) } catch (e: Throwable) { null }
        sb.append("provider: ").append(if (prov != null) "registered" else "MISSING").append('\n')
        sb.append("last error: ").append(lastErr)
        return sb.toString()
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread { act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) } }
    }

    /** Only https links (used for the Get Shizuku button). */
    @JavascriptInterface
    fun openUrl(url: String) {
        if (!url.startsWith("https://")) return
        act.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    /** Async: result comes back through window.onNative(id, output). */
    @JavascriptInterface
    fun run(id: Int, cmd: String) {
        thread {
            val out = if (status() != "ok") "Shizuku not ready"
            else if (!allowed(cmd)) "Blocked: command not in allow-list"
            else try { exec(cmd) } catch (t: Throwable) { "Error: ${t.message}" }
            act.runOnUiThread {
                web.evaluateJavascript("window.onNative($id,${JSONObject.quote(out)})", null)
            }
        }
    }

    private fun exec(cmd: String): String {
        // Shizuku.newProcess is private since API 13 -> reflection (widely used, works fine)
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim().ifEmpty { "done" }
    }
}
