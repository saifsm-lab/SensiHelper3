package com.saif.sensihelper

import android.app.Activity
import android.content.pm.PackageManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/** JS name: window.Native  (see MainActivity line in SETUP.md) */
class ShizukuBridge(private val act: Activity, private val web: WebView) {

    // Only these command prefixes may run. Keeps the WebView from becoming a free shell.
    private val allowedPrefixes = listOf(
        "settings put ", "settings delete ", "settings get ",
        "cmd game ", "cmd notification set_dnd ", "cmd package compile ",
        "cmd deviceidle whitelist ", "am kill-all", "am force-stop ",
        "wm size", "wm density", "getprop ", "dumpsys battery", "dumpsys thermalservice",
        "cmd netpolicy set restrict-background ", "svc bluetooth ",
        "cmd power set-fixed-performance-mode-enabled ", "cmd package trim-caches "
    )
    private val bad = Regex("[`\$|&<>\\n]")

    private fun allowed(cmd: String) = cmd.split(';').map { it.trim() }.filter { it.isNotEmpty() }
        .all { s -> allowedPrefixes.any { s.startsWith(it) } && !bad.containsMatchIn(s) }

    private val shizukuPkg = "moe.shizuku.privileged.api"

    private fun installed() = try { act.packageManager.getPackageInfo(shizukuPkg, 0); true } catch (e: Throwable) { false }

    /** ok | no_permission | not_running | not_installed */
    @JavascriptInterface
    fun status(): String = try {
        when {
            !Shizuku.pingBinder() -> if (installed()) "not_running" else "not_installed"
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> "ok"
            else -> "no_permission"
        }
    } catch (t: Throwable) { if (installed()) "not_running" else "not_installed" }

    @JavascriptInterface
    fun requestPermission() { try { Shizuku.requestPermission(1001) } catch (e: Throwable) {} }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
    }

    /** Only https links (used for the Get Shizuku button). */
    @JavascriptInterface
    fun openUrl(url: String) {
        if (!url.startsWith("https://")) return
        act.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    /** Async: result comes back through window.onNative(id, output). */
    @JavascriptInterface
    fun run(id: Int, cmd: String) {
        thread {
            val out = if (status() != "ok") "Shizuku not ready"
            else if (!allowed(cmd)) "Blocked: command not in allow-list"
            else try { exec(cmd) } catch (t: Throwable) { "Error: ${t.message}" }
            act.runOnUiThread {
                web.evaluateJavascript("window.onNative($id,${JSONObject.quote(out)})", null)
            }
        }
    }

    private fun exec(cmd: String): String {
        // Shizuku.newProcess is private since API 13 -> reflection (widely used, works fine)
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim().ifEmpty { "done" }
    }
}
