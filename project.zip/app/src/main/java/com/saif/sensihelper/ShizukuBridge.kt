package com.saif.sensihelper

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/** JS name: window.Native  (see MainActivity line in SETUP.md) */
class ShizukuBridge(private val act: Activity, private val web: WebView) {

    // Only these command prefixes may run. Keeps the WebView from becoming a free shell.
    private val allowedPrefixes = listOf(
        "settings put ", "settings delete ", "settings get ",
        "cmd game ", "cmd notification set_dnd ", "cmd package compile ",
        "cmd deviceidle whitelist ", "am kill-all", "am force-stop ",
        "wm size", "wm density", "getprop ", "dumpsys battery", "dumpsys thermalservice",
        "cmd netpolicy set restrict-background ", "svc bluetooth ",
        "cmd power set-fixed-performance-mode-enabled ", "cmd package trim-caches "
    )
    private val exactCommands = setOf("cat /proc/meminfo", "sm idle-maint run")
    private val bad = Regex("[`\$|&<>\\n]")

    private fun allowed(cmd: String) = cmd.split(';').map { it.trim() }.filter { it.isNotEmpty() }
        .all { s -> (s in exactCommands || allowedPrefixes.any { s.startsWith(it) }) && !bad.containsMatchIn(s) }

    private val shizukuPkg = "moe.shizuku.privileged.api"

    private fun installed() = try { act.packageManager.getPackageInfo(shizukuPkg, 0); true } catch (e: Throwable) { false }

    private var lastAsk = 0L
    private var lastErr = "-"

    /** Ask the Shizuku app to (re)send its binder. Needed when this app was already running before Shizuku started. */
    private fun askBinder() {
        val now = System.currentTimeMillis()
        if (now - lastAsk < 3000) return
        lastAsk = now
        try {
            val c = Class.forName("rikka.shizuku.ShizukuProvider")
            val m = c.methods.firstOrNull { it.name.startsWith("requestBinderForNonProvider") }
            if (m == null) lastErr = "requestBinder method not found"
            else lastErr = "requestBinder returned " + m.invoke(null, act.applicationContext)
        } catch (e: Throwable) { lastErr = (e.cause ?: e).toString() }
    }

    /** ok | no_permission | not_running | not_installed */
    @JavascriptInterface
    fun status(): String {
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        if (!ping) {
            askBinder()
            return if (installed()) "not_running" else "not_installed"
        }
        return try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "ok" else "no_permission"
        } catch (e: Throwable) { "not_running" }
    }

    /** Returns a short result text so the UI can show what happened. */
    @JavascriptInterface
    fun requestPermission(): String = try {
        if (!Shizuku.pingBinder()) { askBinder(); "No connection to Shizuku yet. Fully close and reopen this app." }
        else { Shizuku.requestPermission(1001); "Permission popup requested" }
    } catch (e: Throwable) { "Error: " + e }

    /** Plain-text connection report for the Tweaks tab. */
    @JavascriptInterface
    fun diag(): String {
        val sb = StringBuilder()
        sb.append("this app: ").append(act.packageName).append('\n')
        try { sb.append("Shizuku app: ").append(act.packageManager.getPackageInfo(shizukuPkg, 0).versionName).append('\n') }
        catch (e: Throwable) { sb.append("Shizuku app: not found\n") }
        try { sb.append("binder: ").append(Shizuku.pingBinder()).append('\n') } catch (e: Throwable) { sb.append("binder: error ").append(e).append('\n') }
        try { sb.append("server: v").append(Shizuku.getVersion()).append(" uid ").append(Shizuku.getUid()).append('\n') }
        catch (e: Throwable) { sb.append("server: not reachable\n") }
        try { sb.append("permission: ").append(if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "granted" else "not granted").append('\n') }
        catch (e: Throwable) { sb.append("permission: unknown\n") }
        sb.append("Android: ").append(Build.VERSION.SDK_INT).append('\n')
        try { sb.append("Shizuku code: ").append(act.packageManager.getPackageInfo(shizukuPkg, 0).versionCode).append('\n') } catch (e: Throwable) {}
        val mgr = try { act.packageManager.resolveContentProvider(shizukuPkg + ".shizuku", 0) } catch (e: Throwable) { null }
        sb.append("manager provider: ").append(if (mgr != null) "found" else "NOT FOUND").append('\n')
        val prov = try { act.packageManager.resolveContentProvider(act.packageName + ".shizuku", 0) } catch (e: Throwable) { null }
        sb.append("provider: ").append(if (prov != null) "registered" else "MISSING").append('\n')
        sb.append("last error: ").append(lastErr)
        return sb.toString()
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread { act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) } }
    }

    @JavascriptInterface
    fun appBuild(): Int = com.saif.sensihelper.appBuild(act)

    @JavascriptInterface
    fun share(text: String) {
        act.runOnUiThread {
            val i = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain")
                .putExtra(android.content.Intent.EXTRA_TEXT, text)
            act.startActivity(android.content.Intent.createChooser(i, "Share Sensi Helper"))
        }
    }

    @JavascriptInterface
    fun isInstalled(pkg: String): Boolean {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return false
        return try { act.packageManager.getPackageInfo(pkg, 0); true } catch (e: Throwable) { false }
    }

    /** Counts gyroscope updates for 2 seconds. Result comes back through window.onNative(id, text). */
    @JavascriptInterface
    fun measureGyro(id: Int) {
        thread {
            val text = try {
                val sm = act.getSystemService(Context.SENSOR_SERVICE) as SensorManager
                val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
                if (g == null) "This phone has no gyroscope sensor."
                else {
                    var n = 0
                    val l = object : SensorEventListener {
                        override fun onSensorChanged(e: SensorEvent) { n++ }
                        override fun onAccuracyChanged(s: Sensor?, a: Int) {}
                    }
                    val t0 = System.nanoTime()
                    sm.registerListener(l, g, SensorManager.SENSOR_DELAY_FASTEST)
                    Thread.sleep(2000)
                    sm.unregisterListener(l)
                    val hz = n / ((System.nanoTime() - t0) / 1e9)
                    val max = if (g.minDelay > 0) " (sensor max " + (1_000_000 / g.minDelay) + " Hz)" else ""
                    "Gyroscope updates at " + hz.toInt() + " Hz" + max + ". 100 Hz or more is smooth. If it is much lower, aim lag is from the sensor, not the game."
                }
            } catch (e: Throwable) { "Could not read the gyroscope: " + e }
            act.runOnUiThread { web.evaluateJavascript("window.onNative($id,${JSONObject.quote(text)})", null) }
        }
    }

    /** Only https links (used for the Get Shizuku button). */
    @JavascriptInterface
    fun openUrl(url: String) {
        if (!(url.startsWith("https://") || url.startsWith("mailto:"))) return
        act.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
    }

    /** Async: result comes back through window.onNative(id, output). */
    @JavascriptInterface
    fun run(id: Int, cmd: String) {
        thread {
            val out = if (status() != "ok") "Shizuku not ready"
            else if (!allowed(cmd)) "Blocked: command not in allow-list"
            else try { exec(cmd) } catch (t: Throwable) { "Error: ${t.message}" }
            act.runOnUiThread {
                web.evaluateJavascript("window.onNative($id,${JSONObject.quote(out)})", null)
            }
        }
    }

    private fun exec(cmd: String): String {
        // Shizuku.newProcess is private since API 13 -> reflection (widely used, works fine)
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText() + p.errorStream.bufferedReader().readText()
        p.waitFor()
        return out.trim().ifEmpty { "done" }
    }
}
