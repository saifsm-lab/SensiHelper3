package com.saif.sensihelper

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** GitHub repo that publishes the APK releases. Change this if your repo name is different. */
const val UPDATE_REPO = "saifsm-lab/SensiHelper3"

@Suppress("DEPRECATION")
fun appBuild(ctx: Context): Int =
    try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode } catch (e: Throwable) { 0 }

/** Runs in the background about every 12 hours and shows a notification when a newer release exists. */
class UpdateWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        try {
            val c = URL("https://api.github.com/repos/$UPDATE_REPO/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.connectTimeout = 15000
            c.readTimeout = 15000
            if (c.responseCode == 404) return Result.success()      // no release yet
            if (c.responseCode != 200) return Result.retry()
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val latest = Regex("(\\d+)").find(j.optString("tag_name"))?.value?.toIntOrNull() ?: return Result.success()
            val prefs = ctx.getSharedPreferences("upd", Context.MODE_PRIVATE)
            if (latest > appBuild(ctx) && prefs.getInt("notified", 0) < latest) {
                var url = j.optString("html_url")
                val assets = j.optJSONArray("assets")
                if (assets != null) for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
                }
                notifyUpdate(latest, j.optString("body"), url)
                prefs.edit().putInt("notified", latest).apply()
            }
            return Result.success()
        } catch (e: Throwable) {
            return Result.retry()
        }
    }

    private fun notifyUpdate(build: Int, notes: String, url: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("upd", "App updates", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(Intent.ACTION_VIEW, Uri.parse(url)), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = notes.trim().ifEmpty { "Tap to download the new version." }
        val n = Notification.Builder(ctx, "upd")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Sensi Helper update (build $build)")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(2001, n)
    }
}
