package com.saif.sensihelper

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    var dlId: Long = -1L

    /** After the update APK finishes downloading, open the installer. */
    private val dlDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val id = i?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id < 0 || id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri = dm.getUriForDownloadedFile(id)
            if (uri == null) {
                Toast.makeText(this@MainActivity, "Download failed. Try again.", Toast.LENGTH_LONG).show()
                return
            }
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Throwable) {
                Toast.makeText(this@MainActivity, "Open the downloaded file from Downloads to install", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            // Links (Telegram, Play Store...) open outside the app
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file:")) return false
                try {
                    val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, request.url)
                    startActivity(i)
                } catch (e: Throwable) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // "Upload screenshot" button
            override fun onShowFileChooser(
                webView: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), 1); true
                } catch (e: Throwable) { fileCb = null; false }
            }
        }

        web.addJavascriptInterface(ShizukuBridge(this, web), "Native")
        web.addJavascriptInterface(SensiNative(this), "SensiNative")
        web.loadUrl("file:///android_asset/index.html")

        val dlFilter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, dlFilter, Context.RECEIVER_EXPORTED)
        else registerReceiver(dlDone, dlFilter)

        // Check for a new release about every 12 hours, even when the app is closed
        val req = PeriodicWorkRequest.Builder(UpdateWorker::class.java, 12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("update-check", ExistingPeriodicWorkPolicy.KEEP, req)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onDestroy() {
        try { unregisterReceiver(dlDone) } catch (e: Throwable) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}

/** window.SensiNative used by the crosshair designer and the game launcher */
class SensiNative(private val act: Activity) {

    /** Installed build number (same number as the GitHub release tag build-N). */
    @JavascriptInterface
    fun build(): Int = appBuild(act)

    @JavascriptInterface
    fun showCrosshair(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, OverlayService::class.java).putExtra("x", json))
            }
        }
    }

    @JavascriptInterface
    fun hideCrosshair() {
        act.runOnUiThread { act.stopService(Intent(act, OverlayService::class.java)) }
    }

    @JavascriptInterface
    fun showPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, PanelService::class.java).putExtra("p", json))
            }
        }
    }

    @JavascriptInterface
    fun autoPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else if (!hasUsageAccess(act)) {
                Toast.makeText(act, "Turn on Usage access for Sensi Helper, then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } else {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", true)
                )
                Toast.makeText(act, "Auto panel is on. Open your game.", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Boost & launch: start the floating panel quietly (no permission pop-ups). */
    @JavascriptInterface
    fun boostPanel(json: String) {
        act.runOnUiThread {
            if (Settings.canDrawOverlays(act)) {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", hasUsageAccess(act))
                )
            }
        }
    }

    /** In-app update: download the release APK, then open the installer. */
    @JavascriptInterface
    fun downloadUpdate(url: String) {
        val ok = Regex("https://github\\.com/" + UPDATE_REPO.replace(".", "\\.") + "/releases/download/[A-Za-z0-9_.%/+-]+\\.apk").matches(url)
        if (!ok) return
        act.runOnUiThread {
            if (!act.packageManager.canRequestPackageInstalls()) {
                Toast.makeText(act, "Allow installs from Sensi Helper, then tap Update again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                )
                return@runOnUiThread
            }
            try {
                val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val req = DownloadManager.Request(Uri.parse(url))
                    .setTitle("Sensi Helper update")
                    .setDescription("Downloading the new version")
                    .setMimeType("application/vnd.android.package-archive")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(act, Environment.DIRECTORY_DOWNLOADS, "SensiHelper-update.apk")
                (act as? MainActivity)?.dlId = dm.enqueue(req)
                Toast.makeText(act, "Downloading update...", Toast.LENGTH_LONG).show()
            } catch (e: Throwable) {
                Toast.makeText(act, "Could not start the download", Toast.LENGTH_LONG).show()
            }
        }
    }

    @JavascriptInterface
    fun hidePanel() {
        act.runOnUiThread { act.stopService(Intent(act, PanelService::class.java)) }
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread {
            act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
        }
    }
}
