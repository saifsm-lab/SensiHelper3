package com.saif.sensihelper

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.graphics.Bitmap
import android.os.BatteryManager
import android.os.Bundle
import android.util.Base64
import androidx.core.graphics.drawable.toBitmap
import android.os.Environment
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    var dlId: Long = -1L

    private val uiH = android.os.Handler(android.os.Looper.getMainLooper())

    /** Sends the download progress to the page. st is "run", "done" or "fail". */
    fun pushUpd(pct: Int, st: String) {
        runOnUiThread {
            try { web.evaluateJavascript("window.onUpdProg&&window.onUpdProg(" + pct + ",'" + st + "')", null) } catch (e: Throwable) {}
        }
    }

    /** Checks the update download twice a second and reports the percent. */
    fun trackDownload(id: Long) {
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val tick = object : Runnable {
            override fun run() {
                if (id != dlId) return
                var next = true
                try {
                    dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                        if (c.moveToFirst()) {
                            val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            if (st == DownloadManager.STATUS_SUCCESSFUL) { pushUpd(100, "done"); next = false }
                            else if (st == DownloadManager.STATUS_FAILED) { pushUpd(0, "fail"); next = false }
                            else pushUpd(if (tot > 0) (got * 100 / tot).toInt() else 0, "run")
                        } else { pushUpd(0, "fail"); next = false }
                    }
                } catch (e: Throwable) {}
                if (next) uiH.postDelayed(this, 500)
            }
        }
        uiH.post(tick)
    }

    /** After the update APK finishes downloading, open the installer. */
    private val dlDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val id = i?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id < 0 || id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri = dm.getUriForDownloadedFile(id)
            if (uri == null) {
                Toast.makeText(this@MainActivity, "Download failed. Try again.", Toast.LENGTH_LONG).show()
                return
            }
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Throwable) {
                Toast.makeText(this@MainActivity, "Open the downloaded file from Downloads to install", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            // Links (Telegram, Play Store...) open outside the app
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file:")) return false
                try {
                    val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, request.url)
                    startActivity(i)
                } catch (e: Throwable) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // "Upload screenshot" button
            override fun onShowFileChooser(
                webView: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), 1); true
                } catch (e: Throwable) { fileCb = null; false }
            }
        }

        web.addJavascriptInterface(ShizukuBridge(this, web), "Native")
        web.addJavascriptInterface(SensiNative(this), "SensiNative")
        web.loadUrl("file:///android_asset/index.html")

        val dlFilter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, dlFilter, Context.RECEIVER_EXPORTED)
        else registerReceiver(dlDone, dlFilter)

        // Check for a new release about every 12 hours, even when the app is closed
        val req = PeriodicWorkRequest.Builder(UpdateWorker::class.java, 12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("update-check", ExistingPeriodicWorkPolicy.KEEP, req)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onResume() {
        super.onResume()
        fixScreenIfStuck()
    }

    /** If the screen was left stretched (phone restarted or app killed), put it back when no game is running. */
    private fun fixScreenIfStuck() {
        val p = getSharedPreferences("gs", Context.MODE_PRIVATE)
        if (!p.getBoolean("wm_dirty", false)) return
        val ig = p.getBoolean("ingame", false) && System.currentTimeMillis() - p.getLong("ingameAt", 0L) < 40000L
        if (ig) return
        Thread {
            for (i in 0 until 6) {
                if (shizukuSh(restoreScreenCmd(p))) { p.edit().putBoolean("wm_dirty", false).apply(); break }
                try { Thread.sleep(2500) } catch (e: Throwable) {}
            }
        }.start()
    }

    override fun onDestroy() {
        try { unregisterReceiver(dlDone) } catch (e: Throwable) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}

/** window.SensiNative used by the crosshair designer and the game launcher */
class SensiNative(private val act: Activity) {

    /** Installed build number (same number as the GitHub release tag build-N). */
    @JavascriptInterface
    fun build(): Int = appBuild(act)

    @JavascriptInterface
    fun showCrosshair(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, OverlayService::class.java).putExtra("x", json))
            }
        }
    }

    @JavascriptInterface
    fun hideCrosshair() {
        act.runOnUiThread { act.stopService(Intent(act, OverlayService::class.java)) }
    }

    @JavascriptInterface
    fun showPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, PanelService::class.java).putExtra("p", json))
            }
        }
    }

    @JavascriptInterface
    fun autoPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else if (!hasUsageAccess(act)) {
                Toast.makeText(act, "Turn on Usage access for Sensi Helper, then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } else {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", true)
                )
                Toast.makeText(act, "Auto panel is on. Open your game.", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Boost & launch: start the floating panel quietly (no permission pop-ups). */
    @JavascriptInterface
    fun boostPanel(json: String) {
        act.runOnUiThread {
            if (Settings.canDrawOverlays(act)) {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", hasUsageAccess(act))
                )
            }
        }
    }

    /** In-app update: download the release APK, then open the installer. */
    @JavascriptInterface
    fun downloadUpdate(url: String) {
        val ok = Regex("https://github\\.com/" + UPDATE_REPO.replace(".", "\\.") + "/releases/download/[A-Za-z0-9_.%/+-]+\\.apk").matches(url)
        if (!ok) return
        act.runOnUiThread {
            if (!act.packageManager.canRequestPackageInstalls()) {
                Toast.makeText(act, "Allow installs from Sensi Helper, then tap Update again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                )
                return@runOnUiThread
            }
            try {
                val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val req = DownloadManager.Request(Uri.parse(url))
                    .setTitle("Sensi Helper update")
                    .setDescription("Downloading the new version")
                    .setMimeType("application/vnd.android.package-archive")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(act, Environment.DIRECTORY_DOWNLOADS, "SensiHelper-update.apk")
                (act as? MainActivity)?.let { it.dlId = dm.enqueue(req); it.trackDownload(it.dlId) }
                Toast.makeText(act, "Downloading update...", Toast.LENGTH_LONG).show()
            } catch (e: Throwable) {
                Toast.makeText(act, "Could not start the download", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Live phone status for the Game Space page: {"temp":31.5,"bat":76,"free":2310,"total":5800} */
    @JavascriptInterface
    fun stats(): String = try {
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
        val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        "{\"temp\":" + t + ",\"bat\":" + pct + ",\"free\":" + (mi.availMem / 1048576L) + ",\"total\":" + (mi.totalMem / 1048576L) + "}"
    } catch (e: Throwable) { "{}" }


    /** Phone info for the monitor, battery and graphics screens. */
    @JavascriptInterface
    fun info(): String = try {
        val o = org.json.JSONObject()
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        o.put("bat", if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1)
        o.put("temp", (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0)
        o.put("volt", (i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000.0)
        o.put("health", i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0)
        o.put("plugged", (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0)
        val bm = act.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        o.put("cur", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
        val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        o.put("ramTotal", mi.totalMem / 1048576L)
        o.put("ramFree", mi.availMem / 1048576L)
        val sf = android.os.StatFs(Environment.getDataDirectory().path)
        o.put("stTotal", sf.totalBytes / 1048576L)
        o.put("stFree", sf.availableBytes / 1048576L)
        o.put("model", Build.MODEL)
        o.put("android", Build.VERSION.RELEASE)
        o.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "")
        var khz = 0L
        for (c in 0..15) {
            try {
                val v = java.io.File("/sys/devices/system/cpu/cpu$c/cpufreq/scaling_cur_freq").readText().trim().toLong()
                if (v > khz) khz = v
            } catch (e: Throwable) {}
        }
        o.put("cpuKhz", khz)
        @Suppress("DEPRECATION")
        val d = act.windowManager.defaultDisplay
        var mx = d.refreshRate
        for (m in d.supportedModes) if (m.refreshRate > mx) mx = m.refreshRate
        o.put("hz", d.refreshRate.toDouble())
        o.put("maxHz", mx.toDouble())
        val dm2 = android.util.DisplayMetrics()
        d.getRealMetrics(dm2)
        val lo2 = minOf(dm2.widthPixels, dm2.heightPixels)
        if (lo2 > 0) o.put("aspect", maxOf(dm2.widthPixels, dm2.heightPixels).toDouble() / lo2.toDouble())
        o.toString()
    } catch (e: Throwable) { "{}" }

    /** Per-game profile: {"hz":90,"res":85,"dnd":true,"ram":true,"mon":true,"guard":false} */
    @JavascriptInterface
    fun setProfile(pkg: String, json: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        try {
            val o = org.json.JSONObject(json)
            act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit()
                .putString("prof_$pkg", o.toString())
                .putInt("tex_$pkg", o.optInt("res", 100).coerceIn(30, 100))
                .putInt("str_$pkg", o.optInt("str", 0).let { if (it in 105..150) it else 0 })
                .apply()
        } catch (ex: Throwable) {}
    }

    /** Saves the screen-resolution percent to use while this game is in front (100 = off). */
    @JavascriptInterface
    fun setTex(pkg: String, pct: Int) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit().putInt("tex_$pkg", pct.coerceIn(30, 100)).apply()
    }

    /** Puts the screen size and density back to what the user had (used by "Reset screen now"). */
    @JavascriptInterface
    fun fixScreen(): Boolean {
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        val ok = shizukuSh(restoreScreenCmd(p))
        if (ok) p.edit().putBoolean("wm_dirty", false).apply()
        return ok
    }

    /** Shows a stretched screen for 6 seconds, then puts everything back. ratio: 110 to 140 (1.10x to 1.40x). */
    @JavascriptInterface
    fun previewStretch(ratio: Int) {
        if (ratio < 105 || ratio > 150) return
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        Thread {
            val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
            if (sz == null) return@Thread
            val a = sz.groupValues[1].toInt()
            val b = sz.groupValues[2].toInt()
            val lo = minOf(a, b)
            val hi = maxOf(a, b)
            val want = hi * ratio / 100
            if (want <= hi || want > hi * 2) return@Thread
            if (!p.getBoolean("wm_dirty", false)) {
                p.edit()
                    .putString("user_size", Regex("Override size:\\s*(\\d+x\\d+)").find(shizukuOut("wm size"))?.groupValues?.get(1) ?: "")
                    .putString("user_density", Regex("Override density:\\s*(\\d+)").find(shizukuOut("wm density"))?.groupValues?.get(1) ?: "")
                    .apply()
            }
            p.edit().putBoolean("wm_dirty", true).apply()
            shizukuSh(if (a <= b) "wm size ${lo}x${want}" else "wm size ${want}x${lo}")
            try { Thread.sleep(6000) } catch (e: Throwable) {}
            if (shizukuSh(restoreScreenCmd(p))) p.edit().putBoolean("wm_dirty", false).apply()
        }.start()
    }

    @JavascriptInterface
    fun setLandscape(on: Boolean) {
        act.runOnUiThread {
            act.requestedOrientation = if (on) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    @JavascriptInterface
    fun appLabel(pkg: String): String {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return pkg
        return try {
            act.packageManager.getApplicationLabel(act.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Throwable) { pkg }
    }

    /** The installed game's real icon as a data: URL (empty if not installed). */
    @JavascriptInterface
    fun appIcon(pkg: String): String {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return ""
        return try {
            val bmp: Bitmap = act.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            val bos = java.io.ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) { "" }
    }

    /** Game Space settings shared with the in-game assistant: performance mode 0..3 and auto-apply. */
    @JavascriptInterface
    fun getGs(): String {
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        return "{\"mode\":" + p.getInt("mode", 2) + ",\"auto\":" + p.getBoolean("auto", false) + "}"
    }

    @JavascriptInterface
    fun setGs(mode: Int, auto: Boolean) {
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit()
            .putInt("mode", mode.coerceIn(0, 3)).putBoolean("auto", auto).apply()
    }

    @JavascriptInterface
    fun hidePanel() {
        act.runOnUiThread { act.stopService(Intent(act, PanelService::class.java)) }
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread {
            act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
        }
    }
}
