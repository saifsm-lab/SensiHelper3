package com.saif.sensihelper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.*
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            // Links (Telegram, Play Store...) open outside the app
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file:")) return false
                try {
                    val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, request.url)
                    startActivity(i)
                } catch (e: Throwable) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // "Upload screenshot" button
            override fun onShowFileChooser(
                webView: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), 1); true
                } catch (e: Throwable) { fileCb = null; false }
            }
        }

        web.addJavascriptInterface(ShizukuBridge(this, web), "Native")
        web.addJavascriptInterface(SensiNative(this), "SensiNative")
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}

/** window.SensiNative used by the crosshair designer and the game launcher */
class SensiNative(private val act: Activity) {

    @JavascriptInterface
    fun showCrosshair(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, OverlayService::class.java).putExtra("x", json))
            }
        }
    }

    @JavascriptInterface
    fun hideCrosshair() {
        act.runOnUiThread { act.stopService(Intent(act, OverlayService::class.java)) }
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread {
            act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
        }
    }
}
