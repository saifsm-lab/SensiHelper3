package com.saif.sensihelper

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.graphics.Bitmap
import android.os.BatteryManager
import android.os.Bundle
import android.util.Base64
import androidx.core.graphics.drawable.toBitmap
import android.os.Environment
import android.provider.Settings
import android.webkit.*
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var fileCb: ValueCallback<Array<Uri>>? = null
    var dlId: Long = -1L

    private val uiH = android.os.Handler(android.os.Looper.getMainLooper())

    /** Sends the download progress to the page. st is "run", "done" or "fail". */
    fun pushUpd(pct: Int, st: String) {
        runOnUiThread {
            try { web.evaluateJavascript("window.onUpdProg&&window.onUpdProg(" + pct + ",'" + st + "')", null) } catch (e: Throwable) {}
        }
    }

    /** Checks the update download twice a second and reports the percent. */
    fun trackDownload(id: Long) {
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val tick = object : Runnable {
            override fun run() {
                if (id != dlId) return
                var next = true
                try {
                    dm.query(DownloadManager.Query().setFilterById(id))?.use { c ->
                        if (c.moveToFirst()) {
                            val st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                            val got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                            val tot = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                            if (st == DownloadManager.STATUS_SUCCESSFUL) { pushUpd(100, "done"); next = false }
                            else if (st == DownloadManager.STATUS_FAILED) { pushUpd(0, "fail"); next = false }
                            else pushUpd(if (tot > 0) (got * 100 / tot).toInt() else 0, "run")
                        } else { pushUpd(0, "fail"); next = false }
                    }
                } catch (e: Throwable) {}
                if (next) uiH.postDelayed(this, 500)
            }
        }
        uiH.post(tick)
    }

    /** After the update APK finishes downloading, open the installer. */
    private val dlDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val id = i?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id < 0 || id != dlId) return
            val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val uri = dm.getUriForDownloadedFile(id)
            if (uri == null) {
                Toast.makeText(this@MainActivity, "Download failed. Try again.", Toast.LENGTH_LONG).show()
                return
            }
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW)
                        .setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Throwable) {
                Toast.makeText(this@MainActivity, "Open the downloaded file from Downloads to install", Toast.LENGTH_LONG).show()
            }
        }
    }

    private var appStarted = false

    /** Opens the real app. Only runs when this phone has a valid code; the app bridges exist only then. */
    fun startApp() {
        if (!Lic.ok(this)) { showLock(); return }
        if (!appStarted) {
            web.addJavascriptInterface(ShizukuBridge(this, web), "Native")
            web.addJavascriptInterface(SensiNative(this), "SensiNative")
            appStarted = true
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    /** Shows the activation screen and takes the app bridges away. */
    fun showLock() {
        if (appStarted) {
            try { web.removeJavascriptInterface("Native"); web.removeJavascriptInterface("SensiNative") } catch (e: Throwable) {}
            appStarted = false
            try { stopService(Intent(this, PanelService::class.java)) } catch (e: Throwable) {}
            try { stopService(Intent(this, OverlayService::class.java)) } catch (e: Throwable) {}
        }
        try { web.removeJavascriptInterface("SensiLock") } catch (e: Throwable) {}
        web.addJavascriptInterface(LockBridge(this), "SensiLock")
        web.loadUrl("file:///android_asset/lock.html")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Gs.ctx = applicationContext
        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
        }

        web.webViewClient = object : WebViewClient() {
            // Links (Telegram, Play Store...) open outside the app
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file:")) return false
                try {
                    val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, request.url)
                    startActivity(i)
                } catch (e: Throwable) {}
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            // "Upload screenshot" button
            override fun onShowFileChooser(
                webView: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(params!!.createIntent(), 1); true
                } catch (e: Throwable) { fileCb = null; false }
            }
        }

        // The app only opens on a phone with a valid activation code from the owner
        if (Lic.ok(this)) startApp() else showLock()
        Lic.refreshRevoked(this, true) { runOnUiThread { showLock() } }

        val dlFilter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, dlFilter, Context.RECEIVER_EXPORTED)
        else registerReceiver(dlDone, dlFilter)

        // Check for a new release about every 12 hours, even when the app is closed
        val req = PeriodicWorkRequest.Builder(UpdateWorker::class.java, 12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("update-check", ExistingPeriodicWorkPolicy.KEEP, req)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
    }

    override fun onResume() {
        super.onResume()
        if (appStarted && !Lic.ok(this)) showLock()
        Lic.refreshRevoked(this, false) { runOnUiThread { showLock() } }
        fixScreenIfStuck()
        restoreStuck()
    }

    /** If Do Not Disturb or the edge swipes were left changed (game closed, app killed), put them back. */
    private fun restoreStuck() {
        val p = getSharedPreferences("gs", Context.MODE_PRIVATE)
        val ig = p.getBoolean("ingame", false) && System.currentTimeMillis() - p.getLong("ingameAt", 0L) < 40000L
        if (ig) return
        val hadDnd = p.getBoolean("dnd_by_us", false) || p.getBoolean("hu_by_us", false)
        if (!hadDnd && !p.getBoolean("edge_dirty", false) && !p.getBoolean("cool_dirty", false) &&
            !p.getBoolean("bl_dirty", false) && !p.getBoolean("sat_dirty", false)) return
        Thread {
            for (i in 0 until 4) {
                val a = DndGuard.restore()
                val b = EdgeFix.restore() && CoolFx.restore() && BrightLock.restore() && SatFx.restore()
                if (a && b) {
                    if (hadDnd) runOnUiThread { Toast.makeText(this, "Notifications are back on", Toast.LENGTH_SHORT).show() }
                    break
                }
                try { Thread.sleep(2500) } catch (e: Throwable) {}
            }
        }.start()
    }

    /** If the screen was left stretched (phone restarted or app killed), put it back when no game is running. */
    private fun fixScreenIfStuck() {
        val p = getSharedPreferences("gs", Context.MODE_PRIVATE)
        if (!p.getBoolean("wm_dirty", false)) return
        val ig = p.getBoolean("ingame", false) && System.currentTimeMillis() - p.getLong("ingameAt", 0L) < 40000L
        if (ig) return
        Thread {
            for (i in 0 until 6) {
                if (shizukuSh(restoreScreenCmd(p))) { p.edit().putBoolean("wm_dirty", false).apply(); break }
                try { Thread.sleep(2500) } catch (e: Throwable) {}
            }
        }.start()
    }

    override fun onDestroy() {
        try { unregisterReceiver(dlDone) } catch (e: Throwable) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}

/** window.SensiNative used by the crosshair designer and the game launcher */
class SensiNative(private val act: Activity) {

    /** Installed build number (same number as the GitHub release tag build-N). */
    @JavascriptInterface
    fun build(): Int = appBuild(act)

    @JavascriptInterface
    fun showCrosshair(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, OverlayService::class.java).putExtra("x", json))
            }
        }
    }

    @JavascriptInterface
    fun hideCrosshair() {
        act.runOnUiThread { act.stopService(Intent(act, OverlayService::class.java)) }
    }

    @JavascriptInterface
    fun showPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Show again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else {
                act.startForegroundService(Intent(act, PanelService::class.java).putExtra("p", json))
            }
        }
    }

    @JavascriptInterface
    fun autoPanel(json: String) {
        act.runOnUiThread {
            if (!Settings.canDrawOverlays(act)) {
                Toast.makeText(act, "Allow \"Display over other apps\", then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                )
            } else if (!hasUsageAccess(act)) {
                Toast.makeText(act, "Turn on Usage access for Sensi Helper, then tap Auto again", Toast.LENGTH_LONG).show()
                act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } else {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", true)
                )
                Toast.makeText(act, "Auto panel is on. Open your game.", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Boost & launch: start the floating panel quietly (no permission pop-ups). */
    @JavascriptInterface
    fun boostPanel(json: String) {
        act.runOnUiThread {
            if (Settings.canDrawOverlays(act)) {
                act.startForegroundService(
                    Intent(act, PanelService::class.java).putExtra("p", json).putExtra("auto", hasUsageAccess(act))
                )
            }
        }
    }

    /** In-app update: download the release APK, then open the installer. */
    @JavascriptInterface
    fun downloadUpdate(url: String) {
        val ok = Regex("https://github\\.com/" + UPDATE_REPO.replace(".", "\\.") + "/releases/download/[A-Za-z0-9_.%/+-]+\\.apk").matches(url)
        if (!ok) return
        act.runOnUiThread {
            if (!act.packageManager.canRequestPackageInstalls()) {
                Toast.makeText(act, "Allow installs from Sensi Helper, then tap Update again", Toast.LENGTH_LONG).show()
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                )
                return@runOnUiThread
            }
            try {
                val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                val req = DownloadManager.Request(Uri.parse(url))
                    .setTitle("Sensi Helper update")
                    .setDescription("Downloading the new version")
                    .setMimeType("application/vnd.android.package-archive")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(act, Environment.DIRECTORY_DOWNLOADS, "SensiHelper-update.apk")
                (act as? MainActivity)?.let { it.dlId = dm.enqueue(req); it.trackDownload(it.dlId) }
                Toast.makeText(act, "Downloading update...", Toast.LENGTH_LONG).show()
            } catch (e: Throwable) {
                Toast.makeText(act, "Could not start the download", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Live phone status for the Game Space page: {"temp":31.5,"bat":76,"free":2310,"total":5800} */
    @JavascriptInterface
    fun stats(): String = try {
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1
        val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        "{\"temp\":" + t + ",\"bat\":" + pct + ",\"free\":" + (mi.availMem / 1048576L) + ",\"total\":" + (mi.totalMem / 1048576L) + "}"
    } catch (e: Throwable) { "{}" }


    /** Phone info for the monitor, battery and graphics screens. */
    @JavascriptInterface
    fun info(): String = try {
        val o = org.json.JSONObject()
        val i = act.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        o.put("bat", if (lvl >= 0 && sc > 0) lvl * 100 / sc else -1)
        o.put("temp", (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0)
        o.put("volt", (i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000.0)
        o.put("health", i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0)
        o.put("plugged", (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0)
        val bm = act.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        o.put("cur", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW))
        val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        o.put("ramTotal", mi.totalMem / 1048576L)
        o.put("ramFree", mi.availMem / 1048576L)
        val sf = android.os.StatFs(Environment.getDataDirectory().path)
        o.put("stTotal", sf.totalBytes / 1048576L)
        o.put("stFree", sf.availableBytes / 1048576L)
        o.put("model", Build.MODEL)
        o.put("android", Build.VERSION.RELEASE)
        o.put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "")
        var khz = 0L
        for (c in 0..15) {
            try {
                val v = java.io.File("/sys/devices/system/cpu/cpu$c/cpufreq/scaling_cur_freq").readText().trim().toLong()
                if (v > khz) khz = v
            } catch (e: Throwable) {}
        }
        o.put("cpuKhz", khz)
        @Suppress("DEPRECATION")
        val d = act.windowManager.defaultDisplay
        var mx = d.refreshRate
        for (m in d.supportedModes) if (m.refreshRate > mx) mx = m.refreshRate
        o.put("hz", d.refreshRate.toDouble())
        o.put("maxHz", mx.toDouble())
        val dm2 = android.util.DisplayMetrics()
        d.getRealMetrics(dm2)
        val lo2 = minOf(dm2.widthPixels, dm2.heightPixels)
        if (lo2 > 0) o.put("aspect", maxOf(dm2.widthPixels, dm2.heightPixels).toDouble() / lo2.toDouble())
        o.toString()
    } catch (e: Throwable) { "{}" }

    @JavascriptInterface
    fun startRecord() {
        Recorder.start { ok ->
            act.runOnUiThread { Toast.makeText(act, if (ok) "Recording saved in Movies/SensiHelper" else "Recording failed. Start Shizuku first", Toast.LENGTH_LONG).show() }
        }
    }

    @JavascriptInterface
    fun stopRecord() { Recorder.stop() }

    @JavascriptInterface
    fun recOn(): Boolean = Recorder.on

    /** Thermal protection: lower performance when the battery temperature reaches limit (degrees C). */
    @JavascriptInterface
    fun setThermal(on: Boolean, limit: Int) {
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit()
            .putBoolean("thermal", on).putInt("thermal_t", limit.coerceIn(38, 50)).apply()
    }

    /** Per-game profile: {"hz":90,"res":85,"dnd":true,"ram":true,"mon":true,"guard":false} */
    @JavascriptInterface
    fun setProfile(pkg: String, json: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        try {
            val o = org.json.JSONObject(json)
            act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit()
                .putString("prof_$pkg", o.toString())
                .putInt("guard_w", o.optInt("gw", 28).coerceIn(12, 80))
                .putInt("guard_style", o.optInt("gst", 0).coerceIn(0, 1))
                .putBoolean("lockbr", o.optBoolean("lb", false))
                .putInt("tex_$pkg", o.optInt("res", 100).coerceIn(30, 100))
                .putInt("str_$pkg", o.optInt("str", 0).let { if (it in 70..140 && it != 100) it else 0 })
                .putInt("sty_$pkg", o.optInt("sty", 0).let { if (it in 70..140 && it != 100) it else 0 })
                .apply()
        } catch (ex: Throwable) {}
    }

    /** Saves the screen-resolution percent to use while this game is in front (100 = off). */
    @JavascriptInterface
    fun setTex(pkg: String, pct: Int) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit().putInt("tex_$pkg", pct.coerceIn(30, 100)).apply()
    }

    /** Puts the screen size and density back to what the user had (used by "Reset screen now"). */
    @JavascriptInterface
    fun fixScreen(): Boolean {
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        val ok = shizukuSh(restoreScreenCmd(p))
        if (ok) p.edit().putBoolean("wm_dirty", false).apply()
        return ok
    }

    /** Shows the stretched screen for 6 seconds, then puts everything back. sx and sy are 70..140 (1.00x = 100). */
    @JavascriptInterface
    fun previewStretch(sx: Int, sy: Int) {
        val ax = if (sx in 70..140) sx else 100
        val ay = if (sy in 70..140) sy else 100
        if (ax == 100 && ay == 100) return
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        Thread {
            val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
            if (sz == null) return@Thread
            val a = sz.groupValues[1].toInt()
            val b = sz.groupValues[2].toInt()
            val lo = minOf(a, b)
            val hi = maxOf(a, b)
            val hi2 = (hi * 100 / ax).coerceIn(hi / 2, hi * 2)
            val lo2 = (lo * 100 / ay).coerceIn(lo / 2, lo * 2)
            if (!p.getBoolean("wm_dirty", false)) {
                p.edit()
                    .putString("user_size", Regex("Override size:\\s*(\\d+x\\d+)").find(shizukuOut("wm size"))?.groupValues?.get(1) ?: "")
                    .putString("user_density", Regex("Override density:\\s*(\\d+)").find(shizukuOut("wm density"))?.groupValues?.get(1) ?: "")
                    .apply()
            }
            p.edit().putBoolean("wm_dirty", true).apply()
            shizukuSh(if (a <= b) "wm size ${lo2}x${hi2}" else "wm size ${hi2}x${lo2}")
            try { Thread.sleep(6000) } catch (e: Throwable) {}
            if (shizukuSh(restoreScreenCmd(p))) p.edit().putBoolean("wm_dirty", false).apply()
        }.start()
    }

    @JavascriptInterface
    fun setLandscape(on: Boolean) {
        act.runOnUiThread {
            act.requestedOrientation = if (on) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    @JavascriptInterface
    fun appLabel(pkg: String): String {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return pkg
        return try {
            act.packageManager.getApplicationLabel(act.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Throwable) { pkg }
    }

    /** The installed game's real icon as a data: URL (empty if not installed). */
    @JavascriptInterface
    fun appIcon(pkg: String): String {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return ""
        return try {
            val bmp: Bitmap = act.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
            val bos = java.io.ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            "data:image/png;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        } catch (e: Throwable) { "" }
    }

    /** Game Space settings shared with the in-game assistant: performance mode 0..3 and auto-apply. */
    @JavascriptInterface
    fun getGs(): String {
        val p = act.getSharedPreferences("gs", Context.MODE_PRIVATE)
        return "{\"mode\":" + p.getInt("mode", 2) + ",\"auto\":" + p.getBoolean("auto", false) +
            ",\"edgefix\":" + p.getBoolean("edgefix", false) + "}"
    }

    @JavascriptInterface
    fun setGs(mode: Int, auto: Boolean) {
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit()
            .putInt("mode", mode.coerceIn(0, 3)).putBoolean("auto", auto).apply()
    }

    /** No edge swipes: turn off the back-gesture zones while a game is open (needs the assistant on Auto). */
    @JavascriptInterface
    fun setEdgeFix(on: Boolean) {
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit().putBoolean("edgefix", on).apply()
        if (!on) Thread { EdgeFix.restore() }.start()
    }

    /** Turns Do Not Disturb off whatever state it was in (for notifications that are stuck off). */
    @JavascriptInterface
    fun dndOff(): Boolean = DndGuard.forceOff()

    /** Rendering graphics (ANGLE): what the phone supports and which preset is on. */
    @JavascriptInterface
    fun angleInfo(): String = try { AngleFx.info().toString() } catch (e: Throwable) { "{}" }

    /** 0 = off, 1 = Low Texture, 2 = Low Pixel. Returns false when it could not be applied. */
    @JavascriptInterface
    fun setRender(preset: Int): Boolean = AngleFx.set(preset.coerceIn(0, 2))

    /** Saturation level used while a game is open: 100, 115, 130 or 150. */
    @JavascriptInterface
    fun setSat(level: Int) {
        val v = if (level == 115 || level == 130 || level == 150) level else 100
        act.getSharedPreferences("gs", Context.MODE_PRIVATE).edit().putInt("sat_level", v).apply()
    }

    @JavascriptInterface
    fun getSat(): Int = act.getSharedPreferences("gs", Context.MODE_PRIVATE).getInt("sat_level", 100)

    /** Which permissions are on, for the Setup card. */
    @JavascriptInterface
    fun perms(): String = try {
        val pw = act.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
        "{\"overlay\":" + Settings.canDrawOverlays(act) +
            ",\"usage\":" + hasUsageAccess(act) +
            ",\"install\":" + act.packageManager.canRequestPackageInstalls() +
            ",\"notif\":" + androidx.core.app.NotificationManagerCompat.from(act).areNotificationsEnabled() +
            ",\"battery\":" + pw.isIgnoringBatteryOptimizations(act.packageName) + "}"
    } catch (e: Throwable) { "{}" }

    /** Opens the right system screen for one permission. */
    @JavascriptInterface
    fun openPerm(which: String) {
        act.runOnUiThread {
            try {
                val i: Intent? = when (which) {
                    "overlay" -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))
                    "usage" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    "install" -> Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                    "notif" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                    "battery" -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    else -> null
                }
                if (i != null) act.startActivity(i)
            } catch (e: Throwable) {}
        }
    }

    /** Plain sentences about what this app has changed on the phone right now. */
    @JavascriptInterface
    fun changes(): String = try { ChangeLog.list().toString() } catch (e: Throwable) { "[]" }

    /** Puts everything back to normal. Returns {"ok":true/false,"failed":["..."]}. */
    @JavascriptInterface
    fun resetAll(): String = try { ResetAll.run(act).toString() } catch (e: Throwable) { "{\"ok\":false,\"failed\":[\"Error\"]}" }

    @JavascriptInterface
    fun hidePanel() {
        act.runOnUiThread { act.stopService(Intent(act, PanelService::class.java)) }
    }

    @JavascriptInterface
    fun launch(pkg: String) {
        if (!Regex("[a-zA-Z0-9_.]+").matches(pkg)) return
        act.runOnUiThread {
            act.packageManager.getLaunchIntentForPackage(pkg)?.let { act.startActivity(it) }
        }
    }
}
