package com.saif.sensihelper

import android.content.Context

/** Lets code without a Context (the Shizuku helpers) reach the small settings store. */
object Gs {
    @Volatile var ctx: Context? = null
    fun prefs() = ctx?.getSharedPreferences("gs", Context.MODE_PRIVATE)
}

/**
 * Remembers what Do Not Disturb and the heads-up pop-ups were set to before this app changed them,
 * and puts them back afterwards.
 */
object DndGuard {
    private val onRe = Regex("set_dnd\\s+(priority|alarms|none)")
    private val offRe = Regex("set_dnd\\s+off")
    private val huOnRe = Regex("heads_up_notifications_enabled\\s+0")
    private val huOffRe = Regex("heads_up_notifications_enabled\\s+1")

    /** Called with every command before it runs. */
    fun watch(cmd: String) {
        val p = Gs.prefs() ?: return
        if (cmd.contains("heads_up_notifications_enabled")) {
            if (huOnRe.containsMatchIn(cmd)) {
                if (!p.getBoolean("hu_by_us", false)) {
                    val prev = shizukuOut("settings get global heads_up_notifications_enabled").trim()
                    p.edit().putString("hu_prev", if (prev == "0") "0" else "1").putBoolean("hu_by_us", true).apply()
                }
            } else if (huOffRe.containsMatchIn(cmd)) {
                p.edit().putBoolean("hu_by_us", false).apply()
            }
        }
        if (!cmd.contains("set_dnd")) return
        if (onRe.containsMatchIn(cmd)) {
            if (!p.getBoolean("dnd_by_us", false)) {
                val prev = shizukuOut("settings get global zen_mode").trim()
                p.edit().putString("zen_prev", if (Regex("[0-3]").matches(prev)) prev else "0")
                    .putBoolean("dnd_by_us", true).apply()
            }
        } else if (offRe.containsMatchIn(cmd)) {
            p.edit().putBoolean("dnd_by_us", false).apply()
        }
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        var ok = true
        if (p.getBoolean("hu_by_us", false)) {
            val prev = if (p.getString("hu_prev", "1") == "0") "0" else "1"
            if (shizukuSh("settings put global heads_up_notifications_enabled $prev")) p.edit().putBoolean("hu_by_us", false).apply()
            else ok = false
        }
        if (p.getBoolean("dnd_by_us", false)) {
            val mode = when (p.getString("zen_prev", "0")) {
                "1" -> "priority"
                "2" -> "none"
                "3" -> "alarms"
                else -> "off"
            }
            if (shizukuSh("cmd notification set_dnd $mode")) p.edit().putBoolean("dnd_by_us", false).apply()
            else ok = false
        }
        return ok
    }

    /** Hard reset for the "Notifications back on" button: Do Not Disturb off and pop-ups on, whatever the old state was. */
    fun forceOff(): Boolean {
        val ok = shizukuSh("cmd notification set_dnd off;settings put global heads_up_notifications_enabled 1")
        if (ok) Gs.prefs()?.edit()?.putBoolean("dnd_by_us", false)?.putBoolean("hu_by_us", false)?.apply()
        return ok
    }
}

/** Turns off the back-gesture zones on both screen edges while a game is open, then puts them back. */
object EdgeFix {
    private const val L = "back_gesture_inset_scale_left"
    private const val R = "back_gesture_inset_scale_right"

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) {
            val l = shizukuOut("settings get secure $L").trim()
            val r = shizukuOut("settings get secure $R").trim()
            p.edit().putString("edge_l", l).putString("edge_r", r).apply()
        }
        val ok = shizukuSh("settings put secure $L 0;settings put secure $R 0")
        if (ok) p.edit().putBoolean("edge_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) return true
        fun cmd(key: String, v: String): String =
            if (Regex("[0-9]+(\\.[0-9]+)?").matches(v)) "settings put secure $key $v" else "settings delete secure $key"
        val ok = shizukuSh(cmd(L, p.getString("edge_l", "") ?: "") + ";" + cmd(R, p.getString("edge_r", "") ?: ""))
        if (ok) p.edit().putBoolean("edge_dirty", false).apply()
        return ok
    }
}

/**
 * Rendering graphics through ANGLE: "Low Texture" blurs textures a little, "Low Pixel" forces blocky texture sampling.
 * Both only make the picture lighter for weak phones. They use ANGLE's own testing switches.
 */
object AngleFx {
    private const val PKGS = "angle_gl_driver_selection_pkgs"
    private const val VALS = "angle_gl_driver_selection_values"
    private const val FEAT = "angle_egl_features"
    private const val GAMES = "com.dts.freefireth,com.dts.freefiremax,com.netease.newspike"

    private fun feature(preset: Int): String = if (preset == 2) "force_nearest_filtering" else "force_texture_lod_offset_2"

    fun info(): org.json.JSONObject {
        val o = org.json.JSONObject()
        o.put("system", shizukuOut("getprop persist.graphics.egl").contains("angle"))
        o.put("present", shizukuOut("pm list packages angle").contains("angle") || shizukuOut("getprop ro.gfx.angle.supported").trim() == "true")
        o.put("preset", Gs.prefs()?.getInt("rg_preset", 0) ?: 0)
        return o
    }

    fun set(preset: Int): Boolean {
        val p = Gs.prefs() ?: return false
        if (preset !in 1..2) return clear()
        // Some phones already use ANGLE for every app. The feature switch is global, so it would hit all apps there.
        if (shizukuOut("getprop persist.graphics.egl").contains("angle")) return false
        if (!p.getBoolean("rg_saved", false)) {
            p.edit()
                .putString("rg_pkgs", shizukuOut("settings get global $PKGS").trim())
                .putString("rg_vals", shizukuOut("settings get global $VALS").trim())
                .putString("rg_feat", shizukuOut("settings get global $FEAT").trim())
                .putBoolean("rg_saved", true).apply()
        }
        val ok = shizukuSh(
            "settings put global $PKGS $GAMES;settings put global $VALS angle,angle,angle;settings put global $FEAT ${feature(preset)}"
        )
        if (ok) p.edit().putInt("rg_preset", preset).apply()
        return ok
    }

    /** Puts the three settings back to what they were before (or removes them). */
    fun clear(): Boolean {
        val p = Gs.prefs() ?: return false
        fun cmd(key: String, v: String): String =
            if (Regex("[A-Za-z0-9_.,:-]+").matches(v) && v != "null") "settings put global $key $v" else "settings delete global $key"
        val ok = if (p.getBoolean("rg_saved", false)) {
            shizukuSh(
                cmd(PKGS, p.getString("rg_pkgs", "") ?: "") + ";" + cmd(VALS, p.getString("rg_vals", "") ?: "") + ";" +
                    cmd(FEAT, p.getString("rg_feat", "") ?: "")
            )
        } else {
            shizukuSh("settings delete global $FEAT;settings delete global $PKGS;settings delete global $VALS")
        }
        if (ok) p.edit().putInt("rg_preset", 0).putBoolean("rg_saved", false).apply()
        return ok
    }
}

/** Cool mode: a dimmer screen and no always-on display, put back exactly as it was afterwards. */
object CoolFx {
    fun on(): Boolean = Gs.prefs()?.getBoolean("cool_dirty", false) ?: false

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) {
            p.edit()
                .putString("cool_b", shizukuOut("settings get system screen_brightness").trim())
                .putString("cool_m", shizukuOut("settings get system screen_brightness_mode").trim())
                .putString("cool_a", shizukuOut("settings get secure doze_always_on").trim())
                .apply()
        }
        val ok = shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness 77;settings put secure doze_always_on 0")
        if (ok) p.edit().putBoolean("cool_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) return true
        val b = p.getString("cool_b", "") ?: ""
        val m = p.getString("cool_m", "") ?: ""
        val a = p.getString("cool_a", "") ?: ""
        val parts = ArrayList<String>()
        if (Regex("\\d+").matches(b)) parts.add("settings put system screen_brightness $b")
        if (Regex("[01]").matches(a)) parts.add("settings put secure doze_always_on $a")
        if (Regex("[01]").matches(m)) parts.add("settings put system screen_brightness_mode $m")
        val ok = parts.isEmpty() || shizukuSh(parts.joinToString(";"))
        if (ok) p.edit().putBoolean("cool_dirty", false).apply()
        return ok
    }
}

/** Lock brightness mode: switches auto-brightness off while playing and back on afterwards. */
object BrightLock {
    fun on(): Boolean = Gs.prefs()?.getBoolean("bl_dirty", false) ?: false

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (p.getBoolean("bl_dirty", false)) return true
        if (shizukuOut("settings get system screen_brightness_mode").trim() != "1") return true
        val ok = shizukuSh("settings put system screen_brightness_mode 0")
        if (ok) p.edit().putBoolean("bl_dirty", true).apply()
        return ok
    }

    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("bl_dirty", false)) return true
        val ok = shizukuSh("settings put system screen_brightness_mode 1")
        if (ok) p.edit().putBoolean("bl_dirty", false).apply()
        return ok
    }
}

/** Colour saturation through SurfaceFlinger, on only while a game is open. Many phones ignore it. */
object SatFx {
    fun level(): Int = Gs.prefs()?.getInt("sat_level", 100) ?: 100

    private fun cmd(l: Int): String = "service call SurfaceFlinger 1022 f " + java.lang.String.format(java.util.Locale.US, "%.2f", l / 100.0)

    fun apply(l: Int): Boolean {
        val p = Gs.prefs() ?: return false
        val v = if (l in 100..200) l else 100
        val ok = shizukuSh(cmd(v))
        if (ok) p.edit().putInt("sat_level", v).putBoolean("sat_dirty", v != 100).apply()
        return ok
    }

    /** Back to normal colours. The chosen level stays saved for the next game. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("sat_dirty", false)) return true
        val ok = shizukuSh(cmd(100))
        if (ok) p.edit().putBoolean("sat_dirty", false).apply()
        return ok
    }
}
