package com.saif.sensihelper

import android.content.Context

/** Lets code without a Context (the Shizuku helpers) reach the small settings store. */
object Gs {
    @Volatile var ctx: Context? = null
    fun prefs() = ctx?.getSharedPreferences("gs", Context.MODE_PRIVATE)
}

/** Remembers what Do Not Disturb was set to before this app turned it on, and puts it back afterwards. */
object DndGuard {
    private val onRe = Regex("set_dnd\\s+(priority|alarms|none)")
    private val offRe = Regex("set_dnd\\s+off")

    /** Called with every command before it runs. */
    fun watch(cmd: String) {
        if (!cmd.contains("set_dnd")) return
        val p = Gs.prefs() ?: return
        if (onRe.containsMatchIn(cmd)) {
            if (!p.getBoolean("dnd_by_us", false)) {
                val prev = shizukuOut("settings get global zen_mode").trim()
                p.edit().putString("zen_prev", if (Regex("[0-3]").matches(prev)) prev else "0")
                    .putBoolean("dnd_by_us", true).apply()
            }
        } else if (offRe.containsMatchIn(cmd)) {
            p.edit().putBoolean("dnd_by_us", false).apply()
        }
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("dnd_by_us", false)) return true
        val mode = when (p.getString("zen_prev", "0")) {
            "1" -> "priority"
            "2" -> "none"
            "3" -> "alarms"
            else -> "off"
        }
        val ok = shizukuSh("cmd notification set_dnd $mode")
        if (ok) p.edit().putBoolean("dnd_by_us", false).apply()
        return ok
    }

    /** Hard reset for the "Notifications back on" button: turns Do Not Disturb off whatever the old state was. */
    fun forceOff(): Boolean {
        val ok = shizukuSh("cmd notification set_dnd off")
        if (ok) Gs.prefs()?.edit()?.putBoolean("dnd_by_us", false)?.apply()
        return ok
    }
}

/** Turns off the back-gesture zones on both screen edges while a game is open, then puts them back. */
object EdgeFix {
    private const val L = "back_gesture_inset_scale_left"
    private const val R = "back_gesture_inset_scale_right"

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) {
            val l = shizukuOut("settings get secure $L").trim()
            val r = shizukuOut("settings get secure $R").trim()
            p.edit().putString("edge_l", l).putString("edge_r", r).apply()
        }
        val ok = shizukuSh("settings put secure $L 0;settings put secure $R 0")
        if (ok) p.edit().putBoolean("edge_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) return true
        fun cmd(key: String, v: String): String =
            if (Regex("[0-9]+(\\.[0-9]+)?").matches(v)) "settings put secure $key $v" else "settings delete secure $key"
        val ok = shizukuSh(cmd(L, p.getString("edge_l", "") ?: "") + ";" + cmd(R, p.getString("edge_r", "") ?: ""))
        if (ok) p.edit().putBoolean("edge_dirty", false).apply()
        return ok
    }
}
