package com.saif.sensihelper

import android.content.Context

/** Lets code without a Context (the Shizuku helpers) reach the small settings store. */
object Gs {
    @Volatile var ctx: Context? = null
    fun prefs() = ctx?.getSharedPreferences("gs", Context.MODE_PRIVATE)
}

/** Remembers what Do Not Disturb was set to before this app turned it on, and puts it back afterwards. */
object DndGuard {
    private val onRe = Regex("set_dnd\\s+(priority|alarms|none)")
    private val offRe = Regex("set_dnd\\s+off")

    /** Called with every command before it runs. */
    fun watch(cmd: String) {
        if (!cmd.contains("set_dnd")) return
        val p = Gs.prefs() ?: return
        if (onRe.containsMatchIn(cmd)) {
            if (!p.getBoolean("dnd_by_us", false)) {
                val prev = shizukuOut("settings get global zen_mode").trim()
                p.edit().putString("zen_prev", if (Regex("[0-3]").matches(prev)) prev else "0")
                    .putBoolean("dnd_by_us", true).apply()
            }
        } else if (offRe.containsMatchIn(cmd)) {
            p.edit().putBoolean("dnd_by_us", false).apply()
        }
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("dnd_by_us", false)) return true
        val mode = when (p.getString("zen_prev", "0")) {
            "1" -> "priority"
            "2" -> "none"
            "3" -> "alarms"
            else -> "off"
        }
        val ok = shizukuSh("cmd notification set_dnd $mode")
        if (ok) p.edit().putBoolean("dnd_by_us", false).apply()
        return ok
    }

    /** Hard reset for the "Notifications back on" button: turns Do Not Disturb off whatever the old state was. */
    fun forceOff(): Boolean {
        val ok = shizukuSh("cmd notification set_dnd off")
        if (ok) Gs.prefs()?.edit()?.putBoolean("dnd_by_us", false)?.apply()
        return ok
    }
}

/** Turns off the back-gesture zones on both screen edges while a game is open, then puts them back. */
object EdgeFix {
    private const val L = "back_gesture_inset_scale_left"
    private const val R = "back_gesture_inset_scale_right"

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) {
            val l = shizukuOut("settings get secure $L").trim()
            val r = shizukuOut("settings get secure $R").trim()
            p.edit().putString("edge_l", l).putString("edge_r", r).apply()
        }
        val ok = shizukuSh("settings put secure $L 0;settings put secure $R 0")
        if (ok) p.edit().putBoolean("edge_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) return true
        fun cmd(key: String, v: String): String =
            if (Regex("[0-9]+(\\.[0-9]+)?").matches(v)) "settings put secure $key $v" else "settings delete secure $key"
        val ok = shizukuSh(cmd(L, p.getString("edge_l", "") ?: "") + ";" + cmd(R, p.getString("edge_r", "") ?: ""))
        if (ok) p.edit().putBoolean("edge_dirty", false).apply()
        return ok
    }
}

/**
 * Rendering graphics through ANGLE: "Low Texture" blurs textures a little, "Low Pixel" forces blocky texture sampling.
 * Both only make the picture lighter for weak phones. They use ANGLE's own testing switches.
 */
object AngleFx {
    private const val PKGS = "angle_gl_driver_selection_pkgs"
    private const val VALS = "angle_gl_driver_selection_values"
    private const val FEAT = "angle_egl_features"
    private const val GAMES = "com.dts.freefireth,com.dts.freefiremax,com.netease.newspike"

    private fun feature(preset: Int): String = if (preset == 2) "force_nearest_filtering" else "force_texture_lod_offset_2"

    fun info(): org.json.JSONObject {
        val o = org.json.JSONObject()
        o.put("system", shizukuOut("getprop persist.graphics.egl").contains("angle"))
        o.put("present", shizukuOut("pm list packages angle").contains("angle") || shizukuOut("getprop ro.gfx.angle.supported").trim() == "true")
        o.put("preset", Gs.prefs()?.getInt("rg_preset", 0) ?: 0)
        return o
    }

    fun set(preset: Int): Boolean {
        val p = Gs.prefs() ?: return false
        if (preset !in 1..2) return clear()
        // Some phones already use ANGLE for every app. The feature switch is global, so it would hit all apps there.
        if (shizukuOut("getprop persist.graphics.egl").contains("angle")) return false
        if (!p.getBoolean("rg_saved", false)) {
            p.edit()
                .putString("rg_pkgs", shizukuOut("settings get global $PKGS").trim())
                .putString("rg_vals", shizukuOut("settings get global $VALS").trim())
                .putString("rg_feat", shizukuOut("settings get global $FEAT").trim())
                .putBoolean("rg_saved", true).apply()
        }
        val ok = shizukuSh(
            "settings put global $PKGS $GAMES;settings put global $VALS angle,angle,angle;settings put global $FEAT ${feature(preset)}"
        )
        if (ok) p.edit().putInt("rg_preset", preset).apply()
        return ok
    }

    /** Puts the three settings back to what they were before (or removes them). */
    fun clear(): Boolean {
        val p = Gs.prefs() ?: return false
        fun cmd(key: String, v: String): String =
            if (Regex("[A-Za-z0-9_.,:-]+").matches(v) && v != "null") "settings put global $key $v" else "settings delete global $key"
        val ok = if (p.getBoolean("rg_saved", false)) {
            shizukuSh(
                cmd(PKGS, p.getString("rg_pkgs", "") ?: "") + ";" + cmd(VALS, p.getString("rg_vals", "") ?: "") + ";" +
                    cmd(FEAT, p.getString("rg_feat", "") ?: "")
            )
        } else {
            shizukuSh("settings delete global $FEAT;settings delete global $PKGS;settings delete global $VALS")
        }
        if (ok) p.edit().putInt("rg_preset", 0).putBoolean("rg_saved", false).apply()
        return ok
    }
}

/** Cool mode: a dimmer screen and no always-on display, put back exactly as it was afterwards. */
object CoolFx {
    fun on(): Boolean = Gs.prefs()?.getBoolean("cool_dirty", false) ?: false

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) {
            p.edit()
                .putString("cool_b", shizukuOut("settings get system screen_brightness").trim())
                .putString("cool_m", shizukuOut("settings get system screen_brightness_mode").trim())
                .putString("cool_a", shizukuOut("settings get secure doze_always_on").trim())
                .apply()
        }
        val ok = shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness 77;settings put secure doze_always_on 0")
        if (ok) p.edit().putBoolean("cool_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) return true
        val b = p.getString("cool_b", "") ?: ""
        val m = p.getString("cool_m", "") ?: ""
        val a = p.getString("cool_a", "") ?: ""
        val parts = ArrayList<String>()
        if (Regex("\\d+").matches(b)) parts.add("settings put system screen_brightness $b")
        if (Regex("[01]").matches(a)) parts.add("settings put secure doze_always_on $a")
        if (Regex("[01]").matches(m)) parts.add("settings put system screen_brightness_mode $m")
        val ok = parts.isEmpty() || shizukuSh(parts.joinToString(";"))
        if (ok) p.edit().putBoolean("cool_dirty", false).apply()
        return ok
    }
}
