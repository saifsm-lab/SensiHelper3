package com.saif.sensihelper

import android.content.Context
import android.content.Intent

/** Lets code without a Context (the Shizuku helpers) reach the small settings store. */
object Gs {
    @Volatile var ctx: Context? = null
    fun prefs() = ctx?.getSharedPreferences("gs", Context.MODE_PRIVATE)
}

/**
 * Remembers what Do Not Disturb and the heads-up pop-ups were set to before this app changed them,
 * and puts them back afterwards.
 */
object DndGuard {
    private val onRe = Regex("set_dnd\\s+(priority|alarms|none)")
    private val offRe = Regex("set_dnd\\s+off")
    private val huOnRe = Regex("heads_up_notifications_enabled\\s+0")
    private val huOffRe = Regex("heads_up_notifications_enabled\\s+1")

    /** Called with every command before it runs. */
    fun watch(cmd: String) {
        val p = Gs.prefs() ?: return
        if (cmd.contains("min_refresh_rate") || cmd.contains("peak_refresh_rate")) {
            if (cmd.contains("settings put")) p.edit().putBoolean("hz_by_us", true).apply()
            else if (cmd.contains("settings delete")) p.edit().putBoolean("hz_by_us", false).apply()
        }
        if (cmd.contains("animation_scale") || cmd.contains("animator_duration_scale")) {
            if (cmd.contains("scale 0.5")) p.edit().putBoolean("anim_by_us", true).apply()
            else if (cmd.contains("scale 1")) p.edit().putBoolean("anim_by_us", false).apply()
        }
        if (cmd.contains("heads_up_notifications_enabled")) {
            if (huOnRe.containsMatchIn(cmd)) {
                if (!p.getBoolean("hu_by_us", false)) {
                    val prev = shizukuOut("settings get global heads_up_notifications_enabled").trim()
                    p.edit().putString("hu_prev", if (prev == "0") "0" else "1").putBoolean("hu_by_us", true).apply()
                }
            } else if (huOffRe.containsMatchIn(cmd)) {
                p.edit().putBoolean("hu_by_us", false).apply()
            }
        }
        if (!cmd.contains("set_dnd")) return
        if (onRe.containsMatchIn(cmd)) {
            if (!p.getBoolean("dnd_by_us", false)) {
                val prev = shizukuOut("settings get global zen_mode").trim()
                p.edit().putString("zen_prev", if (Regex("[0-3]").matches(prev)) prev else "0")
                    .putBoolean("dnd_by_us", true).apply()
            }
        } else if (offRe.containsMatchIn(cmd)) {
            p.edit().putBoolean("dnd_by_us", false).apply()
        }
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        var ok = true
        if (p.getBoolean("hu_by_us", false)) {
            val prev = if (p.getString("hu_prev", "1") == "0") "0" else "1"
            if (shizukuSh("settings put global heads_up_notifications_enabled $prev")) p.edit().putBoolean("hu_by_us", false).apply()
            else ok = false
        }
        if (p.getBoolean("dnd_by_us", false)) {
            val mode = when (p.getString("zen_prev", "0")) {
                "1" -> "priority"
                "2" -> "none"
                "3" -> "alarms"
                else -> "off"
            }
            if (shizukuSh("cmd notification set_dnd $mode")) p.edit().putBoolean("dnd_by_us", false).apply()
            else ok = false
        }
        return ok
    }

    /** Hard reset for the "Notifications back on" button: Do Not Disturb off and pop-ups on, whatever the old state was. */
    fun forceOff(): Boolean {
        val ok = shizukuSh("cmd notification set_dnd off;settings put global heads_up_notifications_enabled 1")
        if (ok) Gs.prefs()?.edit()?.putBoolean("dnd_by_us", false)?.putBoolean("hu_by_us", false)?.apply()
        return ok
    }
}

/** Turns off the back-gesture zones on both screen edges while a game is open, then puts them back. */
object EdgeFix {
    private const val L = "back_gesture_inset_scale_left"
    private const val R = "back_gesture_inset_scale_right"

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) {
            val l = shizukuOut("settings get secure $L").trim()
            val r = shizukuOut("settings get secure $R").trim()
            p.edit().putString("edge_l", l).putString("edge_r", r).apply()
        }
        val ok = shizukuSh("settings put secure $L 0;settings put secure $R 0")
        if (ok) p.edit().putBoolean("edge_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("edge_dirty", false)) return true
        fun cmd(key: String, v: String): String =
            if (Regex("[0-9]+(\\.[0-9]+)?").matches(v)) "settings put secure $key $v" else "settings delete secure $key"
        val ok = shizukuSh(cmd(L, p.getString("edge_l", "") ?: "") + ";" + cmd(R, p.getString("edge_r", "") ?: ""))
        if (ok) p.edit().putBoolean("edge_dirty", false).apply()
        return ok
    }
}

/**
 * Rendering graphics through ANGLE: "Low Texture" blurs textures a little, "Low Pixel" forces blocky texture sampling.
 * Both only make the picture lighter for weak phones. They use ANGLE's own testing switches.
 */
object AngleFx {
    private const val PKGS = "angle_gl_driver_selection_pkgs"
    private const val VALS = "angle_gl_driver_selection_values"
    private const val FEAT = "angle_egl_features"
    private const val GAMES = "com.dts.freefireth,com.dts.freefiremax,com.netease.newspike,com.mojang.minecraftpe"

    private fun feature(preset: Int): String = if (preset == 2) "force_nearest_filtering" else "force_texture_lod_offset_2"

    fun info(): org.json.JSONObject {
        val o = org.json.JSONObject()
        o.put("system", shizukuOut("getprop persist.graphics.egl").contains("angle"))
        o.put("present", shizukuOut("pm list packages angle").contains("angle") || shizukuOut("getprop ro.gfx.angle.supported").trim() == "true")
        o.put("preset", Gs.prefs()?.getInt("rg_preset", 0) ?: 0)
        return o
    }

    fun set(preset: Int): Boolean {
        val p = Gs.prefs() ?: return false
        if (preset !in 1..2) return clear()
        // Some phones already use ANGLE for every app. The feature switch is global, so it would hit all apps there.
        if (shizukuOut("getprop persist.graphics.egl").contains("angle")) return false
        if (!p.getBoolean("rg_saved", false)) {
            p.edit()
                .putString("rg_pkgs", shizukuOut("settings get global $PKGS").trim())
                .putString("rg_vals", shizukuOut("settings get global $VALS").trim())
                .putString("rg_feat", shizukuOut("settings get global $FEAT").trim())
                .putBoolean("rg_saved", true).apply()
        }
        val ok = shizukuSh(
            "settings put global $PKGS $GAMES;settings put global $VALS angle,angle,angle,angle;settings put global $FEAT ${feature(preset)}"
        )
        if (ok) p.edit().putInt("rg_preset", preset).apply()
        return ok
    }

    /** Puts the three settings back to what they were before (or removes them). */
    fun clear(): Boolean {
        val p = Gs.prefs() ?: return false
        fun cmd(key: String, v: String): String =
            if (Regex("[A-Za-z0-9_.,:-]+").matches(v) && v != "null") "settings put global $key $v" else "settings delete global $key"
        val ok = if (p.getBoolean("rg_saved", false)) {
            shizukuSh(
                cmd(PKGS, p.getString("rg_pkgs", "") ?: "") + ";" + cmd(VALS, p.getString("rg_vals", "") ?: "") + ";" +
                    cmd(FEAT, p.getString("rg_feat", "") ?: "")
            )
        } else {
            shizukuSh("settings delete global $FEAT;settings delete global $PKGS;settings delete global $VALS")
        }
        if (ok) p.edit().putInt("rg_preset", 0).putBoolean("rg_saved", false).apply()
        return ok
    }
}

/** Cool mode: a dimmer screen and no always-on display, put back exactly as it was afterwards. */
object CoolFx {
    fun on(): Boolean = Gs.prefs()?.getBoolean("cool_dirty", false) ?: false

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) {
            p.edit()
                .putString("cool_b", shizukuOut("settings get system screen_brightness").trim())
                .putString("cool_m", shizukuOut("settings get system screen_brightness_mode").trim())
                .putString("cool_a", shizukuOut("settings get secure doze_always_on").trim())
                .apply()
        }
        val ok = shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness 77;settings put secure doze_always_on 0")
        if (ok) p.edit().putBoolean("cool_dirty", true).apply()
        return ok
    }

    /** Returns true when there is nothing left to undo. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("cool_dirty", false)) return true
        val b = p.getString("cool_b", "") ?: ""
        val m = p.getString("cool_m", "") ?: ""
        val a = p.getString("cool_a", "") ?: ""
        val parts = ArrayList<String>()
        if (Regex("\\d+").matches(b)) parts.add("settings put system screen_brightness $b")
        if (Regex("[01]").matches(a)) parts.add("settings put secure doze_always_on $a")
        if (Regex("[01]").matches(m)) parts.add("settings put system screen_brightness_mode $m")
        val ok = parts.isEmpty() || shizukuSh(parts.joinToString(";"))
        if (ok) p.edit().putBoolean("cool_dirty", false).apply()
        return ok
    }
}

/** Lock brightness mode: switches auto-brightness off while playing and back on afterwards. */
object BrightLock {
    fun on(): Boolean = Gs.prefs()?.getBoolean("bl_dirty", false) ?: false

    fun apply(): Boolean {
        val p = Gs.prefs() ?: return false
        if (p.getBoolean("bl_dirty", false)) return true
        if (shizukuOut("settings get system screen_brightness_mode").trim() != "1") return true
        val ok = shizukuSh("settings put system screen_brightness_mode 0")
        if (ok) p.edit().putBoolean("bl_dirty", true).apply()
        return ok
    }

    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("bl_dirty", false)) return true
        val ok = shizukuSh("settings put system screen_brightness_mode 1")
        if (ok) p.edit().putBoolean("bl_dirty", false).apply()
        return ok
    }
}

/** Colour saturation through SurfaceFlinger, on only while a game is open. Many phones ignore it. */
object SatFx {
    fun level(): Int = Gs.prefs()?.getInt("sat_level", 100) ?: 100

    private fun cmd(l: Int): String = "service call SurfaceFlinger 1022 f " + java.lang.String.format(java.util.Locale.US, "%.2f", l / 100.0)

    fun apply(l: Int): Boolean {
        val p = Gs.prefs() ?: return false
        val v = if (l in 100..200) l else 100
        val ok = shizukuSh(cmd(v))
        if (ok) p.edit().putInt("sat_level", v).putBoolean("sat_dirty", v != 100).apply()
        return ok
    }

    /** Back to normal colours. The chosen level stays saved for the next game. */
    fun restore(): Boolean {
        val p = Gs.prefs() ?: return false
        if (!p.getBoolean("sat_dirty", false)) return true
        val ok = shizukuSh(cmd(100))
        if (ok) p.edit().putBoolean("sat_dirty", false).apply()
        return ok
    }
}


/** What this app has changed on the phone right now, as plain sentences. Read from the app's own records. */
object ChangeLog {
    private val GAMES = listOf("com.dts.freefireth" to "Free Fire", "com.dts.freefiremax" to "FF MAX", "com.netease.newspike" to "Blood Strike", "com.mojang.minecraftpe" to "Minecraft")

    fun list(): org.json.JSONArray {
        val a = org.json.JSONArray()
        val p = Gs.prefs() ?: return a
        if (p.getBoolean("wm_dirty", false)) a.put("Screen size, resolution or stretch is changed")
        if (p.getBoolean("dnd_by_us", false)) a.put("Do Not Disturb is on")
        if (p.getBoolean("hu_by_us", false)) a.put("Heads-up pop-ups are hidden")
        if (p.getBoolean("edge_dirty", false)) a.put("Back-gesture zones on the screen edges are off")
        if (p.getBoolean("cool_dirty", false)) a.put("Cool mode: the screen is dimmer")
        if (p.getBoolean("bl_dirty", false)) a.put("Auto-brightness is off")
        if (p.getBoolean("sat_dirty", false)) a.put("Colour saturation is " + p.getInt("sat_level", 100) + "%")
        val rg = p.getInt("rg_preset", 0)
        if (rg > 0) a.put("Rendering graphics: " + (if (rg == 1) "Low Texture" else "Low Pixel"))
        if (p.getBoolean("hz_by_us", false)) a.put("Refresh rate is forced")
        if (p.getBoolean("anim_by_us", false)) a.put("Animations are shortened")
        for ((pkg, name) in GAMES) {
            val d = p.getInt("gm_ds_$pkg", 0)
            if (d > 0) a.put("Game Mode+: $name draws at $d% resolution")
        }
        return a
    }
}

/** Puts everything this app can change back to normal, and stops the floating pieces. */
object ResetAll {
    private val GAMES = listOf("com.dts.freefireth", "com.dts.freefiremax", "com.netease.newspike", "com.mojang.minecraftpe")

    fun run(ctx: Context): org.json.JSONObject {
        val p = Gs.prefs()
        val failed = org.json.JSONArray()
        fun step(name: String, ok: Boolean) { if (!ok) failed.put(name) }
        // stop the floating pieces first so they cannot change anything again
        try { ctx.stopService(Intent(ctx, PanelService::class.java)) } catch (e: Throwable) {}
        try { ctx.stopService(Intent(ctx, OverlayService::class.java)) } catch (e: Throwable) {}
        step("Notifications", DndGuard.restore())
        step("Edge swipes", EdgeFix.restore())
        step("Cool mode", CoolFx.restore())
        step("Brightness", BrightLock.restore())
        step("Colours", SatFx.restore())
        if (p != null && (p.getInt("rg_preset", 0) > 0 || p.getBoolean("rg_saved", false))) step("Rendering graphics", AngleFx.clear())
        if (p != null) {
            val ok = shizukuSh(restoreScreenCmd(p))
            if (ok) p.edit().putBoolean("wm_dirty", false).apply()
            step("Screen size", ok)
        }
        val cmds = ArrayList<String>()
        if (p?.getBoolean("hz_by_us", false) == true) cmds.add("settings delete system min_refresh_rate;settings delete system peak_refresh_rate")
        if (p?.getBoolean("anim_by_us", false) == true) cmds.add("settings put global window_animation_scale 1;settings put global transition_animation_scale 1;settings put global animator_duration_scale 1")
        cmds.add("cmd power set-fixed-performance-mode-enabled false")
        for (g in GAMES) if ((p?.getInt("gm_ds_$g", 0) ?: 0) > 0) cmds.add("cmd game reset $g")
        step("Refresh rate, animations and Game Mode+", shizukuSh(cmds.joinToString(";")))
        p?.edit()?.apply { for (g in GAMES) putInt("gm_ds_$g", 0) }?.apply()
        return org.json.JSONObject().put("failed", failed).put("ok", failed.length() == 0)
    }
}
