package com.saif.sensihelper

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/**
 * Game Assistant (Red Magic style): a logo handle that docks to the screen edge while a game
 * is in front. Tap it to open the assistant: live temperature, battery and free RAM,
 * performance modes, Do Not Disturb, clean RAM, screenshot, crosshair and your sensitivity numbers.
 *
 * Data from the web page:
 * {"cur":"bs","hz":120,"games":{"bs":{"name","vals":[[n,v]],"xh":{..}},"ff":{..}}}
 */
class PanelService : Service() {

    private val RED = "#FF2A3D"
    private val WHITE = "#FFFFFF"
    private val MUTED = "#9AA0B4"
    private val BS_PKG = "com.netease.newspike"
    private val FF_PKG = "com.dts.freefireth"
    private val modeNames = listOf("OFF", "STANDARD", "HIGH", "EXTREME")

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var data = JSONObject()
    private var curKey = "bs"
    private var hz = 0
    private val xhs = HashMap<String, JSONObject>()
    private var xhOn = false
    private var dnd = false
    private var auto = false
    private var lastFg: String? = null
    private var gamePkg: String? = null
    private var appliedPkg: String? = null
    private var tTemp: TextView? = null
    private var tBat: TextView? = null
    private var tRam: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private val colors = listOf("#27f0d6", "#3dff6a", "#ffe83a", "#ff4d5a", "#ffffff", "#ff6bd6")
    private val prefs by lazy { getSharedPreferences("gs", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("p")?.let {
            try {
                data = JSONObject(it)
                curKey = data.optString("cur", "bs")
                hz = data.optInt("hz", 0).let { v -> if (v in 30..240) v else 0 }
                xhs.clear()
            } catch (e: Throwable) {}
            ui.removeCallbacks(tick)
            auto = intent?.getBooleanExtra("auto", false) ?: false
            if (auto) { hideAll(); ui.post(tick) } else showBubble()
        }
        return START_NOT_STICKY
    }

    // ---------- per-game data
    private fun curGame(): JSONObject? = data.optJSONObject("games")?.optJSONObject(curKey)

    private fun xhNow(): JSONObject = xhs.getOrPut(curKey) {
        JSONObject(curGame()?.optJSONObject("xh")?.toString() ?: "{}")
    }

    private fun keyFor(pkg: String): String? = when {
        pkg == BS_PKG -> "bs"
        pkg.startsWith("com.dts.freefire") -> "ff"
        else -> null
    }

    private fun pkgNow(): String {
        val p = gamePkg ?: (if (curKey == "bs") BS_PKG else FF_PKG)
        return if (Regex("[a-zA-Z0-9_.]+").matches(p)) p else FF_PKG
    }

    // ---------- performance modes (same commands as the Tweaks tab)
    private fun cmdFor(mode: Int, pkg: String): String {
        val on1 = "cmd game mode performance $pkg;cmd notification set_dnd priority"
        val on2 = on1 +
            ";settings put global window_animation_scale 0.5;settings put global transition_animation_scale 0.5" +
            ";settings put global animator_duration_scale 0.5;cmd deviceidle whitelist +$pkg" +
            (if (hz > 0) ";settings put system min_refresh_rate $hz;settings put system peak_refresh_rate $hz" else "")
        val off = "cmd game reset $pkg;cmd notification set_dnd off" +
            ";settings put global window_animation_scale 1;settings put global transition_animation_scale 1" +
            ";settings put global animator_duration_scale 1;cmd deviceidle whitelist -$pkg" +
            ";settings delete system min_refresh_rate;settings delete system peak_refresh_rate" +
            ";cmd power set-fixed-performance-mode-enabled false"
        return when (mode) {
            1 -> "$off;$on1"
            2 -> "$off;$on2"
            3 -> "$off;$on2;cmd power set-fixed-performance-mode-enabled true"
            else -> off
        }
    }

    private fun applyMode(mode: Int, pkg: String) {
        thread {
            val ok = shizukuSh(cmdFor(mode, pkg))
            if (ok) {
                dnd = mode > 0
                toast(if (mode > 0) "Game Space: " + modeNames[mode] else "Performance mode off")
            } else toast("Start Shizuku (Tweaks tab) to use performance modes")
        }
    }

    private fun restore() {
        val p = appliedPkg ?: return
        appliedPkg = null
        dnd = false
        thread { shizukuSh(cmdFor(0, p)) }
    }

    // ---------- auto mode: assistant only while a supported game is in front
    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            val fg = foregroundPkg()
            if (fg != null) {
                val k = keyFor(fg)
                if (k != null) {
                    gamePkg = fg
                    if (bubble == null) { curKey = k; showBubble() }
                    else if (k != curKey) { curKey = k; closePanel() }
                    val m = prefs.getInt("mode", 2)
                    if (prefs.getBoolean("auto", false) && m > 0 && appliedPkg != fg) {
                        appliedPkg = fg
                        applyMode(m, fg)
                    }
                } else if (fg != packageName) {
                    if (bubble != null) hideAll()
                    restore()
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        return try {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 20000, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName
            }
            lastFg
        } catch (t: Throwable) { lastFg }
    }

    private fun hideAll() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pn", "Game panel", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pn")
            .setContentTitle("Game Assistant is on")
            .setContentText("Tap to open Sensi Helper")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    // ---------- small view helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: String, r: Int, stroke: String? = null, sw: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.cornerRadius = dp(r).toFloat()
        if (stroke != null) g.setStroke(dp(sw), Color.parseColor(stroke))
        return g
    }

    private fun toast(t: String) {
        ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    }

    private fun tv(t: String, sp: Float, color: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(Color.parseColor(color))
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun lp1(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun hrow(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in views) r.addView(c, lp1())
        return r
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val t = tv(text, 11f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.setPadding(dp(4), dp(9), dp(4), dp(9))
        t.background = if (selected) shape(RED, 6) else shape("#1A1D26", 6, "#2A2F3C")
        t.setOnClickListener { onClick() }
        return t
    }

    private fun tile(icon: String, label: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(9), dp(4), dp(9))
        c.background = if (active) shape("#33FF2A3D", 8, RED) else shape("#14161D", 8, "#2A2F3C")
        c.addView(tv(icon, 19f, WHITE))
        c.addView(tv(label, 9f, if (active) "#FFB3BA" else MUTED, true))
        c.setOnClickListener { onClick() }
        return c
    }

    // ---------- handle (logo, docks to the edge)
    private fun showBubble() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        val b = ImageView(this)
        b.setImageResource(R.drawable.ic_bubble)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.alpha = 0.9f

        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(110)
        bubbleLp = lp

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                        if (panel != null) closePanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    else {
                        val w = resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + size / 2 < w / 2) 0 else w - size
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                    }
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        ui.removeCallbacks(statsTick)
        tTemp = null; tBat = null; tRam = null
        panel?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        panel = null
    }

    // ---------- live stats
    private val statsTick = object : Runnable {
        override fun run() {
            if (panel == null) return
            updateStats()
            ui.postDelayed(this, 2000)
        }
    }

    private fun updateStats() {
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            tTemp?.text = String.format(Locale.US, "%.1f", t) + "\u00B0"
            tTemp?.setTextColor(Color.parseColor(if (t >= 42.0) "#FF8A80" else WHITE))
            tBat?.text = if (pct >= 0) "$pct%" else "-"
            tRam?.text = (mi.availMem / (1024L * 1024L)).toString() + " MB"
        } catch (e: Throwable) {}
    }

    private fun statCell(label: String): Pair<LinearLayout, TextView> {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(7), dp(4), dp(7))
        c.background = shape("#14161D", 6, "#2A2F3C")
        val v = tv("-", 15f, WHITE, true)
        v.gravity = Gravity.CENTER
        c.addView(v)
        c.addView(tv(label, 8f, MUTED, true))
        return Pair(c, v)
    }

    // ---------- assistant panel
    private fun openPanel() {
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(dp(14), dp(12), dp(14), dp(12))
        holder.background = shape("#F2090A10", 10, RED)
        panel = holder
        showMain()

        val sw = resources.displayMetrics.widthPixels
        val wide = sw >= dp(560)
        val width = if (wide) min(dp(560), sw - dp(150)) else min(dp(320), sw - dp(90))
        val lp = WindowManager.LayoutParams(
            width, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        val onLeft = (bubbleLp?.x ?: 0) + dp(26) < sw / 2
        lp.gravity = Gravity.CENTER_VERTICAL or (if (onLeft) Gravity.START else Gravity.END)
        lp.x = dp(60)
        wm.addView(holder, lp)
        ui.removeCallbacks(statsTick)
        ui.postDelayed(statsTick, 2000)
    }

    private fun showMain() {
        val holder = panel ?: return
        holder.removeAllViews()
        val game = curGame()
        val wide = resources.displayMetrics.widthPixels >= dp(560)
        val mode = prefs.getInt("mode", 2)

        // left: title, stats, performance
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val title = tv("GAME ASSISTANT", 10f, RED, true)
        title.letterSpacing = 0.15f
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val x = tv("\u2715", 14f, MUTED, true)
        x.setPadding(dp(10), 0, 0, 0)
        x.setOnClickListener { closePanel() }
        head.addView(x)
        left.addView(head)
        left.addView(tv((game?.optString("name") ?: "").uppercase(Locale.US), 19f, WHITE, true))

        val sTemp = statCell("TEMP")
        val sBat = statCell("BATTERY")
        val sRam = statCell("RAM FREE")
        tTemp = sTemp.second; tBat = sBat.second; tRam = sRam.second
        val stats = hrow(sTemp.first, sBat.first, sRam.first)
        left.addView(stats)
        updateStats()

        val pl = tv("PERFORMANCE", 10f, MUTED, true)
        pl.letterSpacing = 0.15f
        pl.setPadding(dp(3), dp(8), 0, dp(2))
        left.addView(pl)
        val chips = ArrayList<View>()
        for (i in 0..3) {
            chips.add(chip(modeNames[i], i == mode) {
                prefs.edit().putInt("mode", i).apply()
                val p = pkgNow()
                appliedPkg = if (i > 0) p else null
                applyMode(i, p)
                showMain()
            })
        }
        left.addView(hrow(chips[0], chips[1]))
        left.addView(hrow(chips[2], chips[3]))

        // right: tiles + crosshair adjust
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val t1 = tile("\uD83D\uDD15", "DND", dnd) {
            thread {
                val want = !dnd
                val ok = shizukuSh("cmd notification set_dnd " + (if (want) "priority" else "off"))
                if (ok) dnd = want else toast("Start Shizuku (Tweaks tab) first")
                ui.post { if (panel != null) showMain() }
            }
        }
        val t2 = tile("\uD83E\uDDF9", "CLEAN RAM", false) {
            toast("Cleaning...")
            thread { toast(if (shizukuSh("am kill-all")) "RAM cleaned" else "Start Shizuku (Tweaks tab) first") }
        }
        val t3 = tile("\u271B", "CROSSHAIR", xhOn) {
            if (xhOn) { stopService(Intent(this, OverlayService::class.java)); xhOn = false } else pushCrosshair()
            showMain()
        }
        val t4 = tile("\uD83D\uDCF8", "SCREENSHOT", false) { screenshot() }
        val t5 = tile("\uD83C\uDFAF", "SENSITIVITY", false) { showSens() }
        val t6 = tile("\u2716", "HIDE", false) { stopSelf() }
        right.addView(hrow(t1, t2, t3))
        right.addView(hrow(t4, t5, t6))
        val minus = chip("SIZE -", false) { changeSize(-2.0) }
        val plus = chip("SIZE +", false) { changeSize(2.0) }
        val col = chip("COLOR", false) {
            val xo = xhNow()
            val cur = xo.optString("color", colors[0])
            xo.put("color", colors[(colors.indexOf(cur) + 1) % colors.size])
            if (xhOn) pushCrosshair()
        }
        right.addView(hrow(minus, plus, col))

        if (wide) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            val l2 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            l1.setMargins(0, 0, dp(8), 0)
            row.addView(left, l1)
            row.addView(right, l2)
            holder.addView(row)
        } else {
            holder.addView(left)
            holder.addView(right)
        }
    }

    private fun showSens() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null
        val game = curGame()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = tv("SENSITIVITY  -  " + (game?.optString("name") ?: "").uppercase(Locale.US), 12f, WHITE, true)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val back = chip("BACK", true) { showMain() }
        head.addView(back, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(4))
        val vals = game?.optJSONArray("vals")
        if (vals == null || vals.length() == 0) {
            list.addView(tv("Open the Sensitivity tab in Sensi Helper first, then start the assistant again.", 12f, MUTED))
        } else {
            for (i in 0 until vals.length()) {
                val p = vals.optJSONArray(i) ?: continue
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.setPadding(0, dp(4), 0, dp(4))
                line.addView(tv(p.optString(0), 12f, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(tv(p.optString(1), 15f, WHITE, true))
                list.addView(line)
            }
        }
        val sc = ScrollView(this)
        sc.addView(list)
        val maxH = min(dp(250), resources.displayMetrics.heightPixels - dp(130))
        holder.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxH))
    }

    // ---------- actions
    private fun screenshot() {
        closePanel()
        val b = bubble
        b?.visibility = View.INVISIBLE
        ui.postDelayed({
            thread {
                val f = "/sdcard/Pictures/SensiHelper/shot_" + System.currentTimeMillis() + ".png"
                val ok = shizukuSh(
                    "mkdir -p /sdcard/Pictures/SensiHelper;screencap -p " + f +
                        ";am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + f
                )
                ui.post { b?.visibility = View.VISIBLE }
                toast(if (ok) "Screenshot saved in Pictures/SensiHelper" else "Start Shizuku (Tweaks tab) first")
            }
        }, 500)
    }

    private fun pushCrosshair() {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("x", xhNow().toString()))
        xhOn = true
    }

    private fun changeSize(d: Double) {
        val xo = xhNow()
        xo.put("size", (xo.optDouble("size", 10.0) + d).coerceIn(4.0, 40.0))
        if (xhOn) pushCrosshair()
    }

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        restore()
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
        super.onDestroy()
    }
}

/** True when the user allowed "Usage access" for this app (needed to see which game is open). */
fun hasUsageAccess(ctx: Context): Boolean = try {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
    mode == AppOpsManager.MODE_ALLOWED
} catch (e: Throwable) { false }
