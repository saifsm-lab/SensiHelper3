package com.saif.sensihelper

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.SeekBar
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/**
 * Game Assistant (Red Magic style): a logo handle that docks to the screen edge while a game
 * is in front. Tap it to open the assistant: live temperature, battery and free RAM,
 * performance modes, Do Not Disturb, clean RAM, screenshot, crosshair and your sensitivity numbers.
 *
 * Data from the web page:
 * {"cur":"bs","hz":120,"games":{"bs":{"name","vals":[[n,v]],"xh":{..}},"ff":{..}}}
 */
class PanelService : Service() {

    private val ACC = "#7FD8FF"
    private val WHITE = "#FFFFFF"
    private val MUTED = "#9AA0B4"
    private val BS_PKG = "com.netease.newspike"
    private val FF_PKG = "com.dts.freefireth"
    private val modeNames = listOf("OFF", "STANDARD", "HIGH", "EXTREME")

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var data = JSONObject()
    private var curKey = "bs"
    private var hz = 0
    private val xhs = HashMap<String, JSONObject>()
    private var xhOn = false
    private var dnd = false
    private var auto = false
    private var lastFg: String? = null
    private var gamePkg: String? = null
    private var appliedPkg: String? = null
    private var texOn = false
    private var profFor: String? = null
    private var profHz = 0
    private var profDnd = false
    private var thermalOn = false
    private var thermalPkg: String? = null
    private var monView: TextView? = null
    private var monFps = -1
    private val guards = ArrayList<View>()
    private var tTemp: TextView? = null
    private var tBat: TextView? = null
    private var tRam: TextView? = null
    private var tClock: TextView? = null
    private var gauge: Gauge? = null
    private val ui = Handler(Looper.getMainLooper())
    private val colors = listOf("#27f0d6", "#3dff6a", "#ffe83a", "#ff4d5a", "#ffffff", "#ff6bd6")
    private val prefs by lazy { getSharedPreferences("gs", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("p")?.let {
            try {
                data = JSONObject(it)
                curKey = data.optString("cur", "bs")
                hz = data.optInt("hz", 0).let { v -> if (v in 30..240) v else 0 }
                xhs.clear()
            } catch (e: Throwable) {}
            ui.removeCallbacks(tick)
            auto = intent?.getBooleanExtra("auto", false) ?: false
            if (auto) { hideAll(); ui.post(tick) } else showBubble()
        }
        return START_NOT_STICKY
    }

    // ---------- per-game data
    private fun curGame(): JSONObject? = data.optJSONObject("games")?.optJSONObject(curKey)

    private fun xhNow(): JSONObject = xhs.getOrPut(curKey) {
        JSONObject(curGame()?.optJSONObject("xh")?.toString() ?: "{}")
    }

    private fun keyFor(pkg: String): String? = when {
        pkg == BS_PKG -> "bs"
        pkg.startsWith("com.dts.freefire") -> "ff"
        else -> null
    }

    private fun pkgNow(): String {
        val p = gamePkg ?: (if (curKey == "bs") BS_PKG else FF_PKG)
        return if (Regex("[a-zA-Z0-9_.]+").matches(p)) p else FF_PKG
    }

    // ---------- performance modes (same commands as the Tweaks tab)
    private fun cmdFor(mode: Int, pkg: String): String {
        val on1 = "cmd game mode performance $pkg;cmd notification set_dnd priority"
        val on2 = on1 +
            ";settings put global window_animation_scale 0.5;settings put global transition_animation_scale 0.5" +
            ";settings put global animator_duration_scale 0.5;cmd deviceidle whitelist +$pkg" +
            (if (hz > 0) ";settings put system min_refresh_rate $hz;settings put system peak_refresh_rate $hz" else "")
        val off = "cmd game reset $pkg;cmd notification set_dnd off" +
            ";settings put global window_animation_scale 1;settings put global transition_animation_scale 1" +
            ";settings put global animator_duration_scale 1;cmd deviceidle whitelist -$pkg" +
            ";settings delete system min_refresh_rate;settings delete system peak_refresh_rate" +
            ";cmd power set-fixed-performance-mode-enabled false"
        return when (mode) {
            1 -> "$off;$on1"
            2 -> "$off;$on2"
            3 -> "$off;$on2;cmd power set-fixed-performance-mode-enabled true"
            else -> off
        }
    }

    private fun applyMode(mode: Int, pkg: String) {
        thread {
            val ok = shizukuSh(cmdFor(mode, pkg))
            if (ok) {
                dnd = mode > 0
                toast(if (mode > 0) "Game Space: " + modeNames[mode] else "Performance mode off")
            } else toast("Start Shizuku (Tweaks tab) to use performance modes")
        }
    }

    /** Lowers the whole screen's render size while a game is in front. Reset when the game leaves. */
    @Suppress("DEPRECATION")
    private fun applyTex(pct: Int) {
        thread {
            try {
                shizukuSh("wm size reset;wm density reset")
                val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
                val dn = Regex("Physical density:\\s*(\\d+)").find(shizukuOut("wm density"))
                if (sz == null || dn == null) { texOn = false; return@thread }
                val w = (sz.groupValues[1].toInt() * pct / 100 / 2) * 2
                val h = (sz.groupValues[2].toInt() * pct / 100 / 2) * 2
                // density scales with the size, so buttons and text keep the same on-screen size
                val d = maxOf(120, dn.groupValues[1].toInt() * pct / 100)
                shizukuSh("wm size ${w}x${h};wm density $d")
            } catch (e: Throwable) { texOn = false }
        }
    }

    // ---------- thermal protection
    private fun checkThermal(pkg: String) {
        if (!prefs.getBoolean("thermal", false)) { if (thermalOn) endThermal(); return }
        val lim = prefs.getInt("thermal_t", 44)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (!thermalOn && t >= lim) {
            thermalOn = true
            thermalPkg = pkg
            thread { shizukuSh("settings put system min_refresh_rate 60;settings put system peak_refresh_rate 60;cmd game mode standard $pkg") }
            toast("Phone is hot. Performance lowered.")
        } else if (thermalOn && t <= lim - 3) endThermal()
    }

    private fun endThermal() {
        thermalOn = false
        val pk = thermalPkg
        thermalPkg = null
        val hzSet = profHz
        val m = prefs.getInt("mode", 2)
        thread {
            shizukuSh(if (hzSet > 0) "settings put system min_refresh_rate $hzSet;settings put system peak_refresh_rate $hzSet"
                else "settings delete system min_refresh_rate;settings delete system peak_refresh_rate")
        }
        if (pk != null && m > 0 && prefs.getBoolean("auto", false)) applyMode(m, pk)
    }

    // ---------- per-game profile
    private fun applyProfile(pkg: String) {
        val o = try { JSONObject(prefs.getString("prof_$pkg", "{}") ?: "{}") } catch (e: Throwable) { JSONObject() }
        profHz = o.optInt("hz", 0)
        profDnd = o.optBoolean("dnd", false)
        val clean = o.optBoolean("ram", false)
        val hzNow = profHz
        val dndNow = profDnd
        thread {
            if (hzNow > 0) shizukuSh("settings put system min_refresh_rate $hzNow;settings put system peak_refresh_rate $hzNow")
            if (dndNow) shizukuSh("cmd notification set_dnd priority")
            if (clean) shizukuSh("am kill-all")
        }
        if (o.optBoolean("mon", false)) ui.post { showMonitor() }
        if (o.optBoolean("guard", false)) ui.post { showGuards() }
    }

    private fun endProfile() {
        val hzSet = profHz > 0
        val dndSet = profDnd
        profFor = null
        profHz = 0
        profDnd = false
        hideMonitor()
        hideGuards()
        thread {
            if (hzSet) shizukuSh("settings delete system min_refresh_rate;settings delete system peak_refresh_rate")
            if (dndSet) shizukuSh("cmd notification set_dnd off")
        }
    }

    // ---------- floating monitor (FPS is best effort)
    private fun readFps(pkg: String): Int {
        return try {
            val list = shizukuOut("dumpsys SurfaceFlinger --list")
            val layer = (list.lines().firstOrNull { it.contains(pkg) && it.contains("SurfaceView") }
                ?: list.lines().firstOrNull { it.contains(pkg) })?.trim() ?: return -1
            if (!Regex("[A-Za-z0-9_.#()\\[\\]/:\\- ]+").matches(layer)) return -1
            val out = shizukuOut("dumpsys SurfaceFlinger --latency \"$layer\"")
            val ts = out.lines().drop(1).mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
                .filter { it > 0L && it < Long.MAX_VALUE / 2 }
            if (ts.size < 2) return -1
            val span = ts.last() - ts.first()
            if (span <= 0L) -1 else Math.round((ts.size - 1) * 1e9 / span).toInt()
        } catch (e: Throwable) { -1 }
    }

    private val monTick = object : Runnable {
        override fun run() {
            val v = monView ?: return
            try {
                val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
                val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val fps = if (monFps > 0) "$monFps FPS" else "FPS -"
                v.text = fps + "   " + String.format(Locale.US, "%.1f", t) + "\u00B0   RAM " + (mi.availMem / 1048576L) + "M   " + lvl + "%"
            } catch (e: Throwable) {}
            ui.postDelayed(this, 1000)
        }
    }

    private val fpsTick = object : Runnable {
        override fun run() {
            val pk = profFor
            if (monView == null || pk == null) return
            thread { monFps = readFps(pk) }
            ui.postDelayed(this, 2500)
        }
    }

    private fun showMonitor() {
        if (monView != null) return
        val v = tv("FPS -", 10f, WHITE, true)
        v.setPadding(dp(10), dp(5), dp(10), dp(5))
        v.background = shape("#B3070C14", 14, "#4D7FD8FF", 1)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(70)
        lp.y = dp(6)
        try { wm.addView(v, lp); monView = v } catch (e: Throwable) { return }
        monFps = -1
        ui.post(monTick)
        ui.post(fpsTick)
    }

    private fun hideMonitor() {
        ui.removeCallbacks(monTick)
        ui.removeCallbacks(fpsTick)
        monView?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        monView = null
    }

    // ---------- edge guards (anti-mistouch strips)
    private fun showGuards() {
        hideGuards()
        for (left in booleanArrayOf(true, false)) {
            val v = View(this)
            v.setBackgroundColor(Color.parseColor("#14FFFFFF"))
            v.setOnTouchListener { _, _ -> true }
            val lp = WindowManager.LayoutParams(
                dp(16), ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP
            try { wm.addView(v, lp); guards.add(v) } catch (e: Throwable) {}
        }
    }

    private fun hideGuards() {
        for (v in guards) try { wm.removeView(v) } catch (e: Throwable) {}
        guards.clear()
    }

    private fun restore() {
        val p = appliedPkg ?: return
        appliedPkg = null
        dnd = false
        thread { shizukuSh(cmdFor(0, p)) }
    }

    // ---------- auto mode: assistant only while a supported game is in front
    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            val fg = foregroundPkg()
            if (fg != null) {
                val k = keyFor(fg)
                if (k != null) {
                    gamePkg = fg
                    if (bubble == null) { curKey = k; showBubble() }
                    else if (k != curKey) { curKey = k; closePanel() }
                    val m = prefs.getInt("mode", 2)
                    if (prefs.getBoolean("auto", false) && m > 0 && appliedPkg != fg) {
                        appliedPkg = fg
                        applyMode(m, fg)
                    }
                    val pct = prefs.getInt("tex_$fg", 100)
                    if (pct < 100 && !texOn) { texOn = true; applyTex(pct) }
                    else if (pct >= 100 && texOn) { texOn = false; thread { shizukuSh("wm size reset;wm density reset") } }
                    if (profFor != fg) { profFor = fg; applyProfile(fg) }
                    checkThermal(fg)
                } else if (fg != packageName) {
                    if (bubble != null) hideAll()
                    if (profFor != null) endProfile()
        if (thermalOn) endThermal()
                    if (thermalOn) endThermal()
                    restore()
                    if (texOn) { texOn = false; thread { shizukuSh("wm size reset;wm density reset") } }
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        return try {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 20000, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName
            }
            lastFg
        } catch (t: Throwable) { lastFg }
    }

    private fun hideAll() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pn", "Game panel", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pn")
            .setContentTitle("Game Assistant is on")
            .setContentText("Tap to open Sensi Helper")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    // ---------- small view helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: String, r: Int, stroke: String? = null, sw: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.cornerRadius = dp(r).toFloat()
        if (stroke != null) g.setStroke(dp(sw), Color.parseColor(stroke))
        return g
    }

    private fun toast(t: String) {
        ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    }

    private fun tv(t: String, sp: Float, color: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(Color.parseColor(color))
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun lp1(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun hrow(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in views) r.addView(c, lp1())
        return r
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val t = tv(text, 11f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.setPadding(dp(4), dp(9), dp(4), dp(9))
        t.setTextColor(Color.parseColor(if (selected) "#031018" else WHITE))
        t.background = if (selected) shape(ACC, 16) else shape("#16202E", 16, "#25344A")
        t.setOnClickListener { onClick() }
        return t
    }

    private fun tile(icon: Int, label: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(11), dp(4), dp(10))
        c.background = if (active) shape("#307FD8FF", 18, ACC) else shape("#121A27", 18, "#25344A")
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.parseColor(if (active) ACC else "#C8D3E6"))
        val ilp = LinearLayout.LayoutParams(dp(22), dp(22))
        ilp.bottomMargin = dp(4)
        c.addView(iv, ilp)
        c.addView(tv(label, 9f, if (active) "#BFEBFF" else MUTED, true))
        c.setOnClickListener { onClick() }
        return c
    }

    // ---------- handle (logo, docks to the edge)
    private fun showBubble() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        val b = ImageView(this)
        b.setImageResource(R.drawable.ic_bubble)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(dp(3), dp(3), dp(3), dp(3))
        b.background = shape("#E6080C14", 26, "#997FD8FF", 2)
        b.alpha = 0.95f

        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(110)
        bubbleLp = lp

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                        if (panel != null) closePanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    else {
                        val w = resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + size / 2 < w / 2) 0 else w - size
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                    }
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        ui.removeCallbacks(statsTick)
        tTemp = null; tBat = null; tRam = null; tClock = null; gauge = null
        panel?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        panel = null
    }

    // ---------- live stats
    private val statsTick = object : Runnable {
        override fun run() {
            if (panel == null) return
            updateStats()
            ui.postDelayed(this, 2000)
        }
    }

    private fun updateStats() {
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            tTemp?.text = String.format(Locale.US, "%.1f", t) + "\u00B0"
            tTemp?.setTextColor(Color.parseColor(if (t >= 42.0) "#FF8A80" else WHITE))
            gauge?.let { it.value = ((t - 25.0) / 25.0).toFloat(); it.hot = t >= 42.0; it.invalidate() }
            tBat?.text = if (pct >= 0) "BAT $pct%" else "BAT -"
            tRam?.text = "RAM " + (mi.availMem / (1024L * 1024L)).toString() + " MB"
            tClock?.text = java.text.SimpleDateFormat("hh:mm a", Locale.US).format(java.util.Date())
        } catch (e: Throwable) {}
    }

    private fun statCell(label: String): Pair<LinearLayout, TextView> {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(7), dp(4), dp(7))
        c.background = shape("#121A27", 16, "#25344A")
        val v = tv("-", 15f, WHITE, true)
        v.gravity = Gravity.CENTER
        c.addView(v)
        c.addView(tv(label, 8f, MUTED, true))
        return Pair(c, v)
    }

    // ---------- gauge (temperature ring)
    private inner class Gauge(ctx: Context) : View(ctx) {
        var value = 0f
        var hot = false
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()
        init {
            bg.style = Paint.Style.STROKE
            bg.color = Color.parseColor("#22344A")
            fg.style = Paint.Style.STROKE
            fg.strokeCap = Paint.Cap.ROUND
        }
        override fun onDraw(c: Canvas) {
            val s = dp(7).toFloat()
            bg.strokeWidth = s
            fg.strokeWidth = s
            fg.color = Color.parseColor(if (hot) "#FF8A80" else ACC)
            r.set(s, s, width - s, height - s)
            c.drawArc(r, 135f, 270f, false, bg)
            c.drawArc(r, 135f, 270f * value.coerceIn(0.02f, 1f), false, fg)
        }
    }

    // ---------- hex button for the HUD
    private fun hex(icon: Int, text: String?, label: String, active: Boolean, onLong: (() -> Unit)? = null, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(0, dp(3), 0, dp(3))
        val f = FrameLayout(this)
        f.setBackgroundResource(if (active) R.drawable.ic_hex_on else R.drawable.ic_hex)
        if (text != null) {
            val t = tv(text, 13f, if (active) "#BFEBFF" else WHITE, true)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(Color.parseColor(if (active) ACC else "#C8D3E6"))
            val ilp = FrameLayout.LayoutParams(dp(20), dp(20))
            ilp.gravity = Gravity.CENTER
            f.addView(iv, ilp)
        }
        c.addView(f, LinearLayout.LayoutParams(dp(44), dp(46)))
        val l = tv(label, 8.5f, if (active) "#BFEBFF" else MUTED, true)
        l.gravity = Gravity.CENTER
        l.maxLines = 1
        c.addView(l)
        c.setOnClickListener { onClick() }
        if (onLong != null) c.setOnLongClickListener { onLong(); true }
        return c
    }

    // ---------- assistant panel (HUD)
    private fun openPanel() {
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(dp(16), dp(12), dp(16), dp(12))
        holder.background = shape("#F20A111C", 26, "#597FD8FF", 1)
        panel = holder
        showMain()

        val sw = resources.displayMetrics.widthPixels
        val wide = sw >= dp(560)
        val width = if (wide) min(dp(640), sw - dp(60)) else min(dp(360), sw - dp(24))
        val lp = WindowManager.LayoutParams(
            width, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (wide) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.CENTER
        lp.y = if (wide) dp(8) else 0
        wm.addView(holder, lp)
        ui.removeCallbacks(statsTick)
        ui.postDelayed(statsTick, 2000)
    }

    @Suppress("DEPRECATION")
    private fun hzChoices(): List<Int> {
        var mx = 60
        try {
            for (m in wm.defaultDisplay.supportedModes) mx = maxOf(mx, Math.round(m.refreshRate))
        } catch (e: Throwable) {}
        val l = listOf(60, 90, 120, 144).filter { it <= mx + 1 }
        return if (l.isEmpty()) listOf(60) else l
    }

    private fun cycleHz() {
        val list = hzChoices()
        val cur = prefs.getInt("hzsel", if (hz > 0) hz else list.last())
        val i = list.indexOf(cur)
        val next = list[(i + 1) % list.size]
        prefs.edit().putInt("hzsel", next).apply()
        thread {
            val ok = shizukuSh("settings put system min_refresh_rate $next;settings put system peak_refresh_rate $next")
            toast(if (ok) "Refresh rate $next Hz" else "Start Shizuku (Tweaks tab) first")
        }
        showMain()
    }

    private val texLevels = intArrayOf(100, 85, 70, 55, 40)

    private fun cycleRes() {
        val k = "tex_" + pkgNow()
        val cur = prefs.getInt(k, 100)
        val i = texLevels.indexOf(cur)
        val next = texLevels[(i + 1) % texLevels.size]
        prefs.edit().putInt(k, next).apply()
        if (next < 100) { texOn = true; applyTex(next) } else { texOn = false; thread { shizukuSh("wm size reset;wm density reset") } }
        toast("Resolution $next%")
        showMain()
    }

    private fun showMain() {
        val holder = panel ?: return
        holder.removeAllViews()
        val wide = resources.displayMetrics.widthPixels >= dp(560)
        val mode = prefs.getInt("mode", 2)
        val resNow = prefs.getInt("tex_" + pkgNow(), 100)
        val hzNow = prefs.getInt("hzsel", if (hz > 0) hz else hzChoices().last())

        // header: clock in the middle, close at the right
        val head = FrameLayout(this)
        val clock = tv("", 11f, ACC, true)
        clock.letterSpacing = 0.2f
        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.CENTER
        head.addView(clock, cl)
        tClock = clock
        val x = tv("\u2715", 13f, "#FF8A80", true)
        x.gravity = Gravity.CENTER
        x.background = shape("#22FF5A5A", 15, "#99FF5A5A")
        x.setOnClickListener { closePanel() }
        val xl = FrameLayout.LayoutParams(dp(30), dp(30))
        xl.gravity = Gravity.END
        head.addView(x, xl)
        holder.addView(head)

        // buttons
        val bDnd = hex(R.drawable.ic_p_dnd, null, "DND", dnd) {
            thread {
                val want = !dnd
                val ok = shizukuSh("cmd notification set_dnd " + (if (want) "priority" else "off"))
                if (ok) dnd = want else toast("Start Shizuku (Tweaks tab) first")
                ui.post { if (panel != null) showMain() }
            }
        }
        val bSens = hex(R.drawable.ic_p_sens, null, "SENSITIVITY", false) { showSens() }
        val bXh = hex(R.drawable.ic_p_cross, null, "CROSSHAIR", xhOn, {
            val xo = xhNow()
            val cur = xo.optString("color", colors[0])
            xo.put("color", colors[(colors.indexOf(cur) + 1) % colors.size])
            if (xhOn) pushCrosshair()
            toast("Crosshair colour changed")
        }) {
            if (xhOn) { stopService(Intent(this, OverlayService::class.java)); xhOn = false } else pushCrosshair()
            showMain()
        }
        val bRam = hex(R.drawable.ic_p_ram, null, "CLEAN RAM", false) {
            toast("Cleaning...")
            thread { toast(if (shizukuSh("am kill-all")) "RAM cleaned" else "Start Shizuku (Tweaks tab) first") }
        }
        val bRes = hex(0, "$resNow%", "RESOLUTION", resNow < 100) { cycleRes() }
        val bShot = hex(R.drawable.ic_p_shot, null, "SCREENSHOT", false) { screenshot() }
        val bApp = hex(R.drawable.ic_p_app, null, "TO APP", false) {
            closePanel()
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) {}
        }
        val bOff = hex(R.drawable.ic_p_hide, null, "POWER OFF", false) { stopSelf() }
        val bTurbo = hex(R.drawable.ic_p_turbo, null, modeNames[mode], mode >= 2) {
            val i = (mode + 1) % 4
            prefs.edit().putInt("mode", i).apply()
            val pk = pkgNow()
            appliedPkg = if (i > 0) pk else null
            applyMode(i, pk)
            showMain()
        }
        val bHz = hex(0, "$hzNow", "REFRESH", true) { cycleHz() }
        val bRec = hex(R.drawable.ic_p_rec, null, if (Recorder.on) "STOP" else "RECORD", Recorder.on) {
            if (Recorder.on) Recorder.stop()
            else Recorder.start { ok -> toast(if (ok) "Recording saved in Movies/SensiHelper" else "Recording failed. Start Shizuku first") }
            ui.postDelayed({ if (panel != null) showMain() }, 400)
        }
        val bSize = hex(0, "\u00B1", "XH SIZE", false, { changeSize(-2.0) }) { changeSize(2.0) }

        // centre: temperature ring with RAM and battery under it
        val centre = LinearLayout(this)
        centre.orientation = LinearLayout.VERTICAL
        centre.gravity = Gravity.CENTER_HORIZONTAL
        val gf = FrameLayout(this)
        val g = Gauge(this)
        gauge = g
        gf.addView(g, FrameLayout.LayoutParams(dp(86), dp(86)))
        val tt = tv("-", 17f, WHITE, true)
        tt.gravity = Gravity.CENTER
        tTemp = tt
        gf.addView(tt, FrameLayout.LayoutParams(dp(86), dp(86)))
        centre.addView(gf)
        val ram = tv("RAM -", 10f, WHITE, true)
        ram.gravity = Gravity.CENTER
        val bat = tv("BAT -", 10f, WHITE, true)
        bat.gravity = Gravity.CENTER
        tRam = ram; tBat = bat
        centre.addView(ram)
        centre.addView(bat)

        if (wide) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val l = LinearLayout(this)
            l.orientation = LinearLayout.VERTICAL
            l.addView(hrow(bDnd, bSens, bXh))
            l.addView(hrow(bRam, bRes, bShot))
            val r = LinearLayout(this)
            r.orientation = LinearLayout.VERTICAL
            r.addView(hrow(bApp, bOff, bTurbo))
            r.addView(hrow(bHz, bRec, bSize))
            row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val cp = LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT)
            cp.setMargins(dp(8), 0, dp(8), 0)
            row.addView(centre, cp)
            row.addView(r, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            holder.addView(row)
        } else {
            holder.addView(centre)
            holder.addView(hrow(bDnd, bSens, bXh))
            holder.addView(hrow(bRam, bRes, bShot))
            holder.addView(hrow(bApp, bOff, bTurbo))
            holder.addView(hrow(bHz, bRec, bSize))
        }
        updateStats()

        // brightness and volume sliders
        val tint = ColorStateList.valueOf(Color.parseColor(ACC))
        val br = SeekBar(this)
        br.max = 255
        br.progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Throwable) { 128 }
        br.progressTintList = tint
        br.thumbTintList = tint
        br.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                val v = (s?.progress ?: 128).coerceIn(1, 255)
                thread { shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness $v") }
            }
        })
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val vol = SeekBar(this)
        vol.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        vol.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        vol.progressTintList = tint
        vol.thumbTintList = tint
        vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) } catch (e: Throwable) {}
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val sl = LinearLayout(this)
        sl.orientation = LinearLayout.HORIZONTAL
        sl.gravity = Gravity.CENTER_VERTICAL
        sl.setPadding(0, dp(6), 0, 0)
        sl.addView(tv("LIGHT", 8.5f, MUTED, true))
        sl.addView(br, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gap = View(this)
        sl.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        sl.addView(tv("VOLUME", 8.5f, MUTED, true))
        sl.addView(vol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        holder.addView(sl)
    }

    private fun showSens() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null
        val game = curGame()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = tv("SENSITIVITY  -  " + (game?.optString("name") ?: "").uppercase(Locale.US), 12f, WHITE, true)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val back = chip("BACK", true) { showMain() }
        head.addView(back, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(4))
        val vals = game?.optJSONArray("vals")
        if (vals == null || vals.length() == 0) {
            list.addView(tv("Open the Sensitivity tab in Sensi Helper first, then start the assistant again.", 12f, MUTED))
        } else {
            for (i in 0 until vals.length()) {
                val p = vals.optJSONArray(i) ?: continue
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.setPadding(0, dp(4), 0, dp(4))
                line.addView(tv(p.optString(0), 12f, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(tv(p.optString(1), 15f, WHITE, true))
                list.addView(line)
            }
        }
        val sc = ScrollView(this)
        sc.addView(list)
        val maxH = min(dp(250), resources.displayMetrics.heightPixels - dp(130))
        holder.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxH))
    }

    // ---------- actions
    private fun screenshot() {
        closePanel()
        val b = bubble
        b?.visibility = View.INVISIBLE
        ui.postDelayed({
            thread {
                val f = "/sdcard/Pictures/SensiHelper/shot_" + System.currentTimeMillis() + ".png"
                val ok = shizukuSh(
                    "mkdir -p /sdcard/Pictures/SensiHelper;screencap -p " + f +
                        ";am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + f
                )
                ui.post { b?.visibility = View.VISIBLE }
                toast(if (ok) "Screenshot saved in Pictures/SensiHelper" else "Start Shizuku (Tweaks tab) first")
            }
        }, 500)
    }

    private fun pushCrosshair() {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("x", xhNow().toString()))
        xhOn = true
    }

    private fun changeSize(d: Double) {
        val xo = xhNow()
        xo.put("size", (xo.optDouble("size", 10.0) + d).coerceIn(4.0, 40.0))
        if (xhOn) pushCrosshair()
    }

    override fun onDestroy() {
        if (profFor != null) endProfile()
        if (texOn) { texOn = false; thread { shizukuSh("wm size reset;wm density reset") } }
        ui.removeCallbacks(tick)
        restore()
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
        super.onDestroy()
    }
}

/** True when the user allowed "Usage access" for this app (needed to see which game is open). */
fun hasUsageAccess(ctx: Context): Boolean = try {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
    mode == AppOpsManager.MODE_ALLOWED
} catch (e: Throwable) { false }
