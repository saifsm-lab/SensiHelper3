package com.saif.sensihelper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max

/**
 * Floating game panel: a draggable bubble that stays on top of the game.
 * Tap the bubble to open a small panel with the saved sensitivity numbers,
 * crosshair controls and a "Clean RAM" button (Shizuku).
 */
class PanelService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var data = JSONObject()
    private var xh = JSONObject()
    private var xhOn = false
    private val ui = Handler(Looper.getMainLooper())
    private val colors = listOf("#27f0d6", "#3dff6a", "#ffe83a", "#ff4d5a", "#ffffff", "#ff6bd6")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("p")?.let {
            try {
                data = JSONObject(it)
                xh = data.optJSONObject("xh") ?: JSONObject()
            } catch (e: Throwable) {}
            showBubble()
        }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pn", "Game panel", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pn")
            .setContentTitle("Game panel is on")
            .setContentText("Tap to open Sensi Helper")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun round(color: String, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(color))
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun toast(t: String) {
        ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    }

    // ---------- bubble
    private fun showBubble() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        val b = TextView(this)
        b.text = "S"
        b.setTextColor(Color.WHITE)
        b.textSize = 18f
        b.typeface = Typeface.DEFAULT_BOLD
        b.gravity = Gravity.CENTER
        val bg = round("#CC5B5BD6", 24)
        bg.shape = GradientDrawable.OVAL
        bg.setStroke(dp(2), Color.WHITE)
        b.background = bg

        val lp = WindowManager.LayoutParams(
            dp(48), dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(160)
        bubbleLp = lp

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                        if (panel != null) closePanel()
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        panel = null
    }

    // ---------- panel
    private fun label(t: String, size: Float, color: String, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(Color.parseColor(color))
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun chip(text: String, onClick: (TextView) -> Unit): TextView {
        val t = label(text, 13f, "#FFFFFF", true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(9), dp(8), dp(9))
        t.background = round("#33FFFFFF", 12)
        t.setOnClickListener { onClick(t) }
        return t
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in views) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            r.addView(c, lp)
        }
        return r
    }

    private fun openPanel() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(12), dp(14), dp(12))
        root.background = round("#F0141A2B", 22)

        root.addView(label("Sensi Helper  -  " + data.optString("game"), 15f, "#FFFFFF", true))

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(6))
        val vals = data.optJSONArray("vals")
        if (vals == null || vals.length() == 0) {
            list.addView(label("Open the Sensitivity tab in Sensi Helper first, then show the panel again.", 12f, "#B9C0D8", false))
        } else {
            for (i in 0 until vals.length()) {
                val p = vals.optJSONArray(i) ?: continue
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.setPadding(0, dp(3), 0, dp(3))
                val name = label(p.optString(0), 12f, "#B9C0D8", false)
                val num = label(p.optString(1), 14f, "#C9C9FF", true)
                line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(num)
                list.addView(line)
            }
        }
        val sc = ScrollView(this)
        sc.addView(list)
        root.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)))

        root.addView(label("Crosshair", 12f, "#B9C0D8", false))
        val onBtn = chip(if (xhOn) "ON" else "OFF") { t ->
            if (xhOn) {
                stopService(Intent(this, OverlayService::class.java)); xhOn = false
            } else pushCrosshair()
            t.text = if (xhOn) "ON" else "OFF"
        }
        val minus = chip("Size -") { changeSize(-2.0) }
        val plus = chip("Size +") { changeSize(2.0) }
        val col = chip("Color") {
            val cur = xh.optString("color", colors[0])
            xh.put("color", colors[(colors.indexOf(cur) + 1) % colors.size])
            if (xhOn) pushCrosshair()
        }
        root.addView(row(onBtn, minus, plus, col))

        val clean = chip("Clean RAM") {
            toast("Cleaning...")
            thread { toast(shizukuExec("am kill-all")) }
        }
        val close = chip("Close") { closePanel() }
        val stop = chip("Hide bubble") { stopSelf() }
        root.addView(row(clean, close, stop))

        val w = resources.displayMetrics.widthPixels
        val lp = WindowManager.LayoutParams(
            dp(280), ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        val bx = bubbleLp?.x ?: 0
        lp.x = if (bx + dp(56) + dp(280) > w) max(0, bx - dp(288)) else bx + dp(56)
        lp.y = bubbleLp?.y ?: dp(160)
        wm.addView(root, lp)
        panel = root
    }

    private fun pushCrosshair() {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("x", xh.toString()))
        xhOn = true
    }

    private fun changeSize(d: Double) {
        xh.put("size", (xh.optDouble("size", 10.0) + d).coerceIn(4.0, 40.0))
        if (xhOn) pushCrosshair()
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
        super.onDestroy()
    }
}
