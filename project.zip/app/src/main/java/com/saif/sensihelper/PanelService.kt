package com.saif.sensihelper

import android.graphics.DashPathEffect
import android.widget.Switch
import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.SeekBar
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/**
 * Game Assistant (Red Magic style): a logo handle that docks to the screen edge while a game
 * is in front. Tap it to open the assistant: live temperature, battery and free RAM,
 * performance modes, Do Not Disturb, clean RAM, screenshot, crosshair and your sensitivity numbers.
 *
 * Data from the web page:
 * {"cur":"bs","hz":120,"games":{"bs":{"name","vals":[[n,v]],"xh":{..}},"ff":{..}}}
 */
class PanelService : Service() {

    private val ACC = "#7FD8FF"
    private val WHITE = "#FFFFFF"
    private val MUTED = "#9AA0B4"
    private val BS_PKG = "com.netease.newspike"
    private val FF_PKG = "com.dts.freefireth"
    private val modeNames = listOf("OFF", "STANDARD", "HIGH", "EXTREME")

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var data = JSONObject()
    private var curKey = "bs"
    private var hz = 0
    private val xhs = HashMap<String, JSONObject>()
    private var xhOn = false
    private var dnd = false
    private var auto = false
    private var lastFg: String? = null
    private var gamePkg: String? = null
    private var appliedPkg: String? = null
    private var texOn = false
    private var tickN = 0
    private var profFor: String? = null
    private var profHz = 0
    private var profDnd = false
    private var thermalOn = false
    private var thermalPkg: String? = null
    private var monView: TextView? = null
    private var monFps = -1
    private val guards = ArrayList<View>()
    private var tTemp: TextView? = null
    private var tBat: TextView? = null
    private var tRam: TextView? = null
    private var tClock: TextView? = null
    private var gauge: Gauge? = null
    private val ui = Handler(Looper.getMainLooper())
    private val colors = listOf("#27f0d6", "#3dff6a", "#ffe83a", "#ff4d5a", "#ffffff", "#ff6bd6")
    private val prefs by lazy { getSharedPreferences("gs", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("p")?.let {
            try {
                data = JSONObject(it)
                curKey = data.optString("cur", "bs")
                hz = data.optInt("hz", 0).let { v -> if (v in 30..240) v else 0 }
                xhs.clear()
            } catch (e: Throwable) {}
            ui.removeCallbacks(tick)
            auto = intent?.getBooleanExtra("auto", false) ?: false
            if (auto) { hideAll(); ui.post(tick) } else showBubble()
        }
        return START_NOT_STICKY
    }

    // ---------- per-game data
    private fun curGame(): JSONObject? = data.optJSONObject("games")?.optJSONObject(curKey)

    private fun xhNow(): JSONObject = xhs.getOrPut(curKey) {
        JSONObject(curGame()?.optJSONObject("xh")?.toString() ?: "{}")
    }

    private fun keyFor(pkg: String): String? = when {
        pkg == BS_PKG -> "bs"
        pkg.startsWith("com.dts.freefire") -> "ff"
        else -> null
    }

    private fun pkgNow(): String {
        val p = gamePkg ?: (if (curKey == "bs") BS_PKG else FF_PKG)
        return if (Regex("[a-zA-Z0-9_.]+").matches(p)) p else FF_PKG
    }

    // ---------- performance modes (same commands as the Tweaks tab)
    private fun cmdFor(mode: Int, pkg: String): String {
        val on1 = "cmd game mode performance $pkg;cmd notification set_dnd priority"
        val on2 = on1 +
            ";settings put global window_animation_scale 0.5;settings put global transition_animation_scale 0.5" +
            ";settings put global animator_duration_scale 0.5;cmd deviceidle whitelist +$pkg" +
            (if (hz > 0) ";settings put system min_refresh_rate $hz;settings put system peak_refresh_rate $hz" else "")
        val off = "cmd game reset $pkg;cmd notification set_dnd off" +
            ";settings put global window_animation_scale 1;settings put global transition_animation_scale 1" +
            ";settings put global animator_duration_scale 1;cmd deviceidle whitelist -$pkg" +
            ";settings delete system min_refresh_rate;settings delete system peak_refresh_rate" +
            ";cmd power set-fixed-performance-mode-enabled false"
        return when (mode) {
            1 -> "$off;$on1"
            2 -> "$off;$on2"
            3 -> "$off;$on2;cmd power set-fixed-performance-mode-enabled true"
            else -> off
        }
    }

    private fun applyMode(mode: Int, pkg: String) {
        thread {
            val ok = shizukuSh(cmdFor(mode, pkg))
            if (ok) {
                dnd = mode > 0
                toast(if (mode > 0) "Game Space: " + modeNames[mode] else "Performance mode off")
            } else toast("Start Shizuku (Tweaks tab) to use performance modes")
        }
    }

    // ---------- thermal protection
    private fun checkThermal(pkg: String) {
        if (!prefs.getBoolean("thermal", false)) { if (thermalOn) endThermal(); return }
        val lim = prefs.getInt("thermal_t", 44)
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        if (!thermalOn && t >= lim) {
            thermalOn = true
            thermalPkg = pkg
            thread { shizukuSh("settings put system min_refresh_rate 60;settings put system peak_refresh_rate 60;cmd game mode standard $pkg") }
            toast("Phone is hot. Performance lowered.")
        } else if (thermalOn && t <= lim - 3) endThermal()
    }

    private fun endThermal() {
        thermalOn = false
        val pk = thermalPkg
        thermalPkg = null
        val hzSet = profHz
        val m = prefs.getInt("mode", 2)
        thread {
            shizukuSh(if (hzSet > 0) "settings put system min_refresh_rate $hzSet;settings put system peak_refresh_rate $hzSet"
                else "settings delete system min_refresh_rate;settings delete system peak_refresh_rate")
        }
        if (pk != null && m > 0 && prefs.getBoolean("auto", false)) applyMode(m, pk)
    }

    // ---------- per-game profile
    private fun applyProfile(pkg: String) {
        val o = try { JSONObject(prefs.getString("prof_$pkg", "{}") ?: "{}") } catch (e: Throwable) { JSONObject() }
        profHz = o.optInt("hz", 0)
        profDnd = o.optBoolean("dnd", false)
        val clean = o.optBoolean("ram", false)
        val hzNow = profHz
        val dndNow = profDnd
        thread {
            if (hzNow > 0) shizukuSh("settings put system min_refresh_rate $hzNow;settings put system peak_refresh_rate $hzNow")
            if (dndNow) shizukuSh("cmd notification set_dnd priority")
            if (clean) shizukuSh("am kill-all")
        }
        if (o.optBoolean("mon", false)) ui.post { showMonitor() }
        if (o.optBoolean("guard", false)) ui.post { showGuards() }
    }

    private fun endProfile() {
        val hzSet = profHz > 0
        val dndSet = profDnd
        profFor = null
        profHz = 0
        profDnd = false
        hideMonitor()
        hideGuards()
        thread {
            if (hzSet) shizukuSh("settings delete system min_refresh_rate;settings delete system peak_refresh_rate")
            if (dndSet) shizukuSh("cmd notification set_dnd off")
        }
    }

    // ---------- floating monitor (FPS is best effort)
    private fun readFps(pkg: String): Int {
        return try {
            val list = shizukuOut("dumpsys SurfaceFlinger --list")
            val layer = (list.lines().firstOrNull { it.contains(pkg) && it.contains("SurfaceView") }
                ?: list.lines().firstOrNull { it.contains(pkg) })?.trim() ?: return -1
            if (!Regex("[A-Za-z0-9_.#()\\[\\]/:\\- ]+").matches(layer)) return -1
            val out = shizukuOut("dumpsys SurfaceFlinger --latency \"$layer\"")
            val ts = out.lines().drop(1).mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
                .filter { it > 0L && it < Long.MAX_VALUE / 2 }
            if (ts.size < 2) return -1
            val span = ts.last() - ts.first()
            if (span <= 0L) -1 else Math.round((ts.size - 1) * 1e9 / span).toInt()
        } catch (e: Throwable) { -1 }
    }

    private val monTick = object : Runnable {
        override fun run() {
            val v = monView ?: return
            try {
                val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
                val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                val fps = if (monFps > 0) "$monFps FPS" else "FPS -"
                v.text = fps + "   " + String.format(Locale.US, "%.1f", t) + "\u00B0   RAM " + (mi.availMem / 1048576L) + "M   " + lvl + "%"
            } catch (e: Throwable) {}
            ui.postDelayed(this, 1000)
        }
    }

    private val fpsTick = object : Runnable {
        override fun run() {
            val pk = profFor ?: gamePkg
            if (monView == null || pk == null) return
            thread { monFps = readFps(pk) }
            ui.postDelayed(this, 2500)
        }
    }

    private fun showMonitor() {
        if (monView != null) return
        val v = tv("FPS -", 10f, WHITE, true)
        v.setPadding(dp(10), dp(5), dp(10), dp(5))
        v.background = shape("#B3070C14", 14, "#4D7FD8FF", 1)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(70)
        lp.y = dp(6)
        try { wm.addView(v, lp); monView = v } catch (e: Throwable) { return }
        monFps = -1
        ui.post(monTick)
        ui.post(fpsTick)
    }

    private fun hideMonitor() {
        ui.removeCallbacks(monTick)
        ui.removeCallbacks(fpsTick)
        monView?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        monView = null
    }

    // ---------- edge guards (anti-mistouch strips)
    private fun showGuards() {
        hideGuards()
        for (left in booleanArrayOf(true, false)) {
            val v = View(this)
            v.setBackgroundColor(Color.parseColor("#14FFFFFF"))
            v.setOnTouchListener { _, _ -> true }
            val lp = WindowManager.LayoutParams(
                dp(16), ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = (if (left) Gravity.START else Gravity.END) or Gravity.TOP
            try { wm.addView(v, lp); guards.add(v) } catch (e: Throwable) {}
        }
    }

    private fun hideGuards() {
        for (v in guards) try { wm.removeView(v) } catch (e: Throwable) {}
        guards.clear()
    }

    private fun restore() {
        val p = appliedPkg ?: return
        appliedPkg = null
        dnd = false
        thread { shizukuSh(cmdFor(0, p)) }
    }

    // ---------- auto mode: assistant only while a supported game is in front
    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            val fg = foregroundPkg()
            if (fg != null) {
                val k = keyFor(fg)
                if (k != null) {
                    gamePkg = fg
                    if (bubble == null) { curKey = k; showBubble() }
                    else if (k != curKey) { curKey = k; closePanel() }
                    val m = prefs.getInt("mode", 2)
                    if (prefs.getBoolean("auto", false) && m > 0 && appliedPkg != fg) {
                        appliedPkg = fg
                        applyMode(m, fg)
                    }
                    val wantScr = prefs.getInt("tex_$fg", 100) < 100 || prefs.getInt("str_$fg", 0) > 0 || prefs.getInt("sty_$fg", 0) > 0
                    if (wantScr && !texOn) { texOn = true; applyScreen(fg) }
                    else if (!wantScr && texOn) { texOn = false; resetScreen() }
                    prefs.edit().putBoolean("ingame", true).putLong("ingameAt", System.currentTimeMillis()).apply()
                    if (profFor != fg) { profFor = fg; applyProfile(fg) }
                    checkThermal(fg)
                } else if (fg != packageName) {
                    if (bubble != null) hideAll()
                    if (profFor != null) endProfile()
                    if (thermalOn) endThermal()
                    restore()
                    if (texOn) { texOn = false; resetScreen() }
                    prefs.edit().putBoolean("ingame", false).apply()
                } else if (texOn) {
                    // our own app is in front: show it at the normal screen size
                    texOn = false
                    resetScreen()
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    @Suppress("DEPRECATION")
    private fun foregroundPkg(): String? {
        return try {
            val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(now - 20000, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName
            }
            lastFg
        } catch (t: Throwable) { lastFg }
    }

    private fun hideAll() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pn", "Game panel", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pn")
            .setContentTitle("Game Assistant is on")
            .setContentText("Tap to open Sensi Helper")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(3, n)
    }

    // ---------- small view helpers
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(fill: String, r: Int, stroke: String? = null, sw: Int = 1): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(Color.parseColor(fill))
        g.cornerRadius = dp(r).toFloat()
        if (stroke != null) g.setStroke(dp(sw), Color.parseColor(stroke))
        return g
    }

    private fun toast(t: String) {
        ui.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() }
    }

    private fun tv(t: String, sp: Float, color: String, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(Color.parseColor(color))
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun lp1(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
        return lp
    }

    private fun hrow(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (c in views) r.addView(c, lp1())
        return r
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val t = tv(text, 11f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.letterSpacing = 0.06f
        t.setPadding(dp(4), dp(9), dp(4), dp(9))
        t.setTextColor(Color.parseColor(if (selected) "#031018" else WHITE))
        t.background = if (selected) shape(ACC, 16) else shape("#16202E", 16, "#25344A")
        t.setOnClickListener { onClick() }
        return t
    }

    private fun tile(icon: Int, label: String, active: Boolean, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(11), dp(4), dp(10))
        c.background = if (active) shape("#307FD8FF", 18, ACC) else shape("#121A27", 18, "#25344A")
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.parseColor(if (active) ACC else "#C8D3E6"))
        val ilp = LinearLayout.LayoutParams(dp(22), dp(22))
        ilp.bottomMargin = dp(4)
        c.addView(iv, ilp)
        c.addView(tv(label, 9f, if (active) "#BFEBFF" else MUTED, true))
        c.setOnClickListener { onClick() }
        return c
    }

    // ---------- handle (logo, docks to the edge)
    private fun showBubble() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        val b = ImageView(this)
        b.setImageResource(R.drawable.ic_bubble)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(dp(3), dp(3), dp(3), dp(3))
        b.background = shape("#E6080C14", 26, "#997FD8FF", 2)
        b.alpha = 0.95f

        val size = dp(52)
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = dp(110)
        bubbleLp = lp

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        lp.x = sx + dx; lp.y = sy + dy
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                        if (panel != null) closePanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    else {
                        val w = resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + size / 2 < w / 2) 0 else w - size
                        try { wm.updateViewLayout(b, lp) } catch (ex: Throwable) {}
                    }
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        ui.removeCallbacks(statsTick)
        tTemp = null; tBat = null; tRam = null; tClock = null; gauge = null
        panel?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        panel = null
    }

    // ---------- live stats
    private val statsTick = object : Runnable {
        override fun run() {
            if (panel == null) return
            updateStats()
            ui.postDelayed(this, 2000)
        }
    }

    private fun updateStats() {
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val t = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            tTemp?.text = String.format(Locale.US, "%.1f", t) + "\u00B0"
            tTemp?.setTextColor(Color.parseColor(if (t >= 42.0) "#FF8A80" else WHITE))
            gauge?.let { it.value = ((t - 25.0) / 25.0).toFloat(); it.hot = t >= 42.0; it.invalidate() }
            tBat?.text = if (pct >= 0) "BAT $pct%" else "BAT -"
            tRam?.text = "RAM " + (mi.availMem / (1024L * 1024L)).toString() + " MB"
            tClock?.text = java.text.SimpleDateFormat("hh:mm a", Locale.US).format(java.util.Date())
        } catch (e: Throwable) {}
    }

    private fun statCell(label: String): Pair<LinearLayout, TextView> {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.setPadding(dp(4), dp(7), dp(4), dp(7))
        c.background = shape("#121A27", 16, "#25344A")
        val v = tv("-", 15f, WHITE, true)
        v.gravity = Gravity.CENTER
        c.addView(v)
        c.addView(tv(label, 8f, MUTED, true))
        return Pair(c, v)
    }

    // ---------- gauge (temperature ring)
    private inner class Gauge(ctx: Context) : View(ctx) {
        var value = 0f
        var hot = false
        private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val fg = Paint(Paint.ANTI_ALIAS_FLAG)
        private val r = RectF()
        init {
            bg.style = Paint.Style.STROKE
            bg.color = Color.parseColor("#22344A")
            fg.style = Paint.Style.STROKE
            fg.strokeCap = Paint.Cap.ROUND
        }
        override fun onDraw(c: Canvas) {
            val s = dp(7).toFloat()
            bg.strokeWidth = s
            fg.strokeWidth = s
            fg.color = Color.parseColor(if (hot) "#FF8A80" else ACC)
            r.set(s, s, width - s, height - s)
            c.drawArc(r, 135f, 270f, false, bg)
            c.drawArc(r, 135f, 270f * value.coerceIn(0.02f, 1f), false, fg)
        }
    }

    // ---------- tiles for the assistant panel
    private fun iconBtn(icon: Int, tint: String, onClick: () -> Unit): ImageView {
        val v = ImageView(this)
        v.setImageResource(icon)
        v.setColorFilter(Color.parseColor(tint))
        v.setPadding(dp(7), dp(7), dp(7), dp(7))
        v.background = shape("#1B2231", 16, "#2A3348")
        v.setOnClickListener { onClick() }
        return v
    }

    private fun tile(icon: Int, value: String?, label: String, active: Boolean, onLong: (() -> Unit)? = null, onClick: () -> Unit): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.minimumHeight = dp(58)
        c.setPadding(dp(2), dp(7), dp(2), dp(6))
        c.background = if (active) shape("#2B7FD8FF", 14, ACC, 1) else shape("#161C28", 14, "#262F42", 1)
        if (value != null) {
            val t = tv(value, 14f, if (active) "#CFF0FF" else WHITE, true)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            c.addView(t)
        } else {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            iv.setColorFilter(Color.parseColor(if (active) ACC else "#C8D3E6"))
            c.addView(iv, LinearLayout.LayoutParams(dp(22), dp(22)))
        }
        val l = tv(label, 8.5f, if (active) "#BFEBFF" else MUTED, true)
        l.gravity = Gravity.CENTER
        l.maxLines = 1
        l.setPadding(0, dp(3), 0, 0)
        c.addView(l)
        c.setOnClickListener { onClick() }
        if (onLong != null) c.setOnLongClickListener { onLong(); true }
        return c
    }

    private fun grid(items: List<View>, cols: Int): LinearLayout {
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until cols) {
                val v: View = if (i + c < items.size) items[i + c] else View(this)
                row.addView(v, lp1())
            }
            g.addView(row)
            i += cols
        }
        return g
    }

    private fun strLabel(sx: Int, sy: Int): String = when {
        sx == 0 && sy == 0 -> "OFF"
        sy == 0 -> fmtMult(sx)
        sx == 0 -> fmtMult(sy)
        sx == sy -> fmtMult(sx)
        else -> "CUSTOM"
    }

    private fun toggleRecord() {
        if (Recorder.on) {
            Recorder.stop()
            toast("Saving the recording...")
            ui.postDelayed({ if (panel != null) showMain() }, 1500)
            return
        }
        closePanel()
        Recorder.start { ok -> toast(if (ok) "Recording saved in Movies/SensiHelper" else "Recording failed. Start Shizuku first") }
        toast("Recording started. Open the panel and tap STOP REC to finish.")
    }

    // ---------- assistant panel (HUD)
    private fun openPanel() {
        val holder = LinearLayout(this)
        holder.orientation = LinearLayout.VERTICAL
        holder.setPadding(dp(16), dp(12), dp(16), dp(12))
        holder.background = shape("#F20D131D", 22, "#2B3547", 1)
        panel = holder
        showMain()

        val sw = resources.displayMetrics.widthPixels
        val wide = sw >= dp(560)
        val width = if (wide) min(dp(720), sw - dp(40)) else min(dp(380), sw - dp(24))
        val lp = WindowManager.LayoutParams(
            width, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (wide) (Gravity.TOP or Gravity.CENTER_HORIZONTAL) else Gravity.CENTER
        lp.y = if (wide) dp(8) else 0
        wm.addView(holder, lp)
        ui.removeCallbacks(statsTick)
        ui.postDelayed(statsTick, 2000)
    }

    @Suppress("DEPRECATION")
    private fun hzChoices(): List<Int> {
        var mx = 60
        try {
            for (m in wm.defaultDisplay.supportedModes) mx = maxOf(mx, Math.round(m.refreshRate))
        } catch (e: Throwable) {}
        val l = listOf(60, 90, 120, 144).filter { it <= mx + 1 }
        return if (l.isEmpty()) listOf(60) else l
    }

    private fun cycleHz() {
        val list = hzChoices()
        val cur = prefs.getInt("hzsel", if (hz > 0) hz else list.last())
        val i = list.indexOf(cur)
        val next = list[(i + 1) % list.size]
        prefs.edit().putInt("hzsel", next).apply()
        thread {
            val ok = shizukuSh("settings put system min_refresh_rate $next;settings put system peak_refresh_rate $next")
            toast(if (ok) "Refresh rate $next Hz" else "Start Shizuku (Tweaks tab) first")
        }
        showMain()
    }

    private val texLevels = intArrayOf(100, 85, 70, 55, 40)

    // ---------- screen size: lower resolution and/or stretch, only while the game is in front
    private val screenExec = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun snapshotScreen() {
        // remember what the user had before we touch anything (skip if our own change may still be on)
        if (prefs.getBoolean("wm_dirty", false)) return
        val us = Regex("Override size:\\s*(\\d+x\\d+)").find(shizukuOut("wm size"))?.groupValues?.get(1) ?: ""
        val ud = Regex("Override density:\\s*(\\d+)").find(shizukuOut("wm density"))?.groupValues?.get(1) ?: ""
        prefs.edit().putString("user_size", us).putString("user_density", ud).apply()
    }

    private fun applyScreen(pkg: String) {
        screenExec.execute {
            try {
                snapshotScreen()
                val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
                val dn = Regex("Physical density:\\s*(\\d+)").find(shizukuOut("wm density"))
                if (sz == null || dn == null) { texOn = false; return@execute }
                val pw = sz.groupValues[1].toInt()
                val ph = sz.groupValues[2].toInt()
                var lo = minOf(pw, ph)
                var hi = maxOf(pw, ph)
                val sx = prefs.getInt("str_$pkg", 0)
                val sy = prefs.getInt("sty_$pkg", 0)
                // picture size = native size / stretch. Above 1.00x the picture is smaller, so things look wider and bigger.
                // Below 1.00x it is larger, so you see more but things look thinner.
                if (sx in 70..140 && sx != 100) hi = (hi * 100 / sx).coerceIn(hi / 2, hi * 2)
                if (sy in 70..140 && sy != 100) lo = (lo * 100 / sy).coerceIn(lo / 2, lo * 2)
                val pct = prefs.getInt("tex_$pkg", 100)
                val lo2 = (lo * pct / 100 / 2) * 2
                val hi2 = (hi * pct / 100 / 2) * 2
                val w = if (pw <= ph) lo2 else hi2
                val h = if (pw <= ph) hi2 else lo2
                prefs.edit().putBoolean("wm_dirty", true).apply()
                val ok = if (pct < 100) {
                    // density scales with the size so buttons and text keep the same on-screen size
                    val base = prefs.getString("user_density", "")?.toIntOrNull() ?: dn.groupValues[1].toInt()
                    shizukuSh("wm size ${w}x${h};wm density ${maxOf(120, base * pct / 100)}")
                } else {
                    shizukuSh("wm size ${w}x${h}")
                }
                if (ok) ui.post {
                    if (sx > 0 || sy > 0) startVolWatch()
                    if (sx in 70..99 && prefs.getBoolean("safe_on", true)) showSafeArea(sx / 100f) else hideSafeArea()
                }
            } catch (e: Throwable) { texOn = false }
        }
    }

    private fun resetScreen() {
        ui.post { stopVolWatch(); hideSafeArea() }
        screenExec.execute {
            if (shizukuSh(restoreScreenCmd(prefs))) prefs.edit().putBoolean("wm_dirty", false).apply()
        }
    }

    /** Applies or removes the screen change for the current game, from its saved resolution and stretch. */
    private fun refreshScreen() {
        val p = pkgNow()
        val want = prefs.getInt("tex_$p", 100) < 100 || prefs.getInt("str_$p", 0) > 0 || prefs.getInt("sty_$p", 0) > 0
        if (want && !auto) {
            toast("Turn on Auto Game Assistant (Home page) first, so the screen goes back when you leave the game")
            return
        }
        if (want) { texOn = true; applyScreen(p) } else { texOn = false; resetScreen() }
    }

    private fun fmtMult(v: Int): String = String.format(Locale.US, "%.2fx", v / 100.0)

    // ---------- safe-area guide (purple bands show the extra stretched part)
    private var safeView: View? = null

    private inner class SafeView(c: Context, private val frac: Float) : View(c) {
        private val band = Paint().apply { color = Color.parseColor("#44A020F0") }
        private val line = Paint().apply {
            color = Color.parseColor("#CCC77DFF")
            strokeWidth = dp(2).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(dp(8).toFloat(), dp(6).toFloat()), 0f)
        }
        private val pill = Paint().apply { color = Color.parseColor("#E61B1030"); isAntiAlias = true }
        private val txt = Paint().apply {
            color = Color.WHITE
            textSize = dp(12).toFloat()
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val half = w * frac / 2f
            val l = w / 2f - half
            val r = w / 2f + half
            cv.drawRect(0f, 0f, l, h, band)
            cv.drawRect(r, 0f, w, h, band)
            cv.drawLine(l, 0f, l, h, line)
            cv.drawLine(r, 0f, r, h, line)
            val label = "SAFE AREA FOR HUD"
            val tw = txt.measureText(label)
            cv.drawRoundRect(w / 2f - tw / 2f - dp(14), dp(6).toFloat(), w / 2f + tw / 2f + dp(14), dp(34).toFloat(), dp(14).toFloat(), dp(14).toFloat(), pill)
            cv.drawText(label, w / 2f, dp(25).toFloat(), txt)
        }
    }

    private fun showSafeArea(mult: Float) {
        hideSafeArea()
        val v = SafeView(this, 1f / mult)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, lp); safeView = v } catch (e: Throwable) {}
    }

    private fun hideSafeArea() {
        safeView?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        safeView = null
    }

    // ---------- emergency restore: press Volume + while the screen is stretched
    private var volProc: Process? = null
    private var volThread: Thread? = null

    private fun startVolWatch() {
        if (volThread != null) return
        volThread = thread {
            try {
                val p = shizukuProc("getevent -l")
                if (p == null) { volThread = null; return@thread }
                volProc = p
                val r = p.inputStream.bufferedReader()
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.contains("KEY_VOLUMEUP") && line.contains("DOWN")) ui.post { emergencyRestore() }
                }
            } catch (e: Throwable) {
            } finally {
                volProc = null
                volThread = null
            }
        }
    }

    private fun stopVolWatch() {
        try { volProc?.destroy() } catch (e: Throwable) {}
    }

    private fun emergencyRestore() {
        val pk = pkgNow()
        prefs.edit().putInt("str_$pk", 0).putInt("sty_$pk", 0).putInt("tex_$pk", 100).apply()
        texOn = false
        resetScreen()
        toast("Screen restored")
        if (panel != null) showMain()
    }

    // ---------- the stretched-screen popup
    private class StretchRow(val box: LinearLayout, val bar: SeekBar)

    private fun stretchRow(title: String, start: Int, onChange: (Int) -> Unit): StretchRow {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(tv(title, 10f, MUTED, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val value = tv(fmtMult(start), 18f, WHITE, true)
        top.addView(value)
        box.addView(top)
        val tint = ColorStateList.valueOf(Color.parseColor(ACC))
        val sb = SeekBar(this)
        sb.max = 70
        sb.progress = (start - 70).coerceIn(0, 70)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                value.text = fmtMult(70 + p)
                onChange(70 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb)
        return StretchRow(box, sb)
    }

    private fun showStretch() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null; tClock = null; gauge = null
        val pk = pkgNow()
        val wide = resources.displayMetrics.widthPixels >= dp(560)
        var cx = prefs.getInt("str_$pk", 0).let { if (it in 70..140) it else 100 }
        var cy = prefs.getInt("sty_$pk", 0).let { if (it in 70..140) it else 100 }
        var hiPx = 0
        var loPx = 0
        val nat = tv("-", 13f, WHITE, true)
        val canvas = tv("-", 13f, WHITE, true)
        fun showCanvas() {
            if (hiPx > 0) canvas.text = (hiPx * 100 / cx).toString() + " x " + (loPx * 100 / cy)
        }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("STRETCHED SCREEN", 13f, WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(chip("BACK", true) { showMain() }, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val rowX = stretchRow("WIDTH", cx) { cx = it; showCanvas() }
        val rowY = stretchRow("HEIGHT", cy) { cy = it; showCanvas() }
        fun preset(a: Int, b: Int) {
            cx = a
            cy = b
            rowX.bar.progress = a - 70
            rowY.bar.progress = b - 70
            showCanvas()
        }
        val presets = hrow(
            chip("NORMAL", false) { preset(100, 100) },
            chip("SEE MORE", false) { preset(80, 100) },
            chip("WIDER", false) { preset(125, 100) },
            chip("ALL SIDES", false) { preset(120, 120) }
        )
        holder.addView(presets, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.setMargins(0, dp(8), 0, dp(4)) })
        if (wide) holder.addView(hrow(rowX.box, rowY.box)) else { holder.addView(rowX.box); holder.addView(rowY.box) }

        fun col(label: String, v: TextView): LinearLayout {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.addView(tv(label, 10f, MUTED, true))
            c.addView(v)
            return c
        }
        holder.addView(hrow(col("NATIVE", nat), col("PICTURE SIZE", canvas)))
        thread {
            val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
            val a = sz?.groupValues?.get(1)?.toInt() ?: resources.displayMetrics.widthPixels
            val b = sz?.groupValues?.get(2)?.toInt() ?: resources.displayMetrics.heightPixels
            hiPx = maxOf(a, b)
            loPx = minOf(a, b)
            ui.post { nat.text = "$hiPx x $loPx"; showCanvas() }
        }

        val btnApply = chip("APPLY", true) {
            if (cx == 100 && cy == 100) { toast("Move a slider first"); return@chip }
            prefs.edit().putInt("str_$pk", if (cx == 100) 0 else cx).putInt("sty_$pk", if (cy == 100) 0 else cy).apply()
            refreshScreen()
        }
        val btnRestore = chip("RESTORE", false) {
            prefs.edit().putInt("str_$pk", 0).putInt("sty_$pk", 0).apply()
            preset(100, 100)
            refreshScreen()
            hideSafeArea()
            toast("Screen restored")
        }
        holder.addView(hrow(btnApply, btnRestore))

        val sw = Switch(this)
        sw.text = "Show safe area for HUD (when below 1.00x)"
        sw.setTextColor(Color.parseColor(WHITE))
        sw.textSize = 11f
        sw.isChecked = prefs.getBoolean("safe_on", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("safe_on", on).apply()
            val m = prefs.getInt("str_$pk", 0)
            if (on && texOn && m in 70..99) showSafeArea(m / 100f) else hideSafeArea()
        }
        holder.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(tv("Above 1.00x: things look wider and bigger, you see less. Below 1.00x: you see more, things look thinner. WIDTH is left to right, HEIGHT is top to bottom, so ALL SIDES stretches both. Emergency restore: press VOLUME + while the screen is stretched.", 9.5f, MUTED))
    }

    private fun cycleRes() {
        val k = "tex_" + pkgNow()
        val cur = prefs.getInt(k, 100)
        val i = texLevels.indexOf(cur)
        val next = texLevels[(i + 1) % texLevels.size]
        prefs.edit().putInt(k, next).apply()
        refreshScreen()
        toast("Resolution $next%")
        showMain()
    }

    private fun showMain() {
        val holder = panel ?: return
        holder.removeAllViews()
        val wide = resources.displayMetrics.widthPixels >= dp(560)
        val mode = prefs.getInt("mode", 2)
        val pk = pkgNow()
        val resNow = prefs.getInt("tex_$pk", 100)
        val hzNow = prefs.getInt("hzsel", if (hz > 0) hz else hzChoices().last())
        val sx = prefs.getInt("str_$pk", 0)
        val sy = prefs.getInt("sty_$pk", 0)
        val thOn = prefs.getBoolean("thermal", false)
        val gameName = (curGame()?.optString("name") ?: "").uppercase(Locale.US)

        // ---- header: title and game, mode pill, clock, app / power / close
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val ttl = LinearLayout(this)
        ttl.orientation = LinearLayout.VERTICAL
        val t1 = tv("GAME ASSISTANT", 9.5f, ACC, true)
        t1.letterSpacing = 0.2f
        ttl.addView(t1)
        ttl.addView(tv(gameName, 14f, WHITE, true))
        head.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val pill = tv(modeNames[mode], 9.5f, if (mode > 0) "#BFEBFF" else MUTED, true)
        pill.gravity = Gravity.CENTER
        pill.setPadding(dp(10), dp(4), dp(10), dp(4))
        pill.background = shape(if (mode > 0) "#2B7FD8FF" else "#1B2231", 12, if (mode > 0) ACC else "#2A3348")
        head.addView(pill)
        val clock = tv("", 11f, WHITE, true)
        clock.setPadding(dp(12), 0, dp(8), 0)
        tClock = clock
        head.addView(clock)
        fun addBtn(v: View) {
            val lp = LinearLayout.LayoutParams(dp(32), dp(32))
            lp.setMargins(dp(4), 0, 0, 0)
            head.addView(v, lp)
        }
        addBtn(iconBtn(R.drawable.ic_p_app, "#C8D3E6") {
            closePanel()
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) {}
        })
        addBtn(iconBtn(R.drawable.ic_p_hide, "#FF8A80") { stopSelf() })
        val x = tv("\u2715", 13f, "#FF8A80", true)
        x.gravity = Gravity.CENTER
        x.background = shape("#22FF5A5A", 16, "#99FF5A5A")
        x.setOnClickListener { closePanel() }
        addBtn(x)
        holder.addView(head)
        val line = View(this)
        line.setBackgroundColor(Color.parseColor("#222B3B"))
        val ll = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
        ll.setMargins(0, dp(8), 0, dp(6))
        holder.addView(line, ll)

        // ---- left: temperature ring, RAM and battery
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_HORIZONTAL
        val gf = FrameLayout(this)
        val g = Gauge(this)
        gauge = g
        gf.addView(g, FrameLayout.LayoutParams(dp(80), dp(80)))
        val tt = tv("-", 16f, WHITE, true)
        tt.gravity = Gravity.CENTER
        tTemp = tt
        gf.addView(tt, FrameLayout.LayoutParams(dp(80), dp(80)))
        left.addView(gf)
        val ram = tv("RAM -", 9.5f, WHITE, true)
        ram.gravity = Gravity.CENTER
        val bat = tv("BAT -", 9.5f, WHITE, true)
        bat.gravity = Gravity.CENTER
        tRam = ram
        tBat = bat
        left.addView(ram)
        left.addView(bat)

        // ---- tiles
        val tiles = ArrayList<View>()
        tiles.add(tile(R.drawable.ic_p_dnd, null, "DND", dnd) {
            thread {
                val want = !dnd
                val ok = shizukuSh("cmd notification set_dnd " + (if (want) "priority" else "off"))
                if (ok) dnd = want else toast("Start Shizuku (Tweaks tab) first")
                ui.post { if (panel != null) showMain() }
            }
        })
        tiles.add(tile(R.drawable.ic_p_shot, null, "SCREENSHOT", false) { screenshot() })
        tiles.add(tile(R.drawable.ic_p_rec, null, if (Recorder.on) "STOP REC" else "RECORD", Recorder.on) { toggleRecord() })
        tiles.add(tile(R.drawable.ic_p_ram, null, "CLEAN RAM", false) {
            toast("Cleaning...")
            thread { toast(if (shizukuSh("am kill-all")) "RAM cleaned" else "Start Shizuku (Tweaks tab) first") }
        })
        tiles.add(tile(R.drawable.ic_p_cross, null, "CROSSHAIR", xhOn, {
            val xo = xhNow()
            val cur = xo.optString("color", colors[0])
            xo.put("color", colors[(colors.indexOf(cur) + 1) % colors.size])
            if (xhOn) pushCrosshair()
            toast("Crosshair colour changed")
        }) {
            if (xhOn) { stopService(Intent(this, OverlayService::class.java)); xhOn = false } else pushCrosshair()
            showMain()
        })
        tiles.add(tile(R.drawable.ic_p_size, null, "XH SIZE", false, { changeSize(-2.0) }) { changeSize(2.0) })
        tiles.add(tile(R.drawable.ic_p_mon, null, "MONITOR", monView != null) {
            if (monView != null) hideMonitor() else showMonitor()
            showMain()
        })
        tiles.add(tile(R.drawable.ic_p_guard, null, "EDGE GUARD", guards.isNotEmpty()) {
            if (guards.isNotEmpty()) hideGuards() else showGuards()
            showMain()
        })
        tiles.add(tile(R.drawable.ic_p_sens, null, "SENSITIVITY", false) { showSens() })
        tiles.add(tile(0, "$hzNow", "REFRESH HZ", true) { cycleHz() })
        tiles.add(tile(0, "$resNow%", "RESOLUTION", resNow < 100) { cycleRes() })
        tiles.add(tile(R.drawable.ic_p_stretch, null, "STRETCH " + strLabel(sx, sy), sx > 0 || sy > 0) { showStretch() })
        tiles.add(tile(0, "\u21BA", "RESET SCREEN", false) {
            prefs.edit().putInt("str_$pk", 0).putInt("sty_$pk", 0).putInt("tex_$pk", 100).apply()
            texOn = false
            resetScreen()
            toast("Screen back to normal. Stretch and resolution are off.")
            showMain()
        })
        tiles.add(tile(R.drawable.ic_p_therm, null, "THERMAL", thOn) {
            prefs.edit().putBoolean("thermal", !thOn).apply()
            toast(if (!thOn) "Thermal protection on at " + prefs.getInt("thermal_t", 44) + "\u00B0" else "Thermal protection off")
            showMain()
        })
        val gridV = grid(tiles, if (wide) 5 else 4)
        if (wide) {
            val body = LinearLayout(this)
            body.orientation = LinearLayout.HORIZONTAL
            body.gravity = Gravity.CENTER_VERTICAL
            body.addView(left, LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT))
            body.addView(gridV, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            holder.addView(body)
        } else {
            holder.addView(left)
            holder.addView(gridV)
        }

        // ---- performance mode
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeRow.gravity = Gravity.CENTER_VERTICAL
        modeRow.setPadding(0, dp(8), 0, 0)
        val ml = tv("PERFORMANCE", 9f, MUTED, true)
        ml.letterSpacing = 0.15f
        modeRow.addView(ml, LinearLayout.LayoutParams(dp(92), ViewGroup.LayoutParams.WRAP_CONTENT))
        for (i in 0..3) {
            val sel = i == mode
            val p = tv(modeNames[i], 10f, if (sel) "#06202E" else WHITE, true)
            p.gravity = Gravity.CENTER
            p.setPadding(dp(4), dp(7), dp(4), dp(7))
            p.background = if (sel) shape(ACC, 12) else shape("#161C28", 12, "#262F42", 1)
            p.setOnClickListener {
                prefs.edit().putInt("mode", i).apply()
                appliedPkg = if (i > 0) pk else null
                applyMode(i, pk)
                showMain()
            }
            modeRow.addView(p, lp1())
        }
        holder.addView(modeRow)
        updateStats()

        // ---- brightness and volume
        val tint = ColorStateList.valueOf(Color.parseColor(ACC))
        val br = SeekBar(this)
        br.max = 255
        br.progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Throwable) { 128 }
        br.progressTintList = tint
        br.thumbTintList = tint
        br.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                val v = (s?.progress ?: 128).coerceIn(1, 255)
                thread { shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness $v") }
            }
        })
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val vol = SeekBar(this)
        vol.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        vol.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        vol.progressTintList = tint
        vol.thumbTintList = tint
        vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) } catch (e: Throwable) {}
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val sl = LinearLayout(this)
        sl.orientation = LinearLayout.HORIZONTAL
        sl.gravity = Gravity.CENTER_VERTICAL
        sl.setPadding(0, dp(4), 0, 0)
        sl.addView(tv("LIGHT", 8.5f, MUTED, true))
        sl.addView(br, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sl.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        sl.addView(tv("VOLUME", 8.5f, MUTED, true))
        sl.addView(vol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        holder.addView(sl)
    }

    private fun showSens() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null
        val game = curGame()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = tv("SENSITIVITY  -  " + (game?.optString("name") ?: "").uppercase(Locale.US), 12f, WHITE, true)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val back = chip("BACK", true) { showMain() }
        head.addView(back, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(4))
        val vals = game?.optJSONArray("vals")
        if (vals == null || vals.length() == 0) {
            list.addView(tv("Open the Sensitivity tab in Sensi Helper first, then start the assistant again.", 12f, MUTED))
        } else {
            for (i in 0 until vals.length()) {
                val p = vals.optJSONArray(i) ?: continue
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.setPadding(0, dp(4), 0, dp(4))
                line.addView(tv(p.optString(0), 12f, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(tv(p.optString(1), 15f, WHITE, true))
                list.addView(line)
            }
        }
        val sc = ScrollView(this)
        sc.addView(list)
        val maxH = min(dp(250), resources.displayMetrics.heightPixels - dp(130))
        holder.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxH))
    }

    // ---------- actions
    private fun screenshot() {
        closePanel()
        val b = bubble
        b?.visibility = View.INVISIBLE
        ui.postDelayed({
            thread {
                val f = "/sdcard/Pictures/SensiHelper/shot_" + System.currentTimeMillis() + ".png"
                val ok = shizukuSh(
                    "mkdir -p /sdcard/Pictures/SensiHelper;screencap -p " + f +
                        ";am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + f
                )
                ui.post { b?.visibility = View.VISIBLE }
                toast(if (ok) "Screenshot saved in Pictures/SensiHelper" else "Start Shizuku (Tweaks tab) first")
            }
        }, 500)
    }

    private fun pushCrosshair() {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("x", xhNow().toString()))
        xhOn = true
    }

    private fun changeSize(d: Double) {
        val xo = xhNow()
        xo.put("size", (xo.optDouble("size", 10.0) + d).coerceIn(4.0, 40.0))
        if (xhOn) pushCrosshair()
    }

    override fun onDestroy() {
        if (profFor != null) endProfile()
        if (thermalOn) endThermal()
        if (texOn) { texOn = false; resetScreen() }
        prefs.edit().putBoolean("ingame", false).apply()
        stopVolWatch()
        hideSafeArea()
        screenExec.shutdown()
        ui.removeCallbacks(tick)
        restore()
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
        super.onDestroy()
    }
}

/** True when the user allowed "Usage access" for this app (needed to see which game is open). */
fun hasUsageAccess(ctx: Context): Boolean = try {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
    mode == AppOpsManager.MODE_ALLOWED
} catch (e: Throwable) { false }

/** Command that puts the screen size and density back to what the user had before Sensi Helper changed them. */
fun restoreScreenCmd(p: android.content.SharedPreferences): String {
    val us = p.getString("user_size", "") ?: ""
    val ud = p.getString("user_density", "") ?: ""
    val a = if (Regex("\\d+x\\d+").matches(us)) "wm size $us" else "wm size reset"
    val b = if (Regex("\\d+").matches(ud)) "wm density $ud" else "wm density reset"
    return "$a;$b"
}
