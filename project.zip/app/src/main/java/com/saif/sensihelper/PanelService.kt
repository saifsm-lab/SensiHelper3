package com.saif.sensihelper

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.provider.Settings
import android.widget.FrameLayout
import android.widget.SeekBar
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min

/**
 * Game Assistant (Red Magic style): a logo handle that docks to the screen edge while a game
 * is in front. Tap it to open the assistant: live temperature, battery and free RAM,
 * performance modes, Do Not Disturb, clean RAM, screenshot, crosshair and your sensitivity numbers.
 *
 * Data from the web page:
 * {"cur":"bs","hz":120,"games":{"bs":{"name","vals":[[n,v]],"xh":{..}},"ff":{..}}}
 */
class PanelService : Service() {

    private val ACC = "#7FD8FF"
    private val WHITE = "#FFFFFF"
    private val MUTED = "#9AA0B4"
    private val BS_PKG = "com.netease.newspike"
    private val FF_PKG = "com.dts.freefireth"
    private val modeNames = listOf("OFF", "STANDARD", "HIGH", "EXTREME")

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var panel: LinearLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var data = JSONObject()
    private var curKey = "bs"
    private var hz = 0
    private val xhs = HashMap<String, JSONObject>()
    private var xhOn = false
    private var dnd = false
    private var auto = false
    private var lastFg: String? = null
    private var gamePkg: String? = null
    private var appliedPkg: String? = null
    private var texOn = false
    private var tickN = 0
    private var profFor: String? = null
    private var profHz = 0
    private var profDnd = false
    private var monView: TextView? = null
    private var monFps = -1
    private val guards = ArrayList<View>()
    private var tTemp: TextView? = null
    private var tBat: TextView? = null
    private var tRam: TextView? = null
    private var tClock: TextView? = null
    private var gauge: Gauge? = null
    private val ui = Handler(Looper.getMainLooper())
    private val colors = listOf("#27f0d6", "#3dff6a", "#ffe83a", "#ff4d5a", "#ffffff", "#ff6bd6")
    private val prefs by lazy { getSharedPreferences("gs", Context.MODE_PRIVATE) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        intent?.getStringExtra("p")?.let {
            try {
                data = JSONObject(it)
                curKey = data.optString("cur", "bs")
                hz = data.optInt("hz", 0).let { v -> if (v in 30..240) v else 0 }
                xhs.clear()
            } catch (e: Throwable) {}
            ui.removeCallbacks(tick)
            auto = intent?.getBooleanExtra("auto", false) ?: false
            if (auto) { hideAll(); ui.post(tick) } else showBubble()
        }
        return START_NOT_STICKY
    }

    // ---------- per-game data
    private fun curGame(): JSONObject? = data.optJSONObject("games")?.optJSONObject(curKey)

    private fun xhNow(): JSONObject = xhs.getOrPut(curKey) {
        JSONObject(curGame()?.optJSONObject("xh")?.toString() ?: "{}")
    }

    private fun keyFor(pkg: String): String? = when {
        pkg == BS_PKG -> "bs"
        pkg.startsWith("com.dts.freefire") -> "ff"
        else -> null
    }

    private fun pkgNow(): String {
        val p = gamePkg ?: (if (curKey == "bs") BS_PKG else FF_PKG)
        return if (Regex("[a-zA-Z0-9_.]+").matches(p)) p else FF_PKG
    }

    // ---------- performance modes (same commands as the Tweaks tab)
    private fun cmdFor(mode: Int, pkg: String): String {
        val on1 = "cmd game mode performance $pkg;cmd notification set_dnd priority"
        val on2 = on1 +
            ";settings put global window_animation_scale 0.5;settings put global transition_animation_scale 0.5" +
            ";settings put global animator_duration_scale 0.5;cmd deviceidle whitelist +$pkg" +
            (if (hz > 0) ";settings put system min_refresh_rate $hz;settings put system peak_refresh_rate $hz" else "")
        val off = "cmd game reset $pkg;cmd notification set_dnd off" +
            ";settings put global window_animation_scale 1;settings put global transition_animation_scale 1" +
            ";settings put global animator_duration_scale 1;cmd deviceidle whitelist -$pkg" +
            ";settings delete system min_refresh_rate;settings delete system peak_refresh_rate" +
            ";cmd power set-fixed-performance-mode-enabled false"
        return when (mode) {
            1 -> "$off;$on1"
            2 -> "$off;$on2"
            3 -> "$off;$on2;cmd power set-fixed-performance-mode-enabled true"
            else -> off
        }
    }

    private fun applyMode(mode: Int, pkg: String) {
        thread {
            val ok = shizukuSh(cmdFor(mode, pkg))
            if (ok) {
                dnd = mode > 0
                toast(if (mode > 0) "Game Space: " + modeNames[mode] else "Performance mode off")
            } else toast("Start Shizuku (Tweaks tab) to use performance modes")
        }
    }

    /** Lowers the whole screen's render size while a game is in front. Reset when the game leaves. */
    @Suppress("DEPRECATION")
    // ---------- screen size: lower resolution and/or stretch, only while the game is in front
    private val screenExec = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun snapshotScreen() {
        // remember what the user had before we touch anything (skip if our own change may still be on)
        if (prefs.getBoolean("wm_dirty", false)) return
        val us = Regex("Override size:\\s*(\\d+x\\d+)").find(shizukuOut("wm size"))?.groupValues?.get(1) ?: ""
        val ud = Regex("Override density:\\s*(\\d+)").find(shizukuOut("wm density"))?.groupValues?.get(1) ?: ""
        prefs.edit().putString("user_size", us).putString("user_density", ud).apply()
    }

    private fun applyScreen(pkg: String) {
        screenExec.execute {
            try {
                snapshotScreen()
                val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
                val dn = Regex("Physical density:\\s*(\\d+)").find(shizukuOut("wm density"))
                if (sz == null || dn == null) { texOn = false; return@execute }
                val pw = sz.groupValues[1].toInt()
                val ph = sz.groupValues[2].toInt()
                val lo = minOf(pw, ph)
                var hi = maxOf(pw, ph)
                val st = prefs.getInt("str_$pkg", 0)
                if (st > 100) hi = minOf(hi * st / 100, hi * 2)
                val pct = prefs.getInt("tex_$pkg", 100)
                val lo2 = (lo * pct / 100 / 2) * 2
                val hi2 = (hi * pct / 100 / 2) * 2
                val w = if (pw <= ph) lo2 else hi2
                val h = if (pw <= ph) hi2 else lo2
                prefs.edit().putBoolean("wm_dirty", true).apply()
                val ok = if (pct < 100) {
                    // density scales with the size so buttons and text keep the same on-screen size
                    val base = prefs.getString("user_density", "")?.toIntOrNull() ?: dn.groupValues[1].toInt()
                    shizukuSh("wm size ${w}x${h};wm density ${maxOf(120, base * pct / 100)}")
                } else {
                    shizukuSh("wm size ${w}x${h}")
                }
                if (ok) ui.post {
                    if (st > 100) {
                        startVolWatch()
                        if (prefs.getBoolean("safe_on", true)) showSafeArea(st / 100f)
                    } else hideSafeArea()
                }
            } catch (e: Throwable) { texOn = false }
        }
    }

    private fun resetScreen() {
        ui.post { stopVolWatch(); hideSafeArea() }
        screenExec.execute {
            if (shizukuSh(restoreScreenCmd(prefs))) prefs.edit().putBoolean("wm_dirty", false).apply()
        }
    }

    /** Applies or removes the screen change for the current game, from its saved resolution and stretch. */
    private fun refreshScreen() {
        val p = pkgNow()
        val want = prefs.getInt("tex_$p", 100) < 100 || prefs.getInt("str_$p", 0) > 0
        if (want && !auto) {
            toast("Turn on Auto Game Assistant (Home page) first, so the screen goes back when you leave the game")
            return
        }
        if (want) { texOn = true; applyScreen(p) } else { texOn = false; resetScreen() }
    }

    private fun fmtMult(v: Int): String = String.format(Locale.US, "%.2fx", v / 100.0)

    // ---------- safe-area guide (purple bands show the extra stretched part)
    private var safeView: View? = null

    private inner class SafeView(c: Context, private val frac: Float) : View(c) {
        private val band = Paint().apply { color = Color.parseColor("#44A020F0") }
        private val line = Paint().apply {
            color = Color.parseColor("#CCC77DFF")
            strokeWidth = dp(2).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(dp(8).toFloat(), dp(6).toFloat()), 0f)
        }
        private val pill = Paint().apply { color = Color.parseColor("#E61B1030"); isAntiAlias = true }
        private val txt = Paint().apply {
            color = Color.WHITE
            textSize = dp(12).toFloat()
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        override fun onDraw(cv: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val half = w * frac / 2f
            val l = w / 2f - half
            val r = w / 2f + half
            cv.drawRect(0f, 0f, l, h, band)
            cv.drawRect(r, 0f, w, h, band)
            cv.drawLine(l, 0f, l, h, line)
            cv.drawLine(r, 0f, r, h, line)
            val label = "SAFE AREA FOR HUD"
            val tw = txt.measureText(label)
            cv.drawRoundRect(w / 2f - tw / 2f - dp(14), dp(6).toFloat(), w / 2f + tw / 2f + dp(14), dp(34).toFloat(), dp(14).toFloat(), dp(14).toFloat(), pill)
            cv.drawText(label, w / 2f, dp(25).toFloat(), txt)
        }
    }

    private fun showSafeArea(mult: Float) {
        hideSafeArea()
        val v = SafeView(this, 1f / mult)
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { wm.addView(v, lp); safeView = v } catch (e: Throwable) {}
    }

    private fun hideSafeArea() {
        safeView?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        safeView = null
    }

    // ---------- emergency restore: press Volume + while the screen is stretched
    private var volProc: Process? = null
    private var volThread: Thread? = null

    private fun startVolWatch() {
        if (volThread != null) return
        volThread = thread {
            try {
                val p = shizukuProc("getevent -l")
                if (p == null) { volThread = null; return@thread }
                volProc = p
                val r = p.inputStream.bufferedReader()
                while (true) {
                    val line = r.readLine() ?: break
                    if (line.contains("KEY_VOLUMEUP") && line.contains("DOWN")) ui.post { emergencyRestore() }
                }
            } catch (e: Throwable) {
            } finally {
                volProc = null
                volThread = null
            }
        }
    }

    private fun stopVolWatch() {
        try { volProc?.destroy() } catch (e: Throwable) {}
    }

    private fun emergencyRestore() {
        val pk = pkgNow()
        prefs.edit().putInt("str_$pk", 0).putInt("tex_$pk", 100).apply()
        texOn = false
        resetScreen()
        toast("Screen restored")
        if (panel != null) showMain()
    }

    // ---------- the stretched-screen popup
    private fun showStretch() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null
        val pk = pkgNow()
        var cur = prefs.getInt("str_$pk", 0).let { if (it > 100) it else 130 }

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("STRETCHED SCREEN", 13f, WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(chip("BACK", true) { showMain() }, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val tab = tv("PHONE", 11f, ACC, true)
        tab.gravity = Gravity.CENTER
        tab.setPadding(0, dp(8), 0, dp(8))
        tab.background = shape("#1A000000", 8, ACC)
        val tl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tl.setMargins(0, dp(8), 0, dp(4))
        holder.addView(tab, tl)

        val lab = tv("MULTIPLIER", 10f, MUTED, true)
        lab.gravity = Gravity.CENTER
        holder.addView(lab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val big = tv(fmtMult(cur), 28f, WHITE, true)
        big.gravity = Gravity.CENTER
        holder.addView(big, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val tint = ColorStateList.valueOf(Color.parseColor(ACC))
        val sb = SeekBar(this)
        sb.max = 40
        sb.progress = (cur - 100).coerceIn(0, 40)
        sb.progressTintList = tint
        sb.thumbTintList = tint
        holder.addView(sb)
        holder.addView(hrow(tv("1.00x", 10f, MUTED), tv("1.40x", 10f, MUTED).also { it.gravity = Gravity.END }))

        val nat = tv("-", 14f, WHITE, true)
        val proj = tv("-", 14f, WHITE, true)
        val c1 = LinearLayout(this)
        c1.orientation = LinearLayout.VERTICAL
        c1.addView(tv("NATIVE", 10f, MUTED, true))
        c1.addView(nat)
        val c2 = LinearLayout(this)
        c2.orientation = LinearLayout.VERTICAL
        c2.addView(tv("PROJECTION", 10f, MUTED, true))
        c2.addView(proj)
        holder.addView(hrow(c1, c2))

        var hiPx = 0
        var loPx = 0
        fun showProj() {
            if (hiPx > 0) proj.text = (hiPx * cur / 100).toString() + " x " + loPx
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                cur = 100 + p
                big.text = fmtMult(cur)
                showProj()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        thread {
            val sz = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(shizukuOut("wm size"))
            val a = sz?.groupValues?.get(1)?.toInt() ?: resources.displayMetrics.widthPixels
            val b = sz?.groupValues?.get(2)?.toInt() ?: resources.displayMetrics.heightPixels
            hiPx = maxOf(a, b)
            loPx = minOf(a, b)
            ui.post { nat.text = "$hiPx x $loPx"; showProj() }
        }

        val btnApply = chip("APPLY", true) {
            if (cur <= 100) { toast("Pick a multiplier above 1.00x"); return@chip }
            prefs.edit().putInt("str_$pk", cur).apply()
            refreshScreen()
        }
        val btnRestore = chip("RESTORE", false) {
            prefs.edit().putInt("str_$pk", 0).apply()
            refreshScreen()
            hideSafeArea()
            toast("Screen restored")
        }
        holder.addView(hrow(btnApply, btnRestore))

        val sw = Switch(this)
        sw.text = "Show safe area for HUD"
        sw.setTextColor(Color.parseColor(WHITE))
        sw.textSize = 12f
        sw.isChecked = prefs.getBoolean("safe_on", true)
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("safe_on", on).apply()
            val m = prefs.getInt("str_$pk", 0)
            if (on && texOn && m > 100) showSafeArea(m / 100f) else hideSafeArea()
        }
        holder.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(tv("Emergency restore: press VOLUME + while the screen is stretched.", 10f, MUTED, true))
        holder.addView(tv("The game is drawn wider and squeezed to fit, so you see more at the sides. Its buttons move toward the edges, so place them inside the safe area in the game's layout editor.", 10f, MUTED))
    }

    private val texLevels = intArrayOf(100, 85, 70, 55, 40)

    private fun cycleRes() {
        val k = "tex_" + pkgNow()
        val cur = prefs.getInt(k, 100)
        val i = texLevels.indexOf(cur)
        val next = texLevels[(i + 1) % texLevels.size]
        prefs.edit().putInt(k, next).apply()
        refreshScreen()
        toast("Resolution $next%")
        showMain()
    }

    private fun showMain() {
        val holder = panel ?: return
        holder.removeAllViews()
        val wide = resources.displayMetrics.widthPixels >= dp(560)
        val mode = prefs.getInt("mode", 2)
        val resNow = prefs.getInt("tex_" + pkgNow(), 100)
        val hzNow = prefs.getInt("hzsel", if (hz > 0) hz else hzChoices().last())

        // header: clock in the middle, close at the right
        val head = FrameLayout(this)
        val clock = tv("", 11f, ACC, true)
        clock.letterSpacing = 0.2f
        val cl = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cl.gravity = Gravity.CENTER
        head.addView(clock, cl)
        tClock = clock
        val x = tv("\u2715", 13f, "#FF8A80", true)
        x.gravity = Gravity.CENTER
        x.background = shape("#22FF5A5A", 15, "#99FF5A5A")
        x.setOnClickListener { closePanel() }
        val xl = FrameLayout.LayoutParams(dp(30), dp(30))
        xl.gravity = Gravity.END
        head.addView(x, xl)
        holder.addView(head)

        // buttons
        val bDnd = hex(R.drawable.ic_p_dnd, null, "DND", dnd) {
            thread {
                val want = !dnd
                val ok = shizukuSh("cmd notification set_dnd " + (if (want) "priority" else "off"))
                if (ok) dnd = want else toast("Start Shizuku (Tweaks tab) first")
                ui.post { if (panel != null) showMain() }
            }
        }
        val bSens = hex(R.drawable.ic_p_sens, null, "SENSITIVITY", false) { showSens() }
        val bXh = hex(R.drawable.ic_p_cross, null, "CROSSHAIR", xhOn, {
            val xo = xhNow()
            val cur = xo.optString("color", colors[0])
            xo.put("color", colors[(colors.indexOf(cur) + 1) % colors.size])
            if (xhOn) pushCrosshair()
            toast("Crosshair colour changed")
        }) {
            if (xhOn) { stopService(Intent(this, OverlayService::class.java)); xhOn = false } else pushCrosshair()
            showMain()
        }
        val bRam = hex(R.drawable.ic_p_ram, null, "CLEAN RAM", false) {
            toast("Cleaning...")
            thread { toast(if (shizukuSh("am kill-all")) "RAM cleaned" else "Start Shizuku (Tweaks tab) first") }
        }
        val bRes = hex(0, "$resNow%", "RESOLUTION", resNow < 100) { cycleRes() }
        val strNow = prefs.getInt("str_" + pkgNow(), 0)
        val bStr = hex(0, if (strNow > 100) fmtMult(strNow) else "OFF", "STRETCH", strNow > 100) { showStretch() }
        val bFix = hex(0, "\u21BA", "RESET SCREEN", false) {
            val pk = pkgNow()
            prefs.edit().putInt("str_$pk", 0).putInt("tex_$pk", 100).apply()
            texOn = false
            resetScreen()
            toast("Screen back to normal. Stretch and resolution are off.")
            showMain()
        }
        val bShot = hex(R.drawable.ic_p_shot, null, "SCREENSHOT", false) { screenshot() }
        val bApp = hex(R.drawable.ic_p_app, null, "TO APP", false) {
            closePanel()
            try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Throwable) {}
        }
        val bOff = hex(R.drawable.ic_p_hide, null, "POWER OFF", false) { stopSelf() }
        val bTurbo = hex(R.drawable.ic_p_turbo, null, modeNames[mode], mode >= 2) {
            val i = (mode + 1) % 4
            prefs.edit().putInt("mode", i).apply()
            val pk = pkgNow()
            appliedPkg = if (i > 0) pk else null
            applyMode(i, pk)
            showMain()
        }
        val bHz = hex(0, "$hzNow", "REFRESH", true) { cycleHz() }
        val bMinus = hex(0, "\u2212", "SIZE", false) { changeSize(-2.0) }
        val bPlus = hex(0, "+", "SIZE", false) { changeSize(2.0) }

        // centre: temperature ring with RAM and battery under it
        val centre = LinearLayout(this)
        centre.orientation = LinearLayout.VERTICAL
        centre.gravity = Gravity.CENTER_HORIZONTAL
        val gf = FrameLayout(this)
        val g = Gauge(this)
        gauge = g
        gf.addView(g, FrameLayout.LayoutParams(dp(86), dp(86)))
        val tt = tv("-", 17f, WHITE, true)
        tt.gravity = Gravity.CENTER
        tTemp = tt
        gf.addView(tt, FrameLayout.LayoutParams(dp(86), dp(86)))
        centre.addView(gf)
        val ram = tv("RAM -", 10f, WHITE, true)
        ram.gravity = Gravity.CENTER
        val bat = tv("BAT -", 10f, WHITE, true)
        bat.gravity = Gravity.CENTER
        tRam = ram; tBat = bat
        centre.addView(ram)
        centre.addView(bat)

        if (wide) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val l = LinearLayout(this)
            l.orientation = LinearLayout.VERTICAL
            l.addView(hrow(bDnd, bSens, bXh))
            l.addView(hrow(bRam, bRes, bShot))
            l.addView(hrow(bStr, bFix, View(this)))
            val r = LinearLayout(this)
            r.orientation = LinearLayout.VERTICAL
            r.addView(hrow(bApp, bOff, bTurbo))
            r.addView(hrow(bHz, bMinus, bPlus))
            row.addView(l, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val cp = LinearLayout.LayoutParams(dp(110), ViewGroup.LayoutParams.WRAP_CONTENT)
            cp.setMargins(dp(8), 0, dp(8), 0)
            row.addView(centre, cp)
            row.addView(r, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            holder.addView(row)
        } else {
            holder.addView(centre)
            holder.addView(hrow(bDnd, bSens, bXh))
            holder.addView(hrow(bRam, bRes, bShot))
            holder.addView(hrow(bStr, bFix, View(this)))
            holder.addView(hrow(bApp, bOff, bTurbo))
            holder.addView(hrow(bHz, bMinus, bPlus))
        }
        updateStats()

        // brightness and volume sliders
        val tint = ColorStateList.valueOf(Color.parseColor(ACC))
        val br = SeekBar(this)
        br.max = 255
        br.progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (e: Throwable) { 128 }
        br.progressTintList = tint
        br.thumbTintList = tint
        br.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                val v = (s?.progress ?: 128).coerceIn(1, 255)
                thread { shizukuSh("settings put system screen_brightness_mode 0;settings put system screen_brightness $v") }
            }
        })
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val vol = SeekBar(this)
        vol.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        vol.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        vol.progressTintList = tint
        vol.thumbTintList = tint
        vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0) } catch (e: Throwable) {}
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val sl = LinearLayout(this)
        sl.orientation = LinearLayout.HORIZONTAL
        sl.gravity = Gravity.CENTER_VERTICAL
        sl.setPadding(0, dp(6), 0, 0)
        sl.addView(tv("LIGHT", 8.5f, MUTED, true))
        sl.addView(br, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gap = View(this)
        sl.addView(gap, LinearLayout.LayoutParams(dp(10), 1))
        sl.addView(tv("VOLUME", 8.5f, MUTED, true))
        sl.addView(vol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        holder.addView(sl)
    }

    private fun showSens() {
        val holder = panel ?: return
        holder.removeAllViews()
        tTemp = null; tBat = null; tRam = null
        val game = curGame()
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = tv("SENSITIVITY  -  " + (game?.optString("name") ?: "").uppercase(Locale.US), 12f, WHITE, true)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val back = chip("BACK", true) { showMain() }
        head.addView(back, LinearLayout.LayoutParams(dp(80), ViewGroup.LayoutParams.WRAP_CONTENT))
        holder.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, dp(6), 0, dp(4))
        val vals = game?.optJSONArray("vals")
        if (vals == null || vals.length() == 0) {
            list.addView(tv("Open the Sensitivity tab in Sensi Helper first, then start the assistant again.", 12f, MUTED))
        } else {
            for (i in 0 until vals.length()) {
                val p = vals.optJSONArray(i) ?: continue
                val line = LinearLayout(this)
                line.orientation = LinearLayout.HORIZONTAL
                line.setPadding(0, dp(4), 0, dp(4))
                line.addView(tv(p.optString(0), 12f, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                line.addView(tv(p.optString(1), 15f, WHITE, true))
                list.addView(line)
            }
        }
        val sc = ScrollView(this)
        sc.addView(list)
        val maxH = min(dp(250), resources.displayMetrics.heightPixels - dp(130))
        holder.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxH))
    }

    // ---------- actions
    private fun screenshot() {
        closePanel()
        val b = bubble
        b?.visibility = View.INVISIBLE
        ui.postDelayed({
            thread {
                val f = "/sdcard/Pictures/SensiHelper/shot_" + System.currentTimeMillis() + ".png"
                val ok = shizukuSh(
                    "mkdir -p /sdcard/Pictures/SensiHelper;screencap -p " + f +
                        ";am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d file://" + f
                )
                ui.post { b?.visibility = View.VISIBLE }
                toast(if (ok) "Screenshot saved in Pictures/SensiHelper" else "Start Shizuku (Tweaks tab) first")
            }
        }, 500)
    }

    private fun pushCrosshair() {
        startForegroundService(Intent(this, OverlayService::class.java).putExtra("x", xhNow().toString()))
        xhOn = true
    }

    private fun changeSize(d: Double) {
        val xo = xhNow()
        xo.put("size", (xo.optDouble("size", 10.0) + d).coerceIn(4.0, 40.0))
        if (xhOn) pushCrosshair()
    }

    override fun onDestroy() {
        if (profFor != null) endProfile()
        if (texOn) { texOn = false; resetScreen() }
        prefs.edit().putBoolean("ingame", false).apply()
        stopVolWatch()
        hideSafeArea()
        screenExec.shutdown()
        ui.removeCallbacks(tick)
        restore()
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (e: Throwable) {} }
        bubble = null
        super.onDestroy()
    }
}

/** True when the user allowed "Usage access" for this app (needed to see which game is open). */
fun hasUsageAccess(ctx: Context): Boolean = try {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
    mode == AppOpsManager.MODE_ALLOWED
} catch (e: Throwable) { false }


/** Command that puts the screen size and density back to what the user had before Sensi Helper changed them. */
fun restoreScreenCmd(p: android.content.SharedPreferences): String {
    val us = p.getString("user_size", "") ?: ""
    val ud = p.getString("user_density", "") ?: ""
    val a = if (Regex("\\d+x\\d+").matches(us)) "wm size $us" else "wm size reset"
    val b = if (Regex("\\d+").matches(ud)) "wm density $ud" else "wm density reset"
    return "$a;$b"
}
